package com.vz.gchclin.common.dataobject;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;


import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ClinError implements Serializable {
	
	private String clinErrorCode;
	private String clinErrorDescription;
	private InvalidSpecConfigurations invalidSpecConfigurations;
	
	public String getClinErrorCode() {
		return clinErrorCode;
	}
	public void setClinErrorCode(String clinErrorCode) {
		this.clinErrorCode = clinErrorCode;
	}
	public String getClinErrorDescription() {
		return clinErrorDescription;
	}
	public void setClinErrorDescription(String clinErrorDescription) {
		this.clinErrorDescription = clinErrorDescription;
	}
	public InvalidSpecConfigurations getInvalidSpecConfigurations() {
		return invalidSpecConfigurations;
	}
	public void setInvalidSpecConfigurations(
			InvalidSpecConfigurations invalidSpecConfigurations) {
		this.invalidSpecConfigurations = invalidSpecConfigurations;
	}
	
	
	public String toString(){
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
	
	
}