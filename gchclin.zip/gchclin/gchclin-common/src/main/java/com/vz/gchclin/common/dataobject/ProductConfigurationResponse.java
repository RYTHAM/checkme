package com.vz.gchclin.common.dataobject;


import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import java.util.List;
import java.io.*;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ProductConfigurationResponse implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private ProductBaseConfigurations productBaseConfigurations;
	private List<FeatureConfigurationResponse> featureConfigurationResponse;
	
	public ProductBaseConfigurations getProductBaseConfigurations() {
		return productBaseConfigurations;
	}
	public void setProductBaseConfigurations(
			ProductBaseConfigurations productBaseConfigurations) {
		this.productBaseConfigurations = productBaseConfigurations;
	}
	
	
	public List<FeatureConfigurationResponse> getFeatureConfigurationResponse() {
		return featureConfigurationResponse;
	}
	public void setFeatureConfigurationResponse(
			List<FeatureConfigurationResponse> featureConfigurationResponse) {
		this.featureConfigurationResponse = featureConfigurationResponse;
	}
	
	public String toString(){
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
	
	private void writeObject(ObjectOutputStream stream) throws IOException {
		stream.defaultWriteObject();
	}

	private void readObject(ObjectInputStream stream) throws IOException,
			ClassNotFoundException {
		stream.defaultReadObject();
	}
}