package com.vz.gchclin.common.dataobject;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import com.vz.gchclin.common.ldap.LdapUserData;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import java.io.*;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class GetClinListIn implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private String clientId;
	private String transactionID;// needs to move out of this class, add in GetClinListIn
	private ContractDetails contractDetails;
	private List<ProductConfigurations> productConfigurations;
	private LdapUserData userData;
	
	public String getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
		
	public ContractDetails getContractDetails() {
		return contractDetails;
	}
	public void setContractDetails(
			ContractDetails contractDetails) {
		this.contractDetails = contractDetails;
	}
	
	public List<ProductConfigurations> getProductConfigurations() {
		return productConfigurations;
	}
	public void setProductConfigurations(
			List<ProductConfigurations> productConfigurations) {
		this.productConfigurations = productConfigurations;
	}
	
	public LdapUserData getUserData() {
		return userData;
	}
	public void setUserData(LdapUserData userData) {
		this.userData = userData;
	}
	
	
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String toString(){
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
	
	 private void writeObject(ObjectOutputStream stream)
	            throws IOException {
	        stream.defaultWriteObject();
	    }

	    private void readObject(ObjectInputStream stream)
	            throws IOException, ClassNotFoundException {
	        stream.defaultReadObject();
	    }
	
}
