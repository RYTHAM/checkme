package com.vz.gchclin.common.ldap;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import java.io.Serializable;
import java.io.*;

public class LdapUserData implements Serializable {
    private String userId;
    private String eId;    

	private List<String> gsamLevels;
	private List<String> translatedGsamInfo;
    private Boolean isAvailable = Boolean.FALSE;

    public LdapUserData() {
    }  
    
    public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<String> getTranslatedGsamInfo() {
		return translatedGsamInfo;
	}

	public void setTranslatedGsamInfo(List<String> translatedGsamInfo) {
		this.translatedGsamInfo = translatedGsamInfo;
	}

	public String geteId() {
		return eId;
	}

	public void seteId(String eId) {
		this.eId = eId;
	}
    
    public List<String> getGsamLevels() {
        return gsamLevels;
    }
    
    public void setGsamLevels(List<String> gsamLevels) {
        this.gsamLevels = gsamLevels;
    }

    public Boolean getIsAvailable() {
        return isAvailable;
    }

    public void setIsAvailable(Boolean isAvailable) {
        this.isAvailable = isAvailable;
    }
    
       
    public String toString(){
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
    
    
    private void writeObject(ObjectOutputStream stream)
            throws IOException {
        stream.defaultWriteObject();
    }

    private void readObject(ObjectInputStream stream)
            throws IOException, ClassNotFoundException {
        stream.defaultReadObject();
    }
}
