package com.vz.gchclin.common.dataobject;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ClinSearchIn  implements Serializable{
	/**
	 *   { 'contractId': '1', 'startRow': 0,'pageSize': 1 ,'isAsc':'true','sortBy':'clinId' }
	 */
	private static final long serialVersionUID = 1L;
	private int startRow;
	private int pageSize;
	private String sortBy;
	private boolean asc;
	private String contractId;
	private String clinId;
	private String clinDesc;
	public int getStartRow() {
		return startRow;
	}
	public void setStartRow(int startRow) {
		this.startRow = startRow;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public String getSortBy() {
		return sortBy;
	}
	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}
	public boolean isAsc() {
		return asc;
	}
	public void setAsc(boolean asc) {
		this.asc = asc;
	}
	public String getContractId() {
		return contractId;
	}
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	public String getClinId() {
		return clinId;
	}
	public void setClinId(String clinId) {
		this.clinId = clinId;
	}
	public String getClinDesc() {
		return clinDesc;
	}
	public void setClinDesc(String clinDesc) {
		this.clinDesc = clinDesc;
	}
	

}
