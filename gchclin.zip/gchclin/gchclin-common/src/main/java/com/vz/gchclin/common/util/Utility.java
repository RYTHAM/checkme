package com.vz.gchclin.common.util;


import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Arrays;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.ws.rs.core.HttpHeaders;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.commons.configuration.Configuration;

import java.text.SimpleDateFormat;
import java.util.SimpleTimeZone;


public class Utility {

    private static final Logger logger = Logger.getLogger(Utility.class);

  /*  public static Long getOid(EntityManager entityManager, String tableName) {
        final String METHOD_NAME = "Utility:getOid";
        logger.debug(METHOD_NAME + " ENTER ");
        Query query = entityManager.createNativeQuery("select esg.get_table_id(?)  next_oid from dual");
        query.setParameter(1, tableName);
        BigDecimal oid = (BigDecimal) query.getSingleResult();
        logger.debug(METHOD_NAME + " Exit with getOid:" + oid);
        return oid.longValue();
    }*/
       
   /* public static Map getHeaderValues(HttpHeaders headers){
		String METHOD_NAME = "[CommonUtility::getHeaderValues]";
		logger.debug(METHOD_NAME + " - Entering : " );
		String clientId=null;
		Map map = new HashMap();
		try {
			if(headers!=null){
				List<String> headersList = headers.getRequestHeader("ITWB_Subscriber_Appname");
				if(headersList !=null){
					clientId = headersList.get(0);
					map.put("CLIENT_ID" , clientId);
				}
			}
		}catch (Exception ex) {
			logger.error(METHOD_NAME+ " Error ", ex);
			
		}
		return map;
    } */
    
    
    public static boolean  isAcceptableClient(String clientId, String method, Configuration config)
   	{
   	 	String methodName = "Utility::isAcceptableClient()  ";
   	 	logger.debug("\n  Entering " + methodName + "\nInput:\n"+ clientId +"\nMethod:"+method);
   	   boolean  isAcceptableClient=false;
   	   String commonAcceptableClients = config.getString("gchclin/beans/select/commonAcceptableClients");
   	 	String acceptableClients = commonAcceptableClients +"," + config.getString("gchclin/beans/select/"+method+"/acceptableClients");
   		  logger.debug("\n  Entering " + methodName + "\n acceptableClients: "+ acceptableClients);
   		String[] arrClientIds = (acceptableClients.toUpperCase()).split("\\,");
   		List listClientIds = Arrays.asList(arrClientIds);
   		int indx = listClientIds.indexOf(StringUtils.upperCase(clientId));
   		if(indx>=0)
   		{
   			isAcceptableClient =true;
   		}
   		return isAcceptableClient;
   	}
    
    //For given Featurecode list all the spec codes for it.
    public static List<String> getSpecCodesbyFeatureCode(EntityManager entityManager, String featureCode){
    	String METHOD_NAME = "Utility::getSpecCodesbyFeatureCode()";
    	if(logger.isInfoEnabled()){
    		logger.info(METHOD_NAME + " start feature code is " + featureCode);
    	}
    	String sql = "select map.spec_code FROM clin.USEC_ITEM_SPEC_MAP map WHERE map.item_type = 'FET' AND map.item_code   = '" + featureCode + "' AND map.MAP_TYPE  = 'RATE_DET' and " + effectiveDate("map");
    	logger.debug("SQL Query is " + sql);
    	Query qry = entityManager.createNativeQuery(sql);
    	List<String> specCodes = qry.getResultList();
    	if(logger.isInfoEnabled()){
    		logger.info(METHOD_NAME + " end");
    	}
    	return specCodes;
    }
    
    public static String effectiveDate(String tableAlias){
		String METHOD_NAME = "Utility::.effectiveDate()";
		logger.debug(METHOD_NAME  + " start");
		/*SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
		dateFormat.setTimeZone(new SimpleTimeZone(0,"GMT"));
		logger.debug(METHOD_NAME + "date is  " + dateFormat.format(new java.util.Date()));*/
		String dateCondition = tableAlias + ".start_date <= sysdate AND " + tableAlias + ".end_date > sysdate" ;
		logger.debug(METHOD_NAME  + " dateCondition is  " + dateCondition + " end");
		return dateCondition;
		
	}
    
    
    
}
