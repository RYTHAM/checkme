package com.vz.gchclin.common.dataobject;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import java.io.*;
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class GetClinListOut extends GchClinOut implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String errorMessage;
	private String transactionID;

	private ContractDetails contractDetails;
	private List<ProductConfigurationResponse> productConfigurationResponse;
	
	public String getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	
	
	public List<ProductConfigurationResponse> getProductConfigurationResponse() {
		return productConfigurationResponse;
	}
	public void setProductConfigurationResponse(
			List<ProductConfigurationResponse> productConfigurationResponse) {
		this.productConfigurationResponse = productConfigurationResponse;
	}
	
	
	public ContractDetails getContractDetails() {
		return contractDetails;
	}
	public void setContractDetails(
			ContractDetails contractDetails) {
		this.contractDetails = contractDetails;
	}
	
	
	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	public String toString(){
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
	
	 private void writeObject(ObjectOutputStream stream)
	            throws IOException {
	        stream.defaultWriteObject();
	    }

	    private void readObject(ObjectInputStream stream)
	            throws IOException, ClassNotFoundException {
	        stream.defaultReadObject();
	    }
}