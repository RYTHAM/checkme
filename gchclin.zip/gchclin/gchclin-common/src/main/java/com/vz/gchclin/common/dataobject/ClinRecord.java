package com.vz.gchclin.common.dataobject;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ClinRecord implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@XmlElement(name ="clinId")
	private String clinId;
	@XmlElement(name ="clinDesc")
	private String clinDesc;
	@XmlElement(name ="contractId")
	private String contractId;
	@XmlElement(name ="chargeType")
	private String chargeType;
	@XmlElement(name ="effectiveFrom")
	private String effectiveFrom;
	@XmlElement(name ="effectiveUntil")
	private String effectiveUntil;
	@XmlElement(name ="lastUpdateDate")
	private String lastUpdateDate;
	@XmlElement(name ="productCode")
	private String productCode;
	@XmlElement(name ="productGroupCode")
	private String productGroupCode;
	@XmlElement(name ="solutionCode")
	private String solutionCode;
	@XmlElement(name ="featureCode")
	private String featureCode; 
	@XmlElement(name ="specCode1")
	private String specCode1;
	@XmlElement(name ="specCode2")
	private String specCode2;
	@XmlElement(name ="specCode3")
	private String specCode3;
	@XmlElement(name ="specCode4")
	private String specCode4;
	@XmlElement(name ="specCode5")
	private String specCode5;
	@XmlElement(name ="specCode6")
	private String specCode6;
	@XmlElement(name ="specCode7")
	private String specCode7;
	@XmlElement(name ="specCode8")
	private String specCode8;
	@XmlElement(name ="specCode9")
	private String specCode9;
	@XmlElement(name ="specCode10")
	private String specCode10;
	@XmlElement(name ="specCode11")
	private String specCode11;
	@XmlElement(name ="specCode12")
	private String specCode12;
	@XmlElement(name ="specCode13")
	private String specCode13;
	@XmlElement(name ="specCode14")
	private String specCode14;
	@XmlElement(name ="specCode15")
	private String specCode15;
	@XmlElement(name ="specCode16")
	private String specCode16;
	@XmlElement(name ="specValue1")
	private String specValue1;
	@XmlElement(name ="specValue2")
	private String specValue2;
	@XmlElement(name ="specValue3")
	private String specValue3;
	@XmlElement(name ="specValue4")
	private String specValue4;
	@XmlElement(name ="specValue5")
	private String specValue5;
	@XmlElement(name ="specValue6")
	private String specValue6;
	@XmlElement(name ="specValue7")
	private String specValue7;
	@XmlElement(name ="specValue8")
	private String specValue8;
	@XmlElement(name ="specValue9")
	private String specValue9;
	@XmlElement(name ="specValue10")
	private String specValue10;
	@XmlElement(name ="specValue11")
	private String specValue11;
	@XmlElement(name ="specValue12")
	private String specValue12;
	@XmlElement(name ="specValue13")
	private String specValue13;
	@XmlElement(name ="specValue14")
	private String specValue14;
	@XmlElement(name ="specValue15")
	private String specValue15;
	@XmlElement(name ="specValue16")
	private String specValue16;
	
	
	public String getClinId() {
		return clinId;
	}
	public void setClinId(String clinId) {
		this.clinId = clinId;
	}
	public String getClinDesc() {
		return clinDesc;
	}
	public void setClinDesc(String clinDesc) {
		this.clinDesc = clinDesc;
	}
	public String getContractId() {
		return contractId;
	}
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	public String getChargeType() {
		return chargeType;
	}
	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}
	public String getEffectiveFrom() {
		return effectiveFrom;
	}
	public void setEffectiveFrom(String effectiveFrom) {
		this.effectiveFrom = effectiveFrom;
	}
	public String getEffectiveUntil() {
		return effectiveUntil;
	}
	public void setEffectiveUntil(String effectiveUntil) {
		this.effectiveUntil = effectiveUntil;
	}
	public String getLastUpdateDate() {
		return lastUpdateDate;
	}
	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProductGroupCode() {
		return productGroupCode;
	}
	public void setProductGroupCode(String productGroupCode) {
		this.productGroupCode = productGroupCode;
	}
	public String getSolutionCode() {
		return solutionCode;
	}
	public void setSolutionCode(String solutionCode) {
		this.solutionCode = solutionCode;
	}
	public String getFeatureCode() {
		return featureCode;
	}
	public void setFeatureCode(String featureCode) {
		this.featureCode = featureCode;
	}
	public String getSpecCode1() {
		return specCode1;
	}
	public void setSpecCode1(String specCode1) {
		this.specCode1 = specCode1;
	}
	public String getSpecCode2() {
		return specCode2;
	}
	public void setSpecCode2(String specCode2) {
		this.specCode2 = specCode2;
	}
	public String getSpecCode3() {
		return specCode3;
	}
	public void setSpecCode3(String specCode3) {
		this.specCode3 = specCode3;
	}
	public String getSpecCode4() {
		return specCode4;
	}
	public void setSpecCode4(String specCode4) {
		this.specCode4 = specCode4;
	}
	public String getSpecCode5() {
		return specCode5;
	}
	public void setSpecCode5(String specCode5) {
		this.specCode5 = specCode5;
	}
	public String getSpecCode6() {
		return specCode6;
	}
	public void setSpecCode6(String specCode6) {
		this.specCode6 = specCode6;
	}
	public String getSpecCode7() {
		return specCode7;
	}
	public void setSpecCode7(String specCode7) {
		this.specCode7 = specCode7;
	}
	public String getSpecCode8() {
		return specCode8;
	}
	public void setSpecCode8(String specCode8) {
		this.specCode8 = specCode8;
	}
	public String getSpecCode9() {
		return specCode9;
	}
	public void setSpecCode9(String specCode9) {
		this.specCode9 = specCode9;
	}
	public String getSpecCode10() {
		return specCode10;
	}
	public void setSpecCode10(String specCode10) {
		this.specCode10 = specCode10;
	}
	public String getSpecCode11() {
		return specCode11;
	}
	public void setSpecCode11(String specCode11) {
		this.specCode11 = specCode11;
	}
	public String getSpecCode12() {
		return specCode12;
	}
	public void setSpecCode12(String specCode12) {
		this.specCode12 = specCode12;
	}
	public String getSpecCode13() {
		return specCode13;
	}
	public void setSpecCode13(String specCode13) {
		this.specCode13 = specCode13;
	}
	public String getSpecCode14() {
		return specCode14;
	}
	public void setSpecCode14(String specCode14) {
		this.specCode14 = specCode14;
	}
	public String getSpecCode15() {
		return specCode15;
	}
	public void setSpecCode15(String specCode15) {
		this.specCode15 = specCode15;
	}
	public String getSpecCode16() {
		return specCode16;
	}
	public void setSpecCode16(String specCode16) {
		this.specCode16 = specCode16;
	}
	public String getSpecValue1() {
		return specValue1;
	}
	public void setSpecValue1(String specValue1) {
		this.specValue1 = specValue1;
	}
	public String getSpecValue2() {
		return specValue2;
	}
	public void setSpecValue2(String specValue2) {
		this.specValue2 = specValue2;
	}
	public String getSpecValue3() {
		return specValue3;
	}
	public void setSpecValue3(String specValue3) {
		this.specValue3 = specValue3;
	}
	public String getSpecValue4() {
		return specValue4;
	}
	public void setSpecValue4(String specValue4) {
		this.specValue4 = specValue4;
	}
	public String getSpecValue5() {
		return specValue5;
	}
	public void setSpecValue5(String specValue5) {
		this.specValue5 = specValue5;
	}
	public String getSpecValue6() {
		return specValue6;
	}
	public void setSpecValue6(String specValue6) {
		this.specValue6 = specValue6;
	}
	public String getSpecValue7() {
		return specValue7;
	}
	public void setSpecValue7(String specValue7) {
		this.specValue7 = specValue7;
	}
	public String getSpecValue8() {
		return specValue8;
	}
	public void setSpecValue8(String specValue8) {
		this.specValue8 = specValue8;
	}
	public String getSpecValue9() {
		return specValue9;
	}
	public void setSpecValue9(String specValue9) {
		this.specValue9 = specValue9;
	}
	public String getSpecValue10() {
		return specValue10;
	}
	public void setSpecValue10(String specValue10) {
		this.specValue10 = specValue10;
	}
	public String getSpecValue11() {
		return specValue11;
	}
	public void setSpecValue11(String specValue11) {
		this.specValue11 = specValue11;
	}
	public String getSpecValue12() {
		return specValue12;
	}
	public void setSpecValue12(String specValue12) {
		this.specValue12 = specValue12;
	}
	public String getSpecValue13() {
		return specValue13;
	}
	public void setSpecValue13(String specValue13) {
		this.specValue13 = specValue13;
	}
	public String getSpecValue14() {
		return specValue14;
	}
	public void setSpecValue14(String specValue14) {
		this.specValue14 = specValue14;
	}
	public String getSpecValue15() {
		return specValue15;
	}
	public void setSpecValue15(String specValue15) {
		this.specValue15 = specValue15;
	}
	public String getSpecValue16() {
		return specValue16;
	}
	public void setSpecValue16(String specValue16) {
		this.specValue16 = specValue16;
	}


}
