package com.vz.gchclin.common.dataobject;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import java.util.List;
import java.io.*;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class FeatureConfigurations implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private FeatureBaseConfigurations featureBaseConfigurations;
	private String chargeType;
	private List<SpecConfigurations> specConfigurations;
	
	
	public String getChargeType() {
		return chargeType;
	}
	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}
	public List<SpecConfigurations> getSpecConfigurations() {
		return specConfigurations;
	}
	public void setSpecConfigurations(List<SpecConfigurations> specConfigurations) {
		this.specConfigurations = specConfigurations;
	}
	
	public FeatureBaseConfigurations getFeatureBaseConfigurations() {
		return featureBaseConfigurations;
	}
	public void setFeatureBaseConfigurations(
			FeatureBaseConfigurations featureBaseConfigurations) {
		this.featureBaseConfigurations = featureBaseConfigurations;
	}
	
	
	public String toString(){
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
	
	
	 private void writeObject(ObjectOutputStream stream)
	            throws IOException {
	        stream.defaultWriteObject();
	    }

	    private void readObject(ObjectInputStream stream)
	            throws IOException, ClassNotFoundException {
	        stream.defaultReadObject();
	    }
	
	

}