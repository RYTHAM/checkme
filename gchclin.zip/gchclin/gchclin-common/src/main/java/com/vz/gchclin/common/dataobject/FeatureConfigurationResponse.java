package com.vz.gchclin.common.dataobject;


import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import java.util.List;

import java.io.*;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class FeatureConfigurationResponse implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private FeatureBaseConfigurations featureBaseConfigurations;
	private List<Clins> clins;
	private ClinError clinError;
	
	public FeatureBaseConfigurations getFeatureBaseConfigurations() {
		return featureBaseConfigurations;
	}
	public void setFeatureBaseConfigurations(
			FeatureBaseConfigurations featureBaseConfigurations) {
		this.featureBaseConfigurations = featureBaseConfigurations;
	}
	
	public List<Clins> getClins() {
		return clins;
	}
	public void setClins(List<Clins> clins) {
		this.clins = clins;
	}
	public ClinError getClinError() {
		return clinError;
	}
	public void setClinError(ClinError clinError) {
		this.clinError = clinError;
	}
	public String toString(){
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
	
	 private void writeObject(ObjectOutputStream stream)
	            throws IOException {
	        stream.defaultWriteObject();
	    }

	    private void readObject(ObjectInputStream stream)
	            throws IOException, ClassNotFoundException {
	        stream.defaultReadObject();
	    }
	
}	