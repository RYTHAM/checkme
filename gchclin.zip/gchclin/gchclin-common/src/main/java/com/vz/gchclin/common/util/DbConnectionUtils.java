package com.vz.gchclin.common.util;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

public class DbConnectionUtils {

    private static final Logger logger = Logger.getLogger(DbConnectionUtils.class);

    public static Connection getConnection(String type) {
        DataSource ds = null;
        Connection conn = null;
        try {
            InitialContext ic = new InitialContext();
            if("W".equalsIgnoreCase(type)){
            	ds = (DataSource) ic.lookup("com.vz.gch.clin.write.ds");
            }else{
            	ds = (DataSource) ic.lookup("com.vz.gch.clin.read.ds");
            }
            conn = ds.getConnection();
        } catch (NamingException ex) {
            throw new IllegalStateException(ex);
        } catch (SQLException ex) {
            throw new IllegalStateException(ex);
        }
        return conn;
    }
    
    public static Connection getConnection(DataSource ds) throws SQLException{
    	Connection conn = null;
         try {
        	 if(ds != null) { 
        		 conn = ds.getConnection();
        	 } else {
        		 conn = getConnection("W");
        	 }
         } catch (SQLException ex) {
        	 throw new SQLException(ex.getMessage(), ex);
         }
         return conn;
	}

   
    /**
     * This API is used to close db objects if it not null
     * @param con
     * @param stmt
     * @param rs
     */
	public static void closeDBObjects(Connection con, Statement stmt, ResultSet rs) {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				if (logger.isEnabledFor(Level.ERROR))
					logger.error("Failed to close the DB ResultSet", e);
			}
		}
		if (stmt != null) {
			try {
				stmt.close();
			} catch (SQLException e) {
				if (logger.isEnabledFor(Level.ERROR))
					logger.error("Failed to close the DB Statement", e);
			}
		}
		if (con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				if (logger.isEnabledFor(Level.ERROR))
					logger.error("Failed to close the DB Connection", e);
			}
		}
	}
	
	 /**
     * This API is used to close db objects if it not null
     * @param con
     * @param prepared stmt
     * @param rs
     */
	public static void closeDBObjects(Connection con, PreparedStatement stmt, ResultSet rs) {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				if (logger.isEnabledFor(Level.ERROR))
					logger.error("Failed to close the DB ResultSet", e);
			}
		}
		if (stmt != null) {
			try {
				stmt.close();
			} catch (SQLException e) {
				if (logger.isEnabledFor(Level.ERROR))
					logger.error("Failed to close the DB Statement", e);
			}
		}
		if (con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				if (logger.isEnabledFor(Level.ERROR))
					logger.error("Failed to close the DB Connection", e);
			}
		}
	}
	
		
}
