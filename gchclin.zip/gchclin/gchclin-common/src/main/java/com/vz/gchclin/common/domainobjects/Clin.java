package com.vz.gchclin.common.domainobjects;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;

@Entity
@Table(name = "CLIN")
public class Clin implements Serializable {

	private static final long serialVersionUID = 2444324258370342670L;

	@Id
	@Column(name = "CLIN_OID")
	private Long clinOid;
	@Column(name = "CLIN_ID")
	private String clinId;
	@Column(name = "CLIN_DESCRIPTION")
	private String clinDesc;
	@Column(name = "CHARGE_TYPE")
	private String chargeType;
	@Column(name = "USER_ID")
	private String userId;
	@Column(name = "TIMESTAMP")
	@Temporal(TemporalType.TIMESTAMP)
	public Date timeStamp;
	@Column(name = "START_DATE")
	@Temporal(TemporalType.TIMESTAMP)
	public Date startDate;
	@Column(name = "END_DATE")
	@Temporal(TemporalType.TIMESTAMP)
	public Date endDate;
	
	public Clin() {

	}
	
	public Long getClinOid() {
		return clinOid;
	}

	public void setClinOid(Long clinOid) {
		this.clinOid = clinOid;
	}

	public String getClinId() {
		return clinId;
	}

	public void setClinId(String clinId) {
		this.clinId = clinId;
	}

	public String getClinDesc() {
		return clinDesc;
	}

	public void setClinDesc(String clinDesc) {
		this.clinDesc = clinDesc;
	}

	public String getChargeType() {
		return chargeType;
	}

	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Date getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	@Override
	public String toString() {
		return "FeatureConfigurations [chargeType=" + chargeType
				+ ", clinDesc=" + clinDesc + ", clinId=" + clinId
				+ ", clinOid=" + clinOid + ", endDate=" + endDate
				+ ", startDate=" + startDate + ", timeStamp=" + timeStamp
				+ ", userId=" + userId + "]";
	}
}	


