package com.vz.gchclin.common.dataobject;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;



@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class FeatureBaseConfigurations implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String featureCode;
	private String featureInstanceID;
	
	public String getFeatureCode() {
		return featureCode;
	}
	public void setFeatureCode(String featureCode) {
		this.featureCode = featureCode;
	}
	public String getFeatureInstanceID() {
		return featureInstanceID;
	}
	public void setFeatureInstanceID(String featureInstanceID) {
		this.featureInstanceID = featureInstanceID;
	}
	
	public String toString(){
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
	
	
}