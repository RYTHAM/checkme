package com.vz.gchclin.common.dataobject;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class UploadRecord implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5276506612432210989L;
	@XmlElement(name ="uploadRequestId")
	private Long uploadRequestId;
	@XmlElement(name ="contractId")
	private String contractId;
	@XmlElement(name ="requester")
	private String requester;
	@XmlElement(name ="status")
	private String status;
	@XmlElement(name ="timeStamp")
	private String timeStamp;
	@XmlElement(name ="startTime")
	private String startTime;
	@XmlElement(name ="endTime")
	private String endTime;
	@XmlElement(name ="processFlag")
	private String processFlag;
	@XmlElement(name ="comments")
	private String errorMsg;

	public Long getUploadRequestId() {
		return uploadRequestId;
	}
	public void setUploadRequestId(Long uploadRequestId) {
		this.uploadRequestId = uploadRequestId;
	}
	public String getContractId() {
		return contractId;
	}
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	public String getRequester() {
		return requester;
	}
	public void setRequester(String requester) {
		this.requester = requester;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getProcessFlag() {
		return processFlag;
	}
	public void setProcessFlag(String processFlag) {
		this.processFlag = processFlag;
	}
	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	

	

	
	
	

}
