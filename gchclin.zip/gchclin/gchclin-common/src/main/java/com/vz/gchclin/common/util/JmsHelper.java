package com.vz.gchclin.common.util;

import javax.jms.Connection;
import javax.jms.MessageProducer;
import javax.jms.Session;

import org.apache.log4j.Logger;

public class JmsHelper {
	private static final Logger logger = Logger.getLogger(JmsHelper.class);
	public static void close(MessageProducer sender, Session session,
			Connection conn) {
		if (sender != null) {
			try {
				sender.close();
			} catch (Exception ignore) {
				logger.warn("Error closing JMS MessageProducer",ignore);
			}
		}
		if (session != null) {
			try {
				session.close();
			} catch (Exception ignore) {
				logger.warn("Error closing JMS Session",ignore);
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (Exception ignore) {
				logger.warn("Error closing JMS conn",ignore);
			}
		}
	}

}
