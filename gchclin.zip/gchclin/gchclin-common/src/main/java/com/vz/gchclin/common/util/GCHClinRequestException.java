package com.vz.gchclin.common.util;

/**
*
* @Xml Process Exception
*/
public class GCHClinRequestException extends RuntimeException {

   public GCHClinRequestException(String message) {
       super(message);
   }

   public GCHClinRequestException(String message, Throwable cause) {
       super(message, cause);
   }
}