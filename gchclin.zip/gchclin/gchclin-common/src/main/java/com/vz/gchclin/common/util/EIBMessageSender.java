package com.vz.gchclin.common.util;

import javax.jms.Session;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.TextMessage;
import com.ibm.mq.jms.MQQueueConnectionFactory;
import org.apache.log4j.Logger;


/**
 * A service that sends and GCHCLIN Pub messages.
 * 
 * @Laxminarsimha.kongari
 * 
 */
public class EIBMessageSender {
	private static Logger _logger = Logger.getLogger(EIBMessageSender.class);
	private String message;
	private String host;
	int port;
	int type;
	private String queName;
	private String queueManager;
	private String channel;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getQueName() {
		return queName;
	}
	public void setQueName(String queName) {
		this.queName = queName;
	}
	public String getQueueManager() {
		return queueManager;
	}
	public void setQueueManager(String queueManager) {
		this.queueManager = queueManager;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}

	public void sendMessage() throws Exception{
		String METHOD_NAME = "EIBMessageSender:sendMessage():";
		 QueueConnection connection =null;
		 QueueSession session=null;
		 QueueSender messageProducer=null;

		try {
			
			if (_logger.isInfoEnabled()) {
				_logger.info(METHOD_NAME + "MQ Param: \nhost:" + host
						+ "\nport:" + port + "\nchannel:" + channel
						+ "\nqueue_manager:" + queueManager + "\ntype:" + type
						+ "\npubQueName:" + queName);
			}

			QueueConnectionFactory connectionFactory = new MQQueueConnectionFactory();
		    ((MQQueueConnectionFactory) connectionFactory).setHostName(host);
		    ((MQQueueConnectionFactory) connectionFactory).setPort(port);
		    ((MQQueueConnectionFactory) connectionFactory).setChannel(channel);
		    ((MQQueueConnectionFactory) connectionFactory).setQueueManager(queueManager);
		    ((MQQueueConnectionFactory) connectionFactory).setTransportType(type);
		    
		    connection = connectionFactory.createQueueConnection();
		    connection.start();
		     
		    session = connection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
		    Queue queue = session.createQueue(queName);
		    
		    messageProducer = session.createSender(queue);
		    TextMessage textMessage = session.createTextMessage(message);
		    
		    messageProducer.send(textMessage);
		    
		    if (_logger.isInfoEnabled()) {
			_logger.info(METHOD_NAME + "GCH msg sent: " + textMessage.getText());
		    }
		    
		   
		} catch (Exception e) {
			_logger.error(METHOD_NAME
							+ ":Failed to connect or send message from GCHCLIN :"
							+ e);
			throw e;
		}finally{
			_logger.info(METHOD_NAME + ":Closing session & connection");
			JmsHelper.close(messageProducer, session, connection);
		}
	}
}