package com.vz.gchclin.common.dataobject;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;


import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Clins implements Serializable {
	
	private String clin;
	private String clinDescription;
	private String chargeType;
	
	public String getClin() {
		return clin;
	}
	public void setClin(String clin) {
		this.clin = clin;
	}
	public String getClinDescription() {
		return clinDescription;
	}
	public void setClinDescription(String clinDescription) {
		this.clinDescription = clinDescription;
	}
	public String getChargeType() {
		return chargeType;
	}
	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}
	
	
	public String toString(){
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
	
	
}