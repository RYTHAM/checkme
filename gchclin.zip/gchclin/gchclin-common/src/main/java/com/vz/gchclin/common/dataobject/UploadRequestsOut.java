package com.vz.gchclin.common.dataobject;

import java.io.IOException;
import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.vz.gchclin.common.dataobject.UploadRecord;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class UploadRequestsOut extends BaseOutput implements Serializable {

	private static final long serialVersionUID = -1004673134535775780L;

	private Integer position = 0;
	private Integer amount;
	private Integer noOfRowsReturn;
	private long totalRows;
	private List<UploadRecord> requests;

	public Integer getPosition() {
		return position;
	}

	public void setPosition(Integer position) {
		this.position = position;
	}

	public Integer getAmount() {
		return amount;
	}

	public void setAmount(Integer amount) {
		this.amount = amount;
	}

	public Integer getNoOfRowsReturn() {
		return noOfRowsReturn;
	}

	public void setNoOfRowsReturn(Integer noOfRowsReturn) {
		this.noOfRowsReturn = noOfRowsReturn;
	}

	public long getTotalRows() {
		return totalRows;
	}

	public void setTotalRows(long totalRows) {
		this.totalRows = totalRows;
	}

	public List<UploadRecord> getRequests() {
		return requests;
	}

	public void setRequests(List<UploadRecord> requests) {
		this.requests = requests;
	}

	private void writeObject(java.io.ObjectOutputStream out) throws IOException {
		out.defaultWriteObject();
	}

	private void readObject(java.io.ObjectInputStream in) throws IOException,
			ClassNotFoundException {
		in.defaultReadObject();
	}

}
