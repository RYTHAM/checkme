package com.vz.gchclin.common.dataobject;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;


import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ContractDetails implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String contractID;
/*	private String participatingAgreement;*/
	private String customerRequestNumber;
	private String customerRequestVersion;
	
	
	
	public String getContractID() {
		return contractID;
	}
	public void setContractID(String contractID) {
		this.contractID = contractID;
	}
	/*public String getParticipatingAgreement() {
		return participatingAgreement;
	}
	public void setParticipatingAgreement(String participatingAgreement) {
		this.participatingAgreement = participatingAgreement;
	}*/
	public String getCustomerRequestNumber() {
		return customerRequestNumber;
	}
	public void setCustomerRequestNumber(String customerRequestNumber) {
		this.customerRequestNumber = customerRequestNumber;
	}
	public String getCustomerRequestVersion() {
		return customerRequestVersion;
	}
	public void setCustomerRequestVersion(String customerRequestVersion) {
		this.customerRequestVersion = customerRequestVersion;
	}
	
	public String toString(){
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
	
}