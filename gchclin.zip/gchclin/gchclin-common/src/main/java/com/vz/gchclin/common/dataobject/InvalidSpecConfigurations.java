package com.vz.gchclin.common.dataobject;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import java.io.*;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class InvalidSpecConfigurations implements Serializable {
	
	
	private String chargeType;
	private List<SpecConfigurations> specConfigurations;
	

	public String getChargeType() {
		return chargeType;
	}
	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}
	public List<SpecConfigurations> getSpecConfigurations() {
		return specConfigurations;
	}
	public void setSpecConfigurations(List<SpecConfigurations> specConfigurations) {
		this.specConfigurations = specConfigurations;
	}
	
	public String toString(){
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
	
	 private void writeObject(ObjectOutputStream stream)
	            throws IOException {
	        stream.defaultWriteObject();
	    }

	    private void readObject(ObjectInputStream stream)
	            throws IOException, ClassNotFoundException {
	        stream.defaultReadObject();
	    }
	
}