package com.vz.gchclin.common.dataobject;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;
//@XmlRootElement
public class BaseOutput implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private String responseCode;
	private String responseText;
	private boolean success;
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseText() {
		return responseText;
	}
	public void setResponseText(String responseText) {
		this.responseText = responseText;
	}
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	
	

}
