package com.vz.gchclin.common.util;

import javax.annotation.Resource;
import javax.sql.DataSource;

public class BaseDao{
	
    @Resource(name = "com.vz.gch.clin.read.ds")
    protected DataSource clinDataSourceRead;
    @Resource(name = "com.vz.gch.clin.write.ds")
    protected DataSource clinDataSourceWrite;
    
}