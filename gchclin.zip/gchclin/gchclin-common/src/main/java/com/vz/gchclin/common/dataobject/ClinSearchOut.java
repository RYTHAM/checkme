package com.vz.gchclin.common.dataobject;

import java.io.Serializable;
import java.util.List;


import java.io.*;
import com.vz.gchclin.common.dataobject.ClinRecord;

public class ClinSearchOut extends BaseOutput implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer position=0;	
	private Integer noOfRowsReturn;
	private long totalRows;
	private List<ClinRecord> clinList;
	public Integer getPosition() {
		return position;
	}
	public void setPosition(Integer position) {
		this.position = position;
	}
	public Integer getNoOfRowsReturn() {
		return noOfRowsReturn;
	}
	public void setNoOfRowsReturn(Integer noOfRowsReturn) {
		this.noOfRowsReturn = noOfRowsReturn;
	}
	public long getTotalRows() {
		return totalRows;
	}
	public void setTotalRows(long totalRows) {
		this.totalRows = totalRows;
	}
	public List<ClinRecord> getClinList() {
		return clinList;
	}
	public void setClinList(List<ClinRecord> clinList) {
		this.clinList = clinList;
	}
	
	
	 private void writeObject(ObjectOutputStream stream)
	            throws IOException {
	        stream.defaultWriteObject();
	    }

	    private void readObject(ObjectInputStream stream)
	            throws IOException, ClassNotFoundException {
	        stream.defaultReadObject();
	    }
	
}
