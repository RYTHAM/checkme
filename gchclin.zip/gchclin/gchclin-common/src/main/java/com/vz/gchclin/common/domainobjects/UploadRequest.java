package com.vz.gchclin.common.domainobjects;
   
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.SequenceGenerator;

import java.util.Date;

@Entity
@Table(name = "CLIN.CLIN_UPLOAD_REQUEST")
@NamedQueries({
      @NamedQuery(name = "getRequestsByPerson", query = "SELECT r.uploadRequestId ,r.requester,r.contractId,r.status,r.processFlag,r.startTime,r.endTime FROM UploadRequest r WHERE r.requester = ?1 ORDER BY r.uploadRequestId DESC"),
      @NamedQuery(name = "getReportById", query = "SELECT r.outputFile FROM UploadRequest r WHERE r.uploadRequestId = ?1  ") })
// need to be changed outputFile
public class UploadRequest implements Serializable {

   /**
    * 
    */
   private static final long serialVersionUID = 2444324258370342670L;

   @SequenceGenerator(name = "CLIN_UPLOAD_REQUEST_Gen", sequenceName = "CLIN.CLIN_UPLOAD_REQUEST_SEQ", allocationSize = 1)
   @Id
   @GeneratedValue(generator = "CLIN_UPLOAD_REQUEST_Gen")
   @Column(name = "CLIN_UPLOAD_REQUEST_OID")
   private Long uploadRequestId;
   @Column(name = "CONTRACT_ID")
   private String contractId;
   @Column(name = "INPUT_FILE_CONTENT")
   private String inputfile;
   @Column(name = "REQUESTER")
   String requester;
   @Column(name = "PROCESS_FLAG")
   private char processFlag;
   @Column(name = "STATUS")
   private char status;
   @Column(name = "USER_ID")
   private String userId;
   @Column(name = "MODIFIED_DATE")
   @Temporal(TemporalType.TIMESTAMP)
   private Date timeStamp;
   @Column(name = "START_UPLOAD_TS")
   @Temporal(TemporalType.TIMESTAMP)
   private Date startTime;
   @Column(name = "END_UPLOAD_TS")
   @Temporal(TemporalType.TIMESTAMP)
   private Date endTime;
   @Column(name = "OUTPUT_FILE_CONTENT")
   private String outputFile;

   public UploadRequest() {

   }

   public Long getUploadRequestId() {
      return uploadRequestId;
   }

   public void setUploadRequestId(Long uploadRequestId) {
      this.uploadRequestId = uploadRequestId;
   }

   public String getContractId() {
      return contractId;
   }

   public void setContractId(String contractId) {
      this.contractId = contractId;
   }

   public String getInputfile() {
      return inputfile;
   }

   public void setInputfile(String inputfile) {
      this.inputfile = inputfile;
   }

   public String getRequester() {
      return requester;
   }

   public void setRequester(String requester) {
      this.requester = requester;
   }

   public char getStatus() {
      return status;
   }

   public void setStatus(char status) {
      this.status = status;
   }

   public Date getStartTime() {
      return startTime;
   }

   public void setStartTime(Date startTime) {
      this.startTime = startTime;
   }

   public Date getEndTime() {
      return endTime;
   }

   public void setEndTime(Date endTime) {
      this.endTime = endTime;
   }

   public String getOutputFile() {
      return outputFile;
   }

   public void setOutputFile(String outputFile) {
      this.outputFile = outputFile;
   }

   public char getProcessFlag() {
      return processFlag;
   }

   public void setProcessFlag(char processFlag) {
      this.processFlag = processFlag;
   }

   public String getUserId() {
      return userId;
   }

   public void setUserId(String userId) {
      this.userId = userId;
   }

   public Date getTimeStamp() {
      return timeStamp;
   }

   public void setTimeStamp(Date timeStamp) {
      this.timeStamp = timeStamp;
   }

   @Override
   public String toString() {
      return "UploadRequest [uploadRequestId=" + uploadRequestId
            + ", contractId=" + contractId + ", requester=" + requester
            + ", status=" + status + ", startTime=" + startTime
            + ", endTime=" + endTime + "]";
   }

}
