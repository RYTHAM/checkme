package com.vz.gchclin.common.util;

import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import com.vz.gchclin.common.util.EIBMessageSender;

public class EIBMessageSenderTest {

	@Before
	public void beforeTest() {
		System.out.println("BEFORE TEST");

	}

	@Test
	public void sendMessageTest() {
		try{
		
			EIBMessageSender p = new EIBMessageSender();
	
			p.setHost("eibsit.verizon.com");
			p.setChannel("EIB.GCHCLIN.SVRCONN");
			p.setPort(Integer.parseInt("2411"));
			p.setType(1);
			p.setQueName("EIB.MULTI.GCHCLIN.CLINLIST.ASYNC.DG");
			p.setQueueManager("EIBSITA");
			p.setMessage("message");
			
			System.out.println("Details are ::" + p.getHost() + ", " + p.getChannel() + ", "  + p.getPort() + ", "  + p.getType() + ", "  + p.getQueName() + ", " +  p.getQueueManager() + ", "  + p.getMessage());
			p.sendMessage();
			
			System.out.println("Message posted Success fully..");
		}catch(Exception e){
			
		}
	}

	@After
	public void afterTest() {
		System.out.println("AFTER TEST");

	}

}