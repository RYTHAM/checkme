package com.vz.gchclin.common.util;

import javax.persistence.*;

import com.vz.gchclin.common.dataobject.UploadRequestsOut;

import org.junit.Before;
import org.junit.After;
import org.junit.Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ws.rs.core.HttpHeaders;
import javax.sql.DataSource;

import com.vz.gchclin.common.util.Utility;
import com.vz.gchclin.common.util.DbConnectionUtils;
import com.vz.gchclin.common.dataobject.ClinRecord;
import com.vz.gchclin.common.dataobject.ClinSearchIn;
import com.vz.gchclin.common.dataobject.UploadRequestsIn;
import com.vz.gchclin.common.dataobject.UploadRecord;
import com.vz.gchclin.common.dataobject.ClinSearchOut;
import com.vz.gchclin.common.domainobjects.UploadRequest;

public class UtilityTest {

	EntityManager manager;
	Connection jdbcConnection;

	String url = "jdbc:oracle:thin:@uiiscdd1scan.ebiz.verizon.com:1800/DGCHDBB";
	String usr = "clinapp";
	String pwd = "!1clinapp";

	@Before
	public void beforeTest() {
		System.out.println("BEFORE TEST");
		try {
			Class driverClass = Class.forName("oracle.jdbc.OracleDriver");
			jdbcConnection = DriverManager.getConnection(url, usr, pwd);
		} catch (Exception e) {
		}

	}

	@Test
	public void closeDBObjects() {
		System.out.println("closeDBObjects START");
		try {
			Statement stmt = jdbcConnection.createStatement();
			String SQL = "select count * from clin.clin";
			PreparedStatement pstmt = jdbcConnection.prepareStatement(SQL);

			DbConnectionUtils.closeDBObjects(jdbcConnection, stmt, null);
			DbConnectionUtils.closeDBObjects(jdbcConnection, pstmt, null);
		} catch (Exception e) {
			System.out.println("closeDBObjects EXCEPTION1");
		}
		System.out.println("closeDBObjects COMPLETED");
	}

	/*
	 * @Test public void getHeaderValuesTest() { HttpHeaders headers = null; //
	 * headers.setRequestHeader("ITWB_Subscriber_Appname","GCH"); System.out
	 * .println("Header value-->" + Utility.getHeaderValues(headers)); }
	 */

	@Test
	public void ploadRequest() {
		UploadRequest req = new UploadRequest();
		req.setContractId("contractId");
		Date endTime = new Date();
		req.setEndTime(endTime);
		req.setInputfile("AAAAAAAAAAAAAAAAAAAAAAAAA");
		req.setOutputFile("OUTPUT");
		req.setProcessFlag('P');
		req.setRequester("SIDDAIAH POLU");
		req.setStartTime(endTime);
		req.setStatus('I');
		req.setTimeStamp(endTime);
		req.setUploadRequestId(1001L);
		req.setUserId("v43xxxx");
		System.out.println(req.toString());
		System.out.println("OUTPUT::" + req.getContractId()
				+ req.getInputfile().length() + req.getOutputFile()
				+ req.getProcessFlag() + req.getRequester() + req.getStatus()
				+ req.getUserId() + req.getUploadRequestId() + req.getEndTime()
				+ req.getStartTime() + req.getTimeStamp());
	}

	@Test
	public void clinSearchIn() {
		ClinSearchIn in = new ClinSearchIn();
		in.setAsc(true);
		in.setClinId("sidd");
		in.setClinDesc("Siddaiah");
		in.setContractId("50019");
		in.setPageSize(10);
		in.setSortBy("CLINID");
		in.setStartRow(0);
		System.out.println(in.getClinId() + in.getClinDesc()
				+ in.getContractId() + in.getPageSize() + in.getSortBy()
				+ in.getStartRow() + in.getSortBy());
	}

	@Test
	public void ClinSearchOut() {
		System.out.println("ClinSearchOutClinSearchOut");
		ClinSearchOut out = new ClinSearchOut();
		List<ClinRecord> clinList = new ArrayList<ClinRecord>();
		ClinRecord rec = new ClinRecord();
		rec.setChargeType("MRE NRE");
		rec.setClinDesc("clinDesc");
		rec.setClinId("clinId");
		rec.setContractId("contract");
		rec.setEffectiveFrom("20132707");
		rec.setEffectiveUntil("20131212");
		rec.setFeatureCode("FC1");
		rec.setLastUpdateDate("06272016");
		rec.setProductCode("PC");
		rec.setProductGroupCode("PGC");
		rec.setSolutionCode("SC");
		rec.setSpecCode1("SPECCODE");
		rec.setSpecCode2("SPECCODE");
		rec.setSpecCode3("SPECCODE");
		rec.setSpecCode4("SPECCODE");
		rec.setSpecCode5("SPECCODE");
		rec.setSpecCode6("SPECCODE");
		rec.setSpecCode7("SPECCODE");
		rec.setSpecCode8("SPECCODE");
		rec.setSpecCode8("SPECCODE");
		rec.setSpecCode9("SPECCODE9");
		rec.setSpecCode10("SPECCODE");
		rec.setSpecCode11("SPECCODE");
		rec.setSpecCode12("SPECCODE");
		rec.setSpecCode13("SPECCODE");
		rec.setSpecCode14("SPECCODE");
		rec.setSpecCode15("SPECCODE");
		rec.setSpecCode16("SPECCODE");
		rec.setSpecValue1("SPECVAL");
		rec.setSpecValue1("SPECVAL");
		rec.setSpecValue2("SPECVAL");
		rec.setSpecValue3("3SPECVAL");
		rec.setSpecValue4("S4PECVAL");
		rec.setSpecValue5("SP5ECVAL");
		rec.setSpecValue6("SPE6CVAL");
		rec.setSpecValue7("SPEC7VAL");
		rec.setSpecValue8("SPECV8AL");
		rec.setSpecValue9("SPECVA9L");
		rec.setSpecValue10("SPECVAL");
		rec.setSpecValue11("SPECVAL");
		rec.setSpecValue12("SPECVAL");
		rec.setSpecValue13("SPECVAL");
		rec.setSpecValue14("SPECVAL");
		rec.setSpecValue15("SPECVAL");
		rec.setSpecValue16("SPECVAL");
		clinList.add(rec);
		out.setClinList(clinList);
		out.setNoOfRowsReturn(120);
		out.setPosition(1);
		out.setResponseCode("000");
		out.setResponseText("SUCCESS");
		out.setTotalRows(1);
		System.out.println(out.getResponseCode() + out.getResponseText()
				+ out.getTotalRows() + out.getNoOfRowsReturn()
				+ out.getPosition() + out.getClinList().size());
		ClinRecord r = out.getClinList().get(0);
		System.out.println(r.getChargeType() + r.getClinDesc() + r.getClinId()
				+ r.getContractId() + r.getEffectiveFrom()
				+ r.getEffectiveUntil() + r.getLastUpdateDate()
				+ r.getProductCode() + r.getProductGroupCode()
				+ r.getFeatureCode() + r.getSolutionCode() + r.getSpecCode1()
				+ r.getSpecValue1() + r.getSpecCode2() + r.getSpecValue2()
				+ r.getSpecCode3() + r.getSpecValue3() + r.getSpecCode4()
				+ r.getSpecValue4() + r.getSpecCode5() + r.getSpecValue5()
				+ r.getSpecCode6() + r.getSpecValue6() + r.getSpecCode7()
				+ r.getSpecValue7() + r.getSpecCode8() + r.getSpecValue8()
				+ r.getSpecCode9() + r.getSpecValue9() + r.getSpecCode10()
				+ r.getSpecValue10() + r.getSpecCode11() + r.getSpecValue11()
				+ r.getSpecCode12() + r.getSpecValue12() + r.getSpecCode13()
				+ r.getSpecValue13() + r.getSpecCode14() + r.getSpecValue14()
				+ r.getSpecCode15() + r.getSpecValue15() + r.getSpecCode16()
				+ r.getSpecValue16());
		System.out
				.println("ClinSearchOutClinSearchOutvClinSearchOutClinSearchOutendssssss");
	}

	@Test
	public void UploadRequestsOut() {
		System.out.println("UploadRequestsOutUploadRequestsOut END");
		UploadRequestsOut out = new UploadRequestsOut();
		out.setAmount(100);
		out.setNoOfRowsReturn(50);
		out.setPosition(10);
		out.setResponseCode("000");
		out.setResponseText("hai siddaiah");
		out.setSuccess(true);
		out.setTotalRows(74);
		List<UploadRecord> requests = new ArrayList<UploadRecord>();
		UploadRecord r = new UploadRecord();
		r.setContractId("testcontract");
		r.setProcessFlag("Y");
		r.setRequester("SIDDAIAH");
		r.setStatus("Y OR N");
		r.setUploadRequestId(15L);
		r.setStartTime("123456");
		r.setEndTime("78910");
		r.setErrorMsg("WORK IN PROGRESS..");
		requests.add(r);
		requests.add(r);
		out.setRequests(requests);
		List<UploadRecord> result = out.getRequests();
		System.out.println(out.getAmount() + out.getNoOfRowsReturn()
				+ out.getPosition() + out.getTotalRows());
		UploadRecord row1 = result.get(0);
		System.out.println("UploadRecord::" + row1.getContractId()
				+ row1.getEndTime() + row1.getErrorMsg()
				+ row1.getProcessFlag() + row1.getRequester()
				+ row1.getStartTime() + row1.getStatus() + row1.getTimeStamp()
				+ row1.getUploadRequestId());
		System.out.println("UploadRequestsOutUploadRequestsOut END");
	}

	@Test
	public void uploadRecord() {
		System.out.println("UploadRecord UploadRecord ");
		UploadRecord r = new UploadRecord();
		r.setContractId("testcontract");
		r.setProcessFlag("Y");
		r.setRequester("SIDDAIAH");
		r.setStatus("Y OR N");
		r.setUploadRequestId(15L);
		r.setStartTime("123456");
		r.setEndTime("78910");
		r.setTimeStamp("19051985");
		r.setErrorMsg("WORK IN PROGRESS..");
		System.out.println("UploadRecord::" + r.getContractId()
				+ r.getEndTime() + r.getErrorMsg() + r.getProcessFlag()
				+ r.getRequester() + r.getStartTime() + r.getStatus()
				+ r.getTimeStamp() + r.getUploadRequestId());
	}

	@Test
	public void uploadRequestsIn() {
		System.out.println("uploadRequestsInuploadRequestsIn");
		UploadRequestsIn in = new UploadRequestsIn();
		in.setStartRow(0);
		in.setPageSize(10);
		in.setRequester("v436645");
		System.out.println(in.getStartRow() + in.getPageSize()
				+ in.getRequester());

	}

	@Test
	public void getConnection() {/*
		try {
			DbConnectionUtils.getConnection("W");
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			DbConnectionUtils.getConnection("R");
		} catch (Exception e) {
			e.printStackTrace();
		}
		DataSource ds = null;
		try {
			System.out.println("getConnection"
					+ DbConnectionUtils.getConnection(ds));
		} catch (Exception e) {
			e.printStackTrace();
		}

	*/}

	public void effectiveDateTest() {

		System.out.println("effectiveDate value-->"
				+ Utility.effectiveDate("test_table"));
	}

	@Test
	public void getSpecCodesbyFeatureCodeTest() {
		System.out.println("getSpecCodesbyFeatureCodeTest() start :::");
		manager = Persistence.createEntityManagerFactory("clinEjbPUTestRead")
				.createEntityManager();
		System.out.println("ENTITY CREATED");
		int cnt = Utility.getSpecCodesbyFeatureCode(manager, "FET_LA").size();
		System.out.println("no of specs are " + cnt);
		System.out.println("getSpecCodesbyFeatureCodeTest() end :::");
	}

	/*
	 * @Test public void getOidTest(){ manager =
	 * Persistence.createEntityManagerFactory
	 * ("clinEjbPUTestRead").createEntityManager(); Utility.getOid(manager,
	 * "PROD_LINE_ITEM");
	 * 
	 * }
	 */

	@After
	public void afterTest() {
		System.out.println("AFTER TEST");

	}

}
