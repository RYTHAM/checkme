package com.vz.gchclin.common.util;

import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import com.vz.gchclin.common.util.GCHClinRequestException;

public class GCHClinRequestExceptionTest {

	@Before
	public void beforeTest() {
		System.out.println("GCHClinRequestExceptionTest BEFORE TEST");

	}

	@Test
	public void constructorTest() {
		new GCHClinRequestException("error parsing: " , new Exception());
		new GCHClinRequestException("error parsing: " );
	}

	@After
	public void afterTest() {
		System.out.println(" GCHClinRequestExceptionTestAFTER TEST");

	}

}