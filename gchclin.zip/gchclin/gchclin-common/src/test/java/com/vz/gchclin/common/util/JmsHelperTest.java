package com.vz.gchclin.common.util;

import javax.jms.Session;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import com.ibm.mq.jms.MQQueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import com.vz.gchclin.common.util.JmsHelper;

public class JmsHelperTest {

	@Before
	public void beforeTest() {
		System.out.println("BEFORE TEST");

	}

	@Test
	public void closeTest() {
		try {
			QueueConnectionFactory connectionFactory = new MQQueueConnectionFactory();
			QueueConnection connection = connectionFactory
					.createQueueConnection();
			connection.start();

			QueueSession session = connection.createQueueSession(false,
					Session.AUTO_ACKNOWLEDGE);
			Queue queue = session
					.createQueue("EIB.MULTI.GCHCLIN.CLINLIST.ASYNC.DG");

			QueueSender messageProducer = session.createSender(queue);
			JmsHelper.close(messageProducer, session, connection);
		} catch (Exception e) {

		}
	}

	@After
	public void afterTest() {
		System.out.println("AFTER TEST");

	}

}