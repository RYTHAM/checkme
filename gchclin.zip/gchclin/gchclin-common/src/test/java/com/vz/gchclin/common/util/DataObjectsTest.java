package com.vz.gchclin.common.util;

import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import java.util.List;
import java.util.ArrayList;
import com.vz.gchclin.common.dataobject.*;
import com.vz.gchclin.common.ldap.LdapUserData;
import com.vz.gchclin.common.domainobjects.Clin;
import java.util.Date;


public class DataObjectsTest {

	@Before
	public void beforeTest() {
		System.out.println(" DataObjectsTest BEFORE TEST");

	}

	@Test
	public void getClinListInTest() {
		GetClinListIn inObj = new GetClinListIn();
		inObj.setClientId("PQ");
		inObj.setTransactionID("1234");
		ContractDetails conObj = new ContractDetails();
		conObj.setContractID("J576-00");
		conObj.setCustomerRequestNumber("setCustomerRequestNumber");
		conObj.setCustomerRequestVersion("0");
		System.out.println("Contract input obj is " + conObj.getContractID() +" ," + conObj.getCustomerRequestNumber() + " ," + conObj.getCustomerRequestVersion());
		System.out.println(conObj.toString());
		
		inObj.setContractDetails(conObj);
		
		
		LdapUserData userData = new LdapUserData();
		userData.setUserId("userId");
		userData.seteId("eId");
		List<String> gsamLevlsList = new ArrayList<String>();
		gsamLevlsList.add("8");
		userData.setGsamLevels(gsamLevlsList);
		List<String> translatedGsamInfoList = new ArrayList<String>();
		translatedGsamInfoList.add("ss");
		userData.setTranslatedGsamInfo(translatedGsamInfoList);
		userData.setIsAvailable(true);
		
		System.out.println("LdapUserData ::" + userData.getUserId() + ", " + ", " + userData.geteId()+ ", " + userData.getGsamLevels() + ", "+ userData.getTranslatedGsamInfo() + ", "+ userData.getIsAvailable());
		
		System.out.println(userData.toString());
		
		inObj.setUserData(userData);
	
		
		List<ProductConfigurations> productConfigurationsList = new ArrayList<ProductConfigurations>();
	 
		List<FeatureConfigurations> featureConfigurationsList = new ArrayList<FeatureConfigurations>();
		
		List<SpecConfigurations> specConfigurationsList  = new ArrayList<SpecConfigurations>();
		SpecConfigurations specConfigurations = new SpecConfigurations();
		specConfigurations.setCode("code");
		specConfigurations.setValue("value");
		specConfigurationsList.add(specConfigurations);
		
		System.out.println(specConfigurations.toString());
		System.out.println("specConfigurations " + specConfigurations.getCode() + ", " + specConfigurations.getValue() );
		
		FeatureBaseConfigurations featureBaseConfigurations = new FeatureBaseConfigurations();
		FeatureConfigurations featureConfigurations = new FeatureConfigurations();
		
		featureBaseConfigurations.setFeatureCode("featureCode");
		featureBaseConfigurations.setFeatureInstanceID("featureInstanceID");
		System.out.println(featureBaseConfigurations.toString());
		System.out.println("featureBaseConfigurations " + featureBaseConfigurations.getFeatureCode() + ", " + featureBaseConfigurations.getFeatureInstanceID());
		featureConfigurations.setChargeType("chargeType");
		featureConfigurations.setFeatureBaseConfigurations(featureBaseConfigurations);
		
		featureConfigurations.setSpecConfigurations(specConfigurationsList);
		System.out.println(featureConfigurations.toString());
		System.out.println(featureConfigurations.getChargeType() + ", " + featureConfigurations.getFeatureBaseConfigurations() + ", " + featureConfigurations.getSpecConfigurations());
		featureConfigurationsList.add(featureConfigurations);
		
		
		ProductConfigurations productConfigurations = new ProductConfigurations();
		ProductBaseConfigurations productBaseConfigurations = new ProductBaseConfigurations();
		
		productBaseConfigurations.setSolutionCode("solutionCode");
		productBaseConfigurations.setProductGroup("productGroup");
		productBaseConfigurations.setProductCode("productCode");
		
		System.out.println(productBaseConfigurations.toString());
		System.out.println("productBaseConfigurations" + productBaseConfigurations.getSolutionCode() + ", " + productBaseConfigurations.getProductGroup() + ", " + productBaseConfigurations.getProductCode());
		
		
			productConfigurations.setProductBaseConfigurations(productBaseConfigurations);
			productConfigurations.setFeatureConfigurations(featureConfigurationsList);
			System.out.println(productConfigurations.toString());
			System.out.println(productConfigurations.getProductBaseConfigurations());
			System.out.println(productConfigurations.getFeatureConfigurations());
			productConfigurationsList.add(productConfigurations);
		
			inObj.setProductConfigurations(productConfigurationsList);
			
		System.out.println(inObj.getTransactionID() + inObj.getContractDetails() + inObj.getProductConfigurations() + inObj.getUserData() + inObj.getClientId() );
		System.out.println(inObj.toString());
	}
		
	
	@Test
	public void getClinListOutTest() {
		GetClinListOut out = new GetClinListOut();
		out.setTransactionID("1");
		
		ContractDetails conObj = new ContractDetails();
		conObj.setContractID("J576-00");
		conObj.setCustomerRequestNumber("setCustomerRequestNumber");
		conObj.setCustomerRequestVersion("0");
		System.out.println("Contract input obj is " + conObj.getContractID() +" ," + conObj.getCustomerRequestNumber() + " ," + conObj.getCustomerRequestVersion());
		System.out.println(conObj.toString());
		
		out.setContractDetails(conObj);
		out.setErrorMessage("no error");
		
		List<ProductConfigurationResponse> resList = new ArrayList<ProductConfigurationResponse>();
		ProductConfigurationResponse resObj = new ProductConfigurationResponse();
		
		ProductBaseConfigurations productBaseConfigurations = new ProductBaseConfigurations();
		productBaseConfigurations.setSolutionCode("solutionCode");
		productBaseConfigurations.setProductGroup("productGroup");
		productBaseConfigurations.setProductCode("productCode");
		
		resObj.setProductBaseConfigurations(productBaseConfigurations);
		
		System.out.println(productBaseConfigurations.toString());
		System.out.println("productBaseConfigurations" + productBaseConfigurations.getSolutionCode() + ", " + productBaseConfigurations.getProductGroup() + ", " + productBaseConfigurations.getProductCode());
		
		List<FeatureConfigurationResponse> fetResList = new ArrayList<FeatureConfigurationResponse>();
		
		FeatureConfigurationResponse fetResObj = new FeatureConfigurationResponse();
		FeatureBaseConfigurations featureBaseConfigurations = new FeatureBaseConfigurations();
		featureBaseConfigurations.setFeatureCode("featureCode");
		featureBaseConfigurations.setFeatureInstanceID("featureInstanceID");
		System.out.println(featureBaseConfigurations.toString());
		System.out.println("featureBaseConfigurations " + featureBaseConfigurations.getFeatureCode() + ", " + featureBaseConfigurations.getFeatureInstanceID());
		
		fetResObj.setFeatureBaseConfigurations(featureBaseConfigurations);
		
		List<Clins> clinList = new ArrayList<Clins>();
		Clins clinsObj = new Clins();
		clinsObj.setClin("clin");
		clinsObj.setClinDescription("clin.getClinDesc()");
		clinsObj.setChargeType("REC");
		System.out.println(clinsObj.toString());
		System.out.println(clinsObj.getClin() +" " + clinsObj.getClinDescription() +" " + clinsObj.getChargeType());
		clinList.add(clinsObj);
		
		fetResObj.setClins(clinList);
		
		ClinError clinErrorObj = new ClinError();
		clinErrorObj.setClinErrorCode("008");
		clinErrorObj.setClinErrorDescription("No CLIN found for billable feature ");
		InvalidSpecConfigurations invalidSpecConfigurationsRes = new InvalidSpecConfigurations();
		invalidSpecConfigurationsRes.setChargeType("REC");
		List<SpecConfigurations> specConfigurationsList  = new ArrayList<SpecConfigurations>();
		SpecConfigurations specConfigurations = new SpecConfigurations();
		specConfigurations.setCode("code");
		specConfigurations.setValue("value");
		specConfigurationsList.add(specConfigurations);
		
		System.out.println(specConfigurations.toString());
		System.out.println("specConfigurations " + specConfigurations.getCode() + ", " + specConfigurations.getValue() );
		invalidSpecConfigurationsRes.setSpecConfigurations(specConfigurationsList);
		System.out.println(invalidSpecConfigurationsRes.getChargeType() + " " +invalidSpecConfigurationsRes.getSpecConfigurations());
		System.out.println(invalidSpecConfigurationsRes.toString());
		
		System.out.println(clinErrorObj.toString());
		System.out.println(clinErrorObj.getClinErrorCode() + " " +clinErrorObj.getClinErrorDescription() + " " +clinErrorObj.getInvalidSpecConfigurations());
		
		clinErrorObj.setInvalidSpecConfigurations(invalidSpecConfigurationsRes);
		
		fetResObj.setClinError(clinErrorObj);
		System.out.println(fetResObj.toString());
		System.out.println(fetResObj.getClins() + " " +fetResObj.getClinError() + " " +fetResObj.getFeatureBaseConfigurations());
		
		fetResList.add(fetResObj);
		resObj.setFeatureConfigurationResponse(fetResList);
		
		System.out.println(resObj.toString());
		
		System.out.println(resObj.getFeatureConfigurationResponse() + "" + resObj.getProductBaseConfigurations() );
		resList.add(resObj);
		out.setProductConfigurationResponse(resList); 
		
		System.out.println(out.getTransactionID() + " " + out.getContractDetails() + " " + out.getProductConfigurationResponse() + " " + out.getErrorMessage());
		System.out.println(out.toString());
		
		Clin c = new Clin();
		c.setClinOid(1L);
		c.setClinId("AA00123");
		c.setClinDesc("clin_desc");
		c.setChargeType("NRE");
		c.setUserId("v473725");
		c.setTimeStamp(new Date());
		c.setStartDate(new Date());
		c.setEndDate(new Date());
		
		System.out.println(c.toString());
		
		System.out.println("Clin is " + c.getClinOid()+ ", " + c.getClinId()+ ", " + c.getClinDesc()+ ", "+ c.getChargeType()+ ", " +c.getUserId()+ ", " + c.getTimeStamp()+ ", " +  c.getStartDate()+ ", " + c.getEndDate());
		
		GchClinOut obj = new GchClinOut();
		obj.setTransactionCode("000");
		obj.setTransactionStatus("Success");
		System.out.println("OUTOBJ :::" + obj.getTransactionCode()+ ", " + obj.getTransactionStatus() + "," + obj.toString() );
		
			
	}

	

	@After
	public void afterTest() {
		System.out.println(" DataObjectsTest AFTER TEST");

	}

}