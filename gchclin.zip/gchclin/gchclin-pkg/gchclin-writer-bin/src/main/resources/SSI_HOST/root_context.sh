# QA 
gchsc1lna001=gchqa1.ebiz.verizon.com
gchsc1lna002=gchqa1.ebiz.verizon.com

gchsc1lna003=gchqa2.ebiz.verizon.com
gchsc1lna004=gchqa2.ebiz.verizon.com

gchsc1lna043=gchqa3.ebiz.verizon.com
gchsc1lna044=gchqa3.ebiz.verizon.com

gchsc1lna045=gchqa4.ebiz.verizon.com
gchsc1lna046=gchqa4.ebiz.verizon.com

# UAT
gchsc1lna005=gchuat1.ebiz.verizon.com
gchsc1lna006=gchuat1.ebiz.verizon.com

gchsc1lna007=gchuat2.ebiz.verizon.com
gchsc1lna008=gchuat2.ebiz.verizon.com

# Prod
gchfdpa5=gchclin.verizon.com
gchfdpa6=gchclin.verizon.com
gchfdpa7=gchclin.verizon.com
gchfdpa8=gchclin.verizon.com

# DR
gchscpa5=gchclin.verizon.com
gchscpa6=gchclin.verizon.com
gchscpa7=gchclin.verizon.com
gchscpa8=gchclin.verizon.com