package com.vz.gchclin.ws.rs.update.external;

import java.io.Serializable;

import javax.ejb.Stateless;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
//import com.vz.gchclin.beans.update.ClinUpdateServicesBean;
/**
 * Session Bean implementation class CustomerServicesBean
 */
@Path("/services")
@Stateless
public class ClinUpdateExternalServicesImpl{
	
	/*@EJB(mappedName="ClinUpdateServicesBean")
	ClinUpdateServicesBean clinUpdateServicesBean;*/
	
	@GET
	@Path("/test")
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	public String  test(@QueryParam("name") String name) {
		return name;//clinUpdateServicesBean.test("ClinUpdateExternalServicesImpl-"+name);
	}
	
}
