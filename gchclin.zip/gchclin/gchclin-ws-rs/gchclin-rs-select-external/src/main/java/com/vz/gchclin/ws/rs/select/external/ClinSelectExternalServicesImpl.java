package com.vz.gchclin.ws.rs.select.external;

import java.io.Serializable;

import javax.ejb.Stateless;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import com.vz.gchclin.beans.select.ClinSelectServicesBean;
/**
 * Session Bean implementation class CustomerServicesBean
 */
@Path("/services")
@Stateless
public class ClinSelectExternalServicesImpl{
	
	@EJB
	ClinSelectServicesBean clinSelectServicesBean;
	
	@GET
	@Path("/test")
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	public String  test(@QueryParam("name") String name) {
		int a=11;
		return "ClinSelectExternalServicesImpl-" +name;
	}
	
}
