package com.vz.gchclin.ws.rs.select.internal;


import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import com.vz.gchclin.common.dataobject.GetClinListOut;
import com.vz.gchclin.common.dataobject.UploadRequestsOut;
import com.vz.gchclin.common.dataobject.UploadRequestsIn;
import com.vz.gchclin.common.dataobject.ClinSearchOut;
import com.vz.gchclin.common.dataobject.ClinSearchIn;
import com.vz.gchclin.common.dataobject.ClinRecord;



import com.vz.gchclin.beans.select.ClinSelectServicesBean;

import org.apache.log4j.BasicConfigurator;

@Path("/services")
@Stateless
public class ClinSelectInternalServicesImpl {

	@EJB
	ClinSelectServicesBean clinSelectServicesBean;



	@POST
	@Path("/testPostMQ")
	@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public String testPostMQ(String message) {
		clinSelectServicesBean.testPostMQ(message);
		return "success";
	}

	@POST
	@Path("/testClinResponse")
	@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public GetClinListOut testClinResponse(String message) {
		return clinSelectServicesBean.getClinListOut(message);
		 
	}
	
	@POST
	@Path("/getRequests")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public UploadRequestsOut getRequests(UploadRequestsIn input) {
		return clinSelectServicesBean.getRequests(input);
	}

	
	@POST
	@Path("/search")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public ClinSearchOut search(ClinSearchIn in){		
		return clinSelectServicesBean.search(in);
	}

	@GET
	@Path("/download")
	@Produces("text/csv")
	public Response getFile(@QueryParam("requestId") Long requestId) {

		System.out.println("ENTERD INTO RESPONSE :requestId" + requestId);
		ResponseBuilder rb = Response.ok((Object) clinSelectServicesBean
				.getClobData(requestId));
		rb.header("Content-Disposition",
				"attachment; filename=ProcessedCLIN.csv");
		return rb.build();
	}
	
	@POST
	@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	@Path("/getClinsByContract")
	@Produces("text/csv")
	public Response getClinsByContract(String contractId) {

		System.out.println("ENTERD INTO RESPONSE :requestId" + contractId);
		ClinSearchIn in = new ClinSearchIn();
		in.setStartRow(0);
		in.setPageSize(9999);
		in.setSortBy("clinId");
		in.setAsc(true);
		if (contractId != null) {
			in.setContractId(contractId.trim());
		}
		ClinSearchOut out = clinSelectServicesBean.search(in);
		StringBuilder file = new StringBuilder();
		file.append("CLIN Id,CLIN Description,Charge Type,Contract Id,Effective From,Effective Until,Product Code,Product Group Code,Solution Code,Feature Code,Spec Code 1,Spec Value 1,Spec Code 2,Spec Value 2,Spec Code 3,Spec Value 3,Spec Code 4,Spec Value 4,Spec Code 5,Spec Value 5,Spec Code 5,Spec Value 5,Spec Code 6,Spec Value 6,Spec Code 7,Spec Value 7,Spec Code 8,Spec Value 8,Spec Code 9,Spec Value 9,Spec Code 10,Spec Value 10,Spec Code 11,Spec Value 11,Spec Code 12,Spec Value 12,Spec Code 13,Spec Value 13,Spec Code 14,Spec Value 14,Spec Code 15,Spec Value 15,Spec Code 16,Spec Value 16 \n");
		if (out != null && out.getClinList().size() > 0) {
			for (ClinRecord r : out.getClinList()) {
				file.append(getValue(r.getClinId()) + ","
						+ getValue(r.getClinDesc()) + ","
						+ getValue(r.getChargeType()) + ","
						+ getValue(r.getContractId()) + ","
						+ getValue(r.getEffectiveFrom()) + ","
						+ getValue(r.getEffectiveUntil()) + ","
						+ getValue(r.getProductCode()) + ","
						+ getValue(r.getProductGroupCode()) + ","
						+ getValue(r.getSolutionCode()) + ","
						+ getValue(r.getFeatureCode()) + ","
						+ getValue(r.getSpecCode1()) + ","
						+ getValue(r.getSpecValue1()) + ","
						+ getValue(r.getSpecCode2()) + ","
						+ getValue(r.getSpecValue2()) + ","
						+ getValue(r.getSpecCode3()) + ","
						+ getValue(r.getSpecValue3()) + ","
						+ getValue(r.getSpecCode4()) + ","
						+ getValue(r.getSpecValue4()) + ","
						+ getValue(r.getSpecCode5()) + ","
						+ getValue(r.getSpecValue5()) + ","
						+ getValue(r.getSpecCode6()) + ","
						+ getValue(r.getSpecValue6()) + ","
						+ getValue(r.getSpecCode7()) + ","
						+ getValue(r.getSpecValue7()) + ","
						+ getValue(r.getSpecCode8()) + ","
						+ getValue(r.getSpecValue8()) + ","
						+ getValue(r.getSpecCode9()) + ","
						+ getValue(r.getSpecValue9()) + ","
						+ getValue(r.getSpecCode10()) + ","
						+ getValue(r.getSpecValue10()) + ","
						+ getValue(r.getSpecCode11()) + ","
						+ getValue(r.getSpecValue11()) + ","
						+ getValue(r.getSpecCode12()) + ","
						+ getValue(r.getSpecValue12()) + ","
						+ getValue(r.getSpecCode13()) + ","
						+ getValue(r.getSpecValue13()) + ","
						+ getValue(r.getSpecCode14()) + ","
						+ getValue(r.getSpecValue14()) + ","
						+ getValue(r.getSpecCode15()) + ","
						+ getValue(r.getSpecValue15()) + ","
						+ getValue(r.getSpecCode16()) + ","
						+ getValue(r.getSpecValue16()) + "\n");
			}
		}
		ResponseBuilder rb = Response.ok((Object) file.toString());
		rb.header("Content-Disposition",
				"attachment; filename=CLINSetForContractId_" + getValue(contractId) + ".csv");
		return rb.build();
	}
	
	private String getValue(String value){
		return (value==null)?"":value.trim();
	}
	/*@GET
	@Path("/testProcessRequest")
	@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	public String  testProcessRequest(@QueryParam("message") String message) {
		BasicConfigurator.configure(); 
		clinSelectServicesBean.callProcess(message);
		return "success";
	}
	
	
	@POST
	@Path("/testProcessRequestPost")
	@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	public String  testProcessRequestPost(String message) {
		clinSelectServicesBean.callProcess(message);
		return "success";
	}
	*/
	
	
	
	
}
