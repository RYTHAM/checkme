package com.vz.gchclin.ws.rs.select.internal;

import static org.junit.Assert.*;

import org.junit.Test;
import com.vz.gchclin.common.dataobject.ClinSearchOut;
import com.vz.gchclin.common.dataobject.ClinSearchIn;
import com.vz.gchclin.common.dataobject.UploadRequestsIn;
import org.apache.log4j.BasicConfigurator;
public class ClinSelectInternalServicesImplTest {
	
	

	@Test
	public void search() {
		
		ClinSelectInternalServicesImpl impl1=new ClinSelectInternalServicesImpl();
		ClinSearchIn in=new ClinSearchIn();
		in.setStartRow(0);
		in.setPageSize(10);
		in.setSortBy("clinId");
		in.setAsc(true);
		in.setContractId(null);
		in.setClinId("DUMMY");
		BasicConfigurator.configure();
		/*try{ClinSearchOut out=impl1.search(in);
			}catch (Exception e){e.printStackTrace();}
		}*/
		System.out.println("SEARCH DONE");
	}

	@Test
	public void getRequests() {
		UploadRequestsIn in=new UploadRequestsIn();
		in.setRequester("V436645");
		in.setPageSize(10);
		in.setStartRow(0);	
		try{new ClinSelectInternalServicesImpl().getRequests(in);}catch (Exception e){
			
		}
		System.out.println("getRequests tested");
		
	}

	

	@Test
	public void testProcessRequest() {
		assertTrue(1 == 1);

	}

	@Test
	public void testProcessRequestPost() {
		assertTrue(1 == 1);

	}

	@Test
	public void getFile() {
		assertTrue(1 == 1);

	}

}
