package com.vz.gchclin.ws.rs.update.internal;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.FileInputStream;
import java.nio.charset.StandardCharsets;

import com.vz.gchclin.ws.rs.update.internal.ClinUpdateInternalServicesImpl;

import static org.junit.Assert.*;

import javax.naming.Context;
import javax.naming.InitialContext;

import org.apache.log4j.BasicConfigurator;
import org.junit.Test;

public class ClinUpdateInternalServicesImplTest {
	
	

	@Test
	public void testUploadFile() {
		ClinUpdateInternalServicesImpl impl = new ClinUpdateInternalServicesImpl();
		BasicConfigurator.configure();
		String file = "CLIN Id,CLIN Description,Charge Type,Start Date,End Date,Product Group Code,Solution Code,Product Code,Feature Code,Spec Code 1,Spec Value 1,Spec Code 2,Spec Value 2,Spec Code 3,Spec Value 3,Spec Code 4,Spec Value 4,Spec Code 5,Spec Value 5,Spec Code 5,Spec Value 5,Spec Code 6,Spec Value 6,Spec Code 7,Spec Value 7,Spec Code 8,Spec Value 8,Spec Code 9,Spec Value 9,Spec Code 10,Spec Value 10,Spec Code 11,Spec Value 11,Spec Code 12,Spec Value 12,Spec Code 13,Spec Value 13,Spec Code 14,Spec Value 14,Spec Code 15,Spec Value 15,Spec Code 16,Spec Value 16\n"
				+ "DUMMY,DUMMY Clin Description NRE,NRE,20160331,20160526,,SL_WAVE,PR_WAVE_SVC,FET_WAV_Metro,SP_WAV_SPEED,1 Gbps,SP_WAV_PROTECT_TYP,Unprotected,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,";

		System.out.println("RESPONSE"
				+ impl.uploadFile(
						new ByteArrayInputStream(file
								.getBytes(StandardCharsets.UTF_8)), null,
						"CONTRACTiD", "USERID"));
	}
	@Test
	public void testUploadFileError() {
		ClinUpdateInternalServicesImpl impl = new ClinUpdateInternalServicesImpl();
		BasicConfigurator.configure();
		String file = "CLIN Id,CLIN Description,Charge Type,Start Date,End Date,Product Group Code,Solution Code,Product Code,Feature Code,Spec Code 1,Spec Value 1,Spec Code 2,Spec Value 2,Spec Code 3,Spec Value 3,Spec Code 4,Spec Value 4,Spec Code 5,Spec Value 5,Spec Code 5,Spec Value 5,Spec Code 6,Spec Value 6,Spec Code 7,Spec Value 7,Spec Code 8,Spec Value 8,Spec Code 9,Spec Value 9,Spec Code 10,Spec Value 10,Spec Code 11,Spec Value 11,Spec Code 12,Spec Value 12,Spec Code 13,Spec Value 13,Spec Code 14,Spec Value 14,Spec Code 15,Spec Value 15,Spec Code 16,Spec Value 16\n"
				+ "DUMMY,DUMMY Clin Description NRE,NRE,20160331,20160526,,SL_WAVE,PR_WAVE_SVC,FET_WAV_Metro,SP_WAV_SPEED,1 Gbps,SP_WAV_PROTECT_TYP,Unprotected,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,";

		System.out.println("RESPONSE"
				+ impl.uploadFile(
						new ByteArrayInputStream(file
								.getBytes(StandardCharsets.UTF_8)), null,
						"CONTRACTiD", "USERID"));
	}
	

}
