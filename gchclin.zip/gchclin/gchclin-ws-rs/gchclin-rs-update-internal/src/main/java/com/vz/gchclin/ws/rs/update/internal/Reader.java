package com.vz.gchclin.ws.rs.update.internal;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.log4j.Logger;
import org.apache.commons.lang.SystemUtils;
import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.HierarchicalConfiguration;

import com.vz.helpers.config.ConfigHelper;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import com.jcraft.jsch.UserInfo;
import com.jcraft.jsch.ChannelSftp.LsEntry;

public class Reader {
	private static final Logger logger = Logger.getLogger(Reader.class);

	public String getFile(String file) {
		logger.info("getFile BEGIN");
		com.jcraft.jsch.JSch jsch = new com.jcraft.jsch.JSch();
		StringBuilder sb = new StringBuilder();
		Configuration config = ConfigHelper.load("com.vz.gchclin", "gchclin-config", "config");
        String ftpDirectory =config.getString("download/ftpStg"); //@DOWNLOAD_OPS_DIR@
        String ftpServer = config.getString("download/ftpServer"); //@COMMON.GDF_SERVER_NAME@
        String ftpUserName = config.getString("download/ftpUserName"); //@DOWNLOAD_OPS_FTPUSERNAME@
        String ftpPassword = config.getString("download/ftpPassword"); //@DOWNLOAD_OPS_FTPPASSWORD@
        
        logger.info(
                 "Calling SFtp with "             
                + " [ftpServer: " + ftpServer + "] "
                + " [ftpDir: " + ftpDirectory + "] "
                + " [downloadFileName: " + file + " ] "
                + " [ftpUserName: " + ftpUserName + "] "
                + " [ftpPassword:" + ftpPassword + "] ");
		try {
			Session session = jsch.getSession(ftpUserName, ftpServer, 22);

			java.util.Hashtable<String, String> configMap = new java.util.Hashtable<String, String>();
			configMap.put("PreferredAuthentications", "password");
			session.setConfig(configMap);
			final String password = ftpPassword;
			session.setUserInfo(new UserInfo() {
				public String getPassword() {
					return password;
				}

				public boolean promptYesNo(String str) {
					return true;
				}

				public String getPassphrase() {
					return null;
				}

				public boolean promptPassphrase(String message) {
					return true;
				}

				public boolean promptPassword(String message) {
					return true;
				}

				public void showMessage(String message) {
				}
			});

			session.connect();

			ChannelSftp channel = (ChannelSftp) session.openChannel("sftp");
			channel.connect();
			channel.cd(ftpDirectory);
			InputStream stream = null;
			BufferedReader br = null;
			try {
				stream = channel.get(file.trim());
			} catch (SftpException e1) {
				sb.append("NOFILE");
				logger.error(e1);
			}
			if (stream != null) {
				br = new BufferedReader(new InputStreamReader(stream));
				String line;
				while ((line = br.readLine()) != null) {
					sb.append(line.trim()).append("\n");
				}
				br.close();
			}
			channel.disconnect();
			session.disconnect();
			logger.info("file size" + sb.toString().length());
			// System.out.println(sb.toString());
		} catch (JSchException e) {
			sb.append("INTERNAL ERROR");
			logger.error(e);

		} catch (SftpException e) {
			sb.append("INTERNAL ERROR");
			logger.error(e);
		} catch (IOException e) {	
			sb.append("THE FILE REQUESTED BY YOU IS NOT AVILABLE");
			logger.error(e);
		}
		logger.info("getFile END");
		return sb.toString();
	}

}
