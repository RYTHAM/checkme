package com.vz.gchclin.ws.rs.update.internal;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.log4j.Logger;

import javax.ejb.Stateless;
import javax.ejb.EJB;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.HierarchicalConfiguration;

import com.vz.helpers.config.ConfigHelper;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import com.jcraft.jsch.UserInfo;
import com.jcraft.jsch.ChannelSftp.LsEntry;


import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataParam;
import com.vz.gchclin.beans.update.IClinUpdateServicesBean;

//import org.apache.log4j.BasicConfigurator;
/**
 * Session Bean implementation class CustomerServicesBean
 */
@Path("/services")
@Stateless
public class ClinUpdateInternalServicesImpl {
	private static Logger LOGGER = Logger
			.getLogger(ClinUpdateInternalServicesImpl.class);
	static {
		LOGGER.info("ClinUpdateInternalServicesImpl.java 20170223 V436645 ");
	}
	@EJB
	IClinUpdateServicesBean clinUpdateServicesBean = null;
	String jndiName = "ClinUpdateServicesBean#com.vz.gchclin.beans.update.IClinUpdateServicesBean";

	@POST
	@Path("/upload")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.TEXT_HTML)
	public String uploadFile(
			@FormDataParam("file") InputStream uploadedInputStream,
			@FormDataParam("file") FormDataContentDisposition fileDetail,
			@FormDataParam("contractId") String contractId,
			@FormDataParam("requester") String requester) {
		// BasicConfigurator. configure();
		LOGGER.info("uploadFile SERVICE START");
		String errordesc = "{success: false}";
		if (contractId.length() > 20) {
			errordesc = "{success:  false, responseCode: '002', responseMessage: 'Contract Id is too long(Only 20 characters are allowed).'} ";
			return errordesc;
		}
		try {
			BufferedReader br = null;
			StringBuilder sb = new StringBuilder();
			try {
				br = new BufferedReader(new InputStreamReader(
						uploadedInputStream));
				String line;
				while ((line = br.readLine()) != null) {
					if (!line.isEmpty() && line.length() > 42) {
						sb.append(line.trim()).append("\n");
					}
				}
				br.close();
			} catch (IOException iEx) {
				LOGGER.info("uploadFile:: FAILED TO READ THE UPLOADED FILE");
				errordesc = "{success: false}";
				LOGGER.error(iEx);
			}
			/*
			 * http://gchscm.ebiz.verizon.com/jira/browse/IN-805
			 */
			LOGGER.info("NON ASCII CHARS WILL BE REMOVED");
			String file = sb.toString().replaceAll("[^\\p{ASCII}]", "");
			if (file.contains("\'")) {
				errordesc = "{success:  false, responseCode: '001', responseMessage: 'INVALID CHARACTERS FOUND IN FILE'} ";
			} else {
				Context ctx = new InitialContext();
				clinUpdateServicesBean = (IClinUpdateServicesBean) ctx
						.lookup(jndiName);
				clinUpdateServicesBean.insertClob(file, contractId,
						requester.trim());
				errordesc = "{success: true}";
			}
		} catch (Exception e) {
			LOGGER.info("UNEXPECTED ERROR WHILE UPLOADING FILE");
			errordesc = "{success: false}";
			LOGGER.info(e.getLocalizedMessage());
			LOGGER.error(e);
		}
		LOGGER.info("uploadFile SERVICE END");
		return errordesc;

	}

	@GET
	@Path("/getSearchResult/{fileId}")
	@Produces("text/plain")
	public Response getSearchResult(@PathParam("fileId") final String fileId) {
		// BasicConfigurator. configure();
		LOGGER.info("getSearchResult getSearchResult ::recevied request");			
		javax.ws.rs.core.StreamingOutput stream = new javax.ws.rs.core.StreamingOutput() {
            @Override
            public void write(java.io.OutputStream os) throws IOException, javax.ws.rs.WebApplicationException {
            	int chunksize = 500;
            	int count;
            	byte[] chunk = new byte[chunksize];
            	java.io.Writer writer = new java.io.BufferedWriter(new java.io.OutputStreamWriter(os));           		
            		com.jcraft.jsch.JSch jsch = new com.jcraft.jsch.JSch();
            		StringBuilder sb = new StringBuilder();
            		Configuration config = ConfigHelper.load("com.vz.gchclin", "gchclin-config", "config");
                    String ftpDirectory =config.getString("download/ftpStg"); //@DOWNLOAD_OPS_DIR@                    
                    String ftpServer = config.getString("download/ftpServer"); //@COMMON.GDF_SERVER_NAME@
                    String ftpUserName = config.getString("download/ftpUserName"); //@DOWNLOAD_OPS_FTPUSERNAME@
                    String ftpPassword = config.getString("download/ftpPassword"); //@DOWNLOAD_OPS_FTPPASSWORD@
                    InputStream stream = null;
                    LOGGER.info(
                             "Calling SFtp with "             
                            + " [ftpServer: " + ftpServer + "] "
                            + " [ftpDir: " + ftpDirectory + "] "
                            + " [downloadFileName: " + fileId + " ] "
                            );
                    Session session=null;
            			try{ session = jsch.getSession(ftpUserName, ftpServer, 22);

            			java.util.Hashtable<String, String> configMap = new java.util.Hashtable<String, String>();
            			configMap.put("PreferredAuthentications", "password");
            			session.setConfig(configMap);
            			final String password = ftpPassword;
            			session.setUserInfo(new UserInfo() {
            				public String getPassword() {
            					return password;
            				}

            				public boolean promptYesNo(String str) {
            					return true;
            				}

            				public String getPassphrase() {
            					return null;
            				}

            				public boolean promptPassphrase(String message) {
            					return true;
            				}

            				public boolean promptPassword(String message) {
            					return true;
            				}

            				public void showMessage(String message) {
            				}
            			});

            			session.connect();
            	
            	ChannelSftp channel = (ChannelSftp) session.openChannel("sftp");
            	channel.connect();
            	channel.cd(ftpDirectory);
            	InputStream bIn =  channel.get(fileId);
            	while ((count = bIn.read(chunk,0,chunksize)) >= 0)
            	{
            	os.write(chunk,0,count);
            	os.flush();
            	}                                
                writer.flush();
                channel.disconnect();
    			session.disconnect();
            			}catch(com.jcraft.jsch.JSchException e){LOGGER.error(e);}catch(com.jcraft.jsch.SftpException e1){LOGGER.error(e1);}
        }
		};
		LOGGER.info("ENTERD INTO RESPONSE");
		ResponseBuilder rb = Response.ok((Object) stream);
		
			String name[] = fileId.split("\\.");
			rb.header("Content-Disposition", "attachment; filename=" + name[5]+ "_" + name[2] + "_" + name[3]+ "." +name[4]);
		
		return rb.build();
	}
}
