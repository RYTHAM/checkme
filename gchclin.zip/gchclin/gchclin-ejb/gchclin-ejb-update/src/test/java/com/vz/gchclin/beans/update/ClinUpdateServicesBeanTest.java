package com.vz.gchclin.beans.update;

import java.io.InputStream;

import com.vz.gchclin.beans.update.ClinUpdateServicesHelper;
import com.vz.gchclin.beans.update.ClinUpdateServicesBean;
import com.vz.gchclin.common.domainobjects.UploadRequest;
import org.junit.Before;
import org.junit.After;
import org.junit.Test;

import java.sql.DriverManager;
import java.sql.Connection;

import javax.persistence.*;

import static org.junit.Assert.*;

import java.io.InputStream;

import org.apache.log4j.BasicConfigurator;

public class ClinUpdateServicesBeanTest {

	EntityManager manager;
	Connection jdbcConnection;

	String url = "jdbc:oracle:thin:@uiiscdd1scan.ebiz.verizon.com:1800/DGCHDBB";
	String usr = "clinapp";
	String pwd = "!1clinapp";

	@Before
	public void beforeTest() {
		manager = Persistence.createEntityManagerFactory("clinEjbPUTestRead")
				.createEntityManager();
		try {
			Class driverClass = Class.forName("oracle.jdbc.OracleDriver");
			jdbcConnection = DriverManager.getConnection(url, usr, pwd);
		} catch (Exception e) {
		}

		System.out.println("ENTITY CREATED");

	}

	@Test
	public void test() {
		ClinUpdateServicesBean bean = new ClinUpdateServicesBean();
		System.out.println("BEAN TEST" + bean.test("BEAN TEST"));
		System.out.println("Tst test()"
				+ ClinUpdateServicesHelper.getInstance().test("Hello ClIN"));
	}

	@Test
	public void insertClob() {
		System.out.println("insertClob  TEST START ");
		UploadRequest req = new UploadRequest();
		req.setContractId("DUMMY	");
		String file="CLIN Id,CLIN Description,Charge Type,Start Date,End Date,Product Group Code,Solution Code,Product Code,Feature Code,Spec Code 1,Spec Value 1,Spec Code 2,Spec Value 2,Spec Code 3,Spec Value 3,Spec Code 4,Spec Value 4,Spec Code 5,Spec Value 5,Spec Code 5,Spec Value 5,Spec Code 6,Spec Value 6,Spec Code 7,Spec Value 7,Spec Code 8,Spec Value 8,Spec Code 9,Spec Value 9,Spec Code 10,Spec Value 10,Spec Code 11,Spec Value 11,Spec Code 12,Spec Value 12,Spec Code 13,Spec Value 13,Spec Code 14,Spec Value 14,Spec Code 15,Spec Value 15,Spec Code 16,Spec Value 16\n"
				+ "DUMMY,DUMMY Clin Description NRE,NRE,20160331,20160526,,SL_WAVE,PR_WAVE_SVC,FET_WAV_Metro,SP_WAV_SPEED,1 Gbps,SP_WAV_PROTECT_TYP,Unprotected,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,";
		
		req.setInputfile(file);
		req.setRequester("SIDDAIAH");
		req.setProcessFlag('N');
		req.setUserId("TEST_VZID");
		req.setTimeStamp(new java.util.Date());
		

		try {
			ClinUpdateServicesHelper
					.getInstance()
					.insertClob(
							manager,req.getInputfile(),req.getContractId(),req.getUserId()
							);
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			ClinUpdateServicesBean bean = new ClinUpdateServicesBean();
			 bean.insertClob("String file", "contractId", "requester");
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("insertClob  TEST END ");
	}

	@Test
	public void populateData() {
		System.out.println("POPULATE DATA START");
		ClinUpdateServicesBean bean = new ClinUpdateServicesBean();
		try {
			bean.populateData();
		} catch (Exception e) {
			System.out.println("POPULATE DATA 1 end");
		}
		System.out.println("POPULATE DATA START2");
		try {
			ClinUpdateServicesHelper.getInstance().populateClinUploadData(
					manager);
		} catch (Exception e) {
			System.out.println("POPULATE DATA 1 end");
		}
		System.out.println("POPULATE DATA END");
		// assertTrue(1 == 1);
	}

	@Test
	public void testProcess() {
		System.out.println("testProcesstestProcess");
		BasicConfigurator.configure();
		/*try {
			ClinUpdateServicesHelper.getInstance().processPendingRow(
					jdbcConnection, 15L);
		} catch (Exception e) {
			e.printStackTrace();
		}*/
	}

	@Test
	public void getPendingReqs() {
		assertTrue(1 == 1);
	}

	@Test
	public void testParseInputXml() {
		try {
			System.out.println("start ::: ");

			System.out.println(" end ::: ");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
