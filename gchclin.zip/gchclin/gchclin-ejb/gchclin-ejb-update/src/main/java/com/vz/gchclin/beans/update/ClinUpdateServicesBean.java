package com.vz.gchclin.beans.update;
import java.io.IOException;
import java.io.Serializable;
import javax.ejb.Stateless;
import javax.ejb.Asynchronous;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;




/**
 * Session Bean implementation class ClinUpdateServicesBean
 */
@Stateless(name="ClinUpdateServicesBean", mappedName="ClinUpdateServicesBean")
public class ClinUpdateServicesBean  implements IClinUpdateServicesBean, Serializable {
   
   private static final long serialVersionUID = 1L;
   
   @PersistenceContext(unitName = "clinEjbPUWrite")
   protected EntityManager entityManagerWrite;
   
   @Override
   public String  test(String name) {
      return ClinUpdateServicesHelper.getInstance().test(name);
   }
   /*
    * Upload file 
    * */
   @Override
   public void insertClob(String file,String contractId,String requester)  throws Exception{
      ClinUpdateServicesHelper.getInstance().insertClob(entityManagerWrite, file, contractId,requester); 
      
   }
   
//   @Asynchronous
   @Override
  @TransactionAttribute(TransactionAttributeType.REQUIRED)
   public void  populateData(){
      ClinUpdateServicesHelper.getInstance().populateClinUploadData(entityManagerWrite);
   }
   private void writeObject(java.io.ObjectOutputStream out) throws IOException{
       out.defaultWriteObject();
   }
   private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException{
      in.defaultReadObject();
   }

}
