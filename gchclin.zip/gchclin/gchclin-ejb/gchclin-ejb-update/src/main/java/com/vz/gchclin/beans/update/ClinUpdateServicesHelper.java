package com.vz.gchclin.beans.update;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.apache.log4j.Logger;

import javax.persistence.Query;
import javax.persistence.EntityManager;
import com.vz.gchclin.common.util.GCHClinRequestException;
import com.vz.gchclin.common.domainobjects.UploadRequest;

public class ClinUpdateServicesHelper {

	private static final long serialVersionUID = 1L;
	private static Logger LOGGER = Logger
			.getLogger(ClinUpdateServicesHelper.class);
	private static ClinUpdateServicesHelper clinUpdateServicesHelper = null;

	private ClinUpdateServicesHelper() {

	}

	public static ClinUpdateServicesHelper getInstance() {
		if (clinUpdateServicesHelper == null) {
			clinUpdateServicesHelper = new ClinUpdateServicesHelper();
		}
		return clinUpdateServicesHelper;
	}

	public String test(String name) {

		return name;
	}

	public void insertClob(EntityManager entityManager, String file,
			String contractId, String requester) throws GCHClinRequestException {
		LOGGER.info("insertClob SATRTS");
		UploadRequest req = new UploadRequest();
		req.setContractId(trimValue(contractId));
		req.setInputfile(file);
		req.setRequester(requester);
		req.setProcessFlag('N');
		req.setUserId(requester);
		req.setTimeStamp(new java.util.Date());
		try {
			entityManager.merge(req);
		} catch (Exception e) {
			LOGGER.error(e);
			throw new GCHClinRequestException("INSERT FAILED");
		}
		LOGGER.info("insertClob ENDS");
	}

	public void populateClinUploadData(EntityManager entityManager) {
		LOGGER.info("populateClinUploadData Started with latest changes on 07072017");

		Long uploadRequestOid = null;
		Connection conn = null;

		StringBuilder getReq = new StringBuilder(
				"SELECT MIN(CLIN_UPLOAD_REQUEST_OID) from  CLIN.CLIN_UPLOAD_REQUEST WHERE PROCESS_FLAG='N' ");
		StringBuilder inprogress = new StringBuilder(
				"SELECT * from  CLIN.CLIN_UPLOAD_REQUEST WHERE PROCESS_FLAG='P'");
		StringBuilder chgStatus = new StringBuilder(
				"UPDATE CLIN.CLIN_UPLOAD_REQUEST REQ SET REQ.PROCESS_FLAG=?1 WHERE REQ.CLIN_UPLOAD_REQUEST_OID=?2");
		Query query = null;
		int count = 0;
		try {
			LOGGER.info("populateClinUploadData checking for progress");
			query = entityManager.createNativeQuery(inprogress.toString());
			count = query.getResultList().size();
			LOGGER.info("count:" + count);
		} catch (Exception e) {
			LOGGER.error(e);
		}

		if (count == 0) {
			query = entityManager.createNativeQuery(getReq.toString());
			uploadRequestOid = ((java.math.BigDecimal) query.getSingleResult())
					.longValue();
			LOGGER.info("populateClinUploadData STARTED:" + uploadRequestOid);
			query = entityManager.createNativeQuery(chgStatus.toString());
			query.setParameter(1, "P");
			query.setParameter(2, uploadRequestOid);
			query.executeUpdate();
			LOGGER.info("populateClinUploadData INPROGRESS:" + uploadRequestOid);

			conn = com.vz.gchclin.common.util.DbConnectionUtils
					.getConnection("W");
			try {
				processPendingRow(conn, uploadRequestOid);
			} catch (Exception e) {
				LOGGER.error(
						"FAILED TO processPendingRow ,CHANGING PROCESS_FLAG TO N ", e);

				query = entityManager.createNativeQuery(chgStatus.toString());
				query.setParameter(1, "N");
				query.setParameter(2, uploadRequestOid);
				query.executeUpdate();
				LOGGER.info("populateClinUploadData Exception updateing status ENDS");
			} finally {
				try {
					if (conn != null && !conn.isClosed()) {
						conn.close();
					}
				} catch (Exception e) {
					LOGGER.warn("Error in closing the connection ", e);
				}

			}
			LOGGER.info("populateClinUploadData ENDS");

		}

	}

	public void processPendingRow(Connection conn, Long uploadRequestOid)
			throws Exception {
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		String requester = null;
		String regex = "^[a-zA-Z0-9]{1,10}+$";
		Pattern pattern = Pattern.compile(regex);
		boolean isError;

		PreparedStatement st = null;
		PreparedStatement err_st = null;

		StringBuilder happyPath = new StringBuilder();
		happyPath
				.append(" INSERT INTO CLIN.CLIN_UPLOAD_DATA (CLIN_UPLOAD_DATA_OID, CLIN_UPLOAD_REQUEST_OID, CLIN_ID, CLIN_DESCRIPTION, CHARGE_TYPE, START_DATE, END_DATE, MODIFIED_DATE, PG_CODE, SL_CODE, PR_CODE, FET_CODE,"
						+ "SPEC_CODE_1 ,SPEC_VALUE_1 ,SPEC_CODE_2 ,SPEC_VALUE_2 ,SPEC_CODE_3 ,SPEC_VALUE_3 ,SPEC_CODE_4 ,SPEC_VALUE_4 ,SPEC_CODE_5 ,"
						+ "SPEC_VALUE_5 ,SPEC_CODE_6 ,SPEC_VALUE_6 ,SPEC_CODE_7 ,SPEC_VALUE_7 ,SPEC_CODE_8 ,SPEC_VALUE_8 ,SPEC_CODE_9 ,SPEC_VALUE_9 ,"
						+ "SPEC_CODE_10 ,SPEC_VALUE_10 ,SPEC_CODE_11 ,SPEC_VALUE_11 ,SPEC_CODE_12 ,SPEC_VALUE_12 ,SPEC_CODE_13 ,SPEC_VALUE_13 ,"
						+ "SPEC_CODE_14 ,SPEC_VALUE_14 ,SPEC_CODE_15 ,SPEC_VALUE_15 ,SPEC_CODE_16 ,SPEC_VALUE_16, STATUS,USER_ID,RAW_DATA,ERROR_MSG)"
						+ "values(CLIN.CLIN_UPLOAD_DATA_SEQ.NEXTVAL,?,?,?,?,?,?,SYSDATE,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		StringBuilder failPath = new StringBuilder();
		failPath.append(" INSERT INTO CLIN.CLIN_UPLOAD_DATA (CLIN_UPLOAD_DATA_OID, CLIN_UPLOAD_REQUEST_OID,"
				+ "ERROR_MSG,STATUS,RAW_DATA,USER_ID,MODIFIED_DATE) values (CLIN.CLIN_UPLOAD_DATA_SEQ.NEXTVAL,?,?,?,?,?,SYSDATE)");

		StringBuilder readQery = new StringBuilder(
				"SELECT INPUT_FILE_CONTENT ,REQUESTER FROM CLIN.CLIN_UPLOAD_REQUEST WHERE CLIN_UPLOAD_REQUEST_OID=?");
		StringBuilder blank_file = new StringBuilder(
				"UPDATE CLIN.CLIN_UPLOAD_REQUEST SET PROCESS_FLAG='Y',STATUS='F',START_UPLOAD_TS=SYSDATE,END_UPLOAD_TS=SYSDATE,OUTPUT_FILE_CONTENT = 'Empty file: Please upload a valid .csv file' WHERE CLIN_UPLOAD_REQUEST_OID=?");

		try {
			stmt = conn.prepareStatement(readQery.toString());
			stmt.setLong(1, uploadRequestOid);
			resultSet = stmt.executeQuery();
			while (resultSet.next()) {				
				st = conn.prepareStatement(happyPath.toString());
				err_st = conn.prepareStatement(failPath.toString());
				requester = resultSet.getString(2);
				if (resultSet.getCharacterStream(1) != null) {
					try {
						for (CSVRecord r : CSVFormat.EXCEL.parse(resultSet
								.getCharacterStream(1))) {
							if (r.getRecordNumber() != 1) {
								isError = false;
								StringBuilder err_msg = new StringBuilder();
								LOGGER.info("populateClinUploadData ROWNUM:"
										+ r.getRecordNumber() + "FIELD COUNT"
										+ r.size());
								StringBuilder rawData = new StringBuilder();
								for (int i = 0; i < r.size(); i++) {
									rawData.append(r.get(i)).append(",");
								}
								if (r.size() != 41) {
									err_msg.append("In correct number of values , expected 41, found: "
											+ r.size());
									isError = true;
								}
								Matcher matcher = pattern.matcher(trimValue(r
										.get(0)));

								if (!matcher.matches()) {
									err_msg.append("INVALID FORMAT OF CLIN_ID");
									LOGGER.info(err_msg.toString());
									isError = true;
								}
								if(trimValue(r.get(2)).length() >10){
									err_msg.append("CHARGE TYPE TOO LARGE");
									LOGGER.info(err_msg.toString());
									isError = true;								
								}

								if (isError) {
									LOGGER.info("populateClinUploadData ERROR ROW");
									err_st.setLong(1, uploadRequestOid);
									err_st.setString(2, err_msg.toString());
									err_st.setString(3, "F");
									err_st.setString(4, rawData.toString()
											.substring(0, rawData.length() - 1));
									err_st.setString(5, requester);
									err_st.executeUpdate();
								} else {
									LOGGER.info("populateClinUploadData  ROW");									
									if (StringUtils.isNotBlank(r.get(3))
											&& invalidDate(r.get(3))) {
										if (err_msg.length() > 1) {
											err_msg.append("|");
											err_msg.append("INVALID START DATE");
										}
									}
									if (StringUtils.isNotBlank(r.get(4))
											&& invalidDate(r.get(4))) {
										if (err_msg.length() > 1) {
											err_msg.append("|");
										}
										err_msg.append("INVALID END DATE");
									}
									st.setLong(1, uploadRequestOid);// uploadRequestOid
									st.setString(2, trimValue(r.get(0)));// CLIN_ID
									st.setString(3, trimValue(r.get(1)));// CLIN_DESCRIPTION
									st.setString(4, trimValue(r.get(2)));// Charge
									// Type
									st.setDate(5, stringToDate(r.get(3)));// START_DATE
									st.setDate(6, stringToDate(r.get(4)));// END_DATE
									// TIMESTAMP
									st.setString(7, trimValue(r.get(5)));// PG_CODE
									st.setString(8, trimValue(r.get(6)));// SL_CODE
									st.setString(9, trimValue(r.get(7)));// PR_CODE
									st.setString(10, trimValue(r.get(8)));// FET_CODE
									st.setString(11, trimValue(r.get(9)));// SPEC_CODE_1
									st.setString(12, trimValue(r.get(10)));// SPEC_VALUE_1
									st.setString(13, trimValue(r.get(11)));// SPEC_CODE_2
									st.setString(14, trimValue(r.get(12)));
									st.setString(15, trimValue(r.get(13)));// SPEC_CODE_3
									st.setString(16, trimValue(r.get(14)));
									st.setString(17, trimValue(r.get(15)));// SPEC_CODE_4
									st.setString(18, trimValue(r.get(16)));
									st.setString(19, trimValue(r.get(17)));// SPEC_CODE_5
									st.setString(20, trimValue(r.get(18)));
									st.setString(21, trimValue(r.get(19)));// SPEC_CODE_6
									st.setString(22, trimValue(r.get(20)));
									st.setString(23, trimValue(r.get(21)));// SPEC_CODE_7
									st.setString(24, trimValue(r.get(22)));
									st.setString(25, trimValue(r.get(23)));// SPEC_CODE_8
									st.setString(26, trimValue(r.get(24)));
									st.setString(27, trimValue(r.get(25)));// SPEC_CODE_9
									st.setString(28, trimValue(r.get(26)));
									st.setString(29, trimValue(r.get(27)));// SPEC_CODE_10
									st.setString(30, trimValue(r.get(28)));
									st.setString(31, trimValue(r.get(29)));// SPEC_CODE_11
									st.setString(32, trimValue(r.get(30)));
									st.setString(33, trimValue(r.get(31)));// SPEC_CODE_12
									st.setString(34, trimValue(r.get(32)));
									st.setString(35, trimValue(r.get(33)));// SPEC_CODE_13
									st.setString(36, trimValue(r.get(34)));
									st.setString(37, trimValue(r.get(35)));// SPEC_CODE_14
									st.setString(38, trimValue(r.get(36)));
									st.setString(39, trimValue(r.get(37)));// SPEC_CODE_15
									st.setString(40, trimValue(r.get(38)));
									st.setString(41, trimValue(r.get(39)));// SPEC_CODE_16
									st.setString(42, trimValue(r.get(40)));
									st.setString(43, "N");// STATUS
									st.setString(44, requester);// user_id
									st.setString(45, rawData.toString()
											.substring(0, rawData.length() - 1));// RAW_DATA
									st.setString(46, err_msg.toString());// ERROR_MSG
									st.executeUpdate();
								}
							}
						}

					} catch (SQLException stEx) {
						LOGGER.error("SPLIT FAILED");
						LOGGER.error(stEx);
						throw new GCHClinRequestException("SPLIT INSERT FAILED");
					}
					LOGGER.info("SPLIT INSERT COMPLETE FOR REQUEST::"
							+ uploadRequestOid);
					try {
						CallableStatement stproc_stmt = conn
								.prepareCall("{call CLIN.CLIN_UPLOAD.CLIN_MAIN(?,?,?)}");
						stproc_stmt.setLong(1, uploadRequestOid);
						stproc_stmt.registerOutParameter(2, Types.VARCHAR);
						stproc_stmt.registerOutParameter(3, Types.VARCHAR);
						stproc_stmt.executeUpdate();
						LOGGER.info("SQL CALLED: STATUS"
								+ stproc_stmt.getString(2) + " ERROR_DESC::"
								+ stproc_stmt.getString(3));
						stproc_stmt.close();
					} catch (SQLException procEx) {
						LOGGER.error("STORED PROCEDURE FAILED");
						LOGGER.error(procEx);
						throw new GCHClinRequestException("STORED PROCEDURE FAILED", procEx);
					}
				} else {
					try {
						LOGGER.info("BLANK FILE FOR REQ:" + uploadRequestOid);
						err_st = conn.prepareStatement(blank_file.toString());
						err_st.setLong(1, uploadRequestOid);
						err_st.executeUpdate();						
					} catch (SQLException stEx) {
						LOGGER.error(stEx);
						throw new GCHClinRequestException("BLANK FILE EXCEPTION");
					}
				}				
				st.close();
				err_st.close();
			}
			resultSet.close();
			stmt.close();
		} catch (Exception e) {
			LOGGER.error("Exception  " + e);
			throw new GCHClinRequestException("EXCEPTION");
		}

	}

	private String trimValue(String s) {
		return StringUtils.isNotBlank(s) ? s.trim() : s;
	}

	private java.sql.Date stringToDate(String date) {
		java.sql.Date returnDate = null;
		if (StringUtils.isNotBlank(date)) {
			SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
			try {
				java.util.Date parsed = format.parse(date);
				returnDate = new java.sql.Date(parsed.getTime());

			} catch (ParseException e) {
				LOGGER.info("DATE PARSING FAILED RETURNIN NULL");
			}
		}
		LOGGER.info("returnDate:" + returnDate);
		return returnDate;
	}

	private static boolean invalidDate(String date) {
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		try {
			format.parse(date);
		} catch (ParseException e) {
			return true;
		}
		return false;
	}

}
