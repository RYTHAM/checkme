package com.vz.gchclin.beans.update;

import java.io.InputStream;
import java.io.IOException;
import javax.ejb.Remote;
@Remote
public interface IClinUpdateServicesBean   {
   public String  test(String name); 
   public void insertClob(String file,String contractId,String requester)  throws Exception;
   //@Asynchronous
   public void  populateData();
   

}
