package com.vz.gchclin.beans.select;

import java.io.IOException;
import org.apache.commons.configuration.Configuration;
import javax.persistence.Query;
import javax.persistence.EntityManager;
import com.vz.helpers.config.ConfigHelper;
import com.vz.gchclin.common.dataobject.ClinSearchOut;
import com.vz.gchclin.common.dataobject.ClinRecord;
import com.vz.gchclin.common.dataobject.ClinSearchIn;
import com.vz.gchclin.common.dataobject.UploadRecord;
import com.vz.gchclin.common.dataobject.UploadRequestsOut;
import com.vz.gchclin.common.dataobject.UploadRequestsIn;
import com.vz.gchclin.common.util.Utility;
import com.vz.gchclin.common.util.EIBMessageSender;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import java.util.Arrays;
import com.vz.gchclin.common.dataobject.*;
import java.util.List;
import java.util.ArrayList;
import org.jdom.Document;
import org.jdom.Element;
import com.vz.gchclin.common.util.GCHClinRequestException;
import org.jdom.input.SAXBuilder;
import org.jdom.JDOMException;
import java.io.StringReader;
import com.vz.gchclin.common.ldap.LdapUserData;
import com.vz.gchclin.common.domainobjects.Clin;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;

public class ClinSelectServicesHelper{
	
	private static final long serialVersionUID = 1L;
	private static Logger _logger  = Logger.getLogger(ClinSelectServicesHelper.class);
	static {
		_logger.info("ClinSelectServicesHelper.java 20170221 	TEST COMMIT TEST COMMITTEST COMMITTEST COMMITTEST COMMIT  V436645 ");
	}
	private static ClinSelectServicesHelper clinSelectServicesHelper=null;
	private ClinSelectServicesHelper(){
	}
	public static ClinSelectServicesHelper getInstance() {
        if (clinSelectServicesHelper == null) {
        	clinSelectServicesHelper = new ClinSelectServicesHelper();
        }
        return clinSelectServicesHelper;
    }
	public void testPostMQ(String message){
		try{
			Configuration config = ConfigHelper.load("com.vz.gchclin", "gchclin-config", "config");
			EIBMessageSender p = new EIBMessageSender();
			_logger.info("EIB connection details :::  host::" + config.getString("mq/host")
					 + "channel :: " + config.getString("mq/channel") + "port ::" + config.getString("mq/port") + " Queue Name ::"
					 + config.getString("mq/clinlist-queue") + " Queue Manager ::" + config.getString("mq/queue-manager"));
			p.setHost(config.getString("mq/host"));
			p.setChannel(config.getString("mq/channel"));
			p.setPort(Integer.parseInt(config.getString("mq/port")));
			p.setType(1);
			p.setQueName(config.getString("mq/clinlist-queue"));
			p.setQueueManager(config.getString("mq/queue-manager"));
			p.setMessage(message);
			p.sendMessage();
		}catch(Exception e){
			_logger.error("testPostMQ error-->",e);
		}
	}
	public String getClobData(EntityManager entityManager, Long rquestID) {
		_logger.info("getClobData SATRT");
		String clob=null;	
		try {			
			Query query = entityManager.createNamedQuery("getReportById");
	    	query.setParameter(1, rquestID);
			clob = (String) query.getSingleResult();
		} catch (Exception e) {
			_logger.error("getClobData Error", e);
		}
		_logger.info("getClobData END");
		return clob;
	}
	public UploadRequestsOut getRequests(EntityManager entityManager,UploadRequestsIn in){
		_logger.info("getRequests BEGIN");
		UploadRequestsOut output = new UploadRequestsOut();
		List<UploadRecord> resList=new ArrayList<UploadRecord>();
		StringBuilder SQL = new StringBuilder();
		SQL.append(
				"SELECT CLIN_UPLOAD_REQUEST_OID,CONTRACT_ID,REQUESTER,PROCESS_FLAG,STATUS,to_char(START_UPLOAD_TS,   'MON,DD-YYYY HH:MI') START_UPLOAD_TS,to_char(END_UPLOAD_TS,   'MON,DD-YYYY HH:MI') END_UPLOAD_TS ,to_char(MODIFIED_DATE,   'MON,DD-YYYY HH:MI') MODIFIED_DATE ,ERROR_MSG FROM CLIN.CLIN_UPLOAD_REQUEST WHERE REQUESTER ='")
				.append(in.getRequester().trim()).append("' ")
				.append(" ORDER BY  CLIN_UPLOAD_REQUEST_OID DESC ");
		Query query = entityManager.createNativeQuery(SQL.toString());
    	int count=0;
       	count = query.getResultList().size();
       	output.setTotalRows(count);
       	output.setNoOfRowsReturn(0);
    	if(count >0 ){       			
           	query.setFirstResult(in.getStartRow()).setMaxResults(in.getPageSize());  
		List<Object[]> qResult = query.getResultList();
		if (qResult != null) {
			output.setNoOfRowsReturn(qResult.size());
			_logger.debug("getRequestsSIZE::" +qResult.size());
			for (Object[] resultElement : qResult) {
				
				UploadRecord r = new UploadRecord();
	       		r.setUploadRequestId(((java.math.BigDecimal) resultElement[0])
						.longValue());
	       		r.setContractId( (String) resultElement[1]);						
	       		r.setRequester((String) resultElement[2]);
	       		r.setProcessFlag((String) resultElement[3]);
	       		r.setStatus((String) resultElement[4]);
	       		r.setStartTime((String) resultElement[5]);
	       		r.setEndTime((String) resultElement[6]);
	       		r.setTimeStamp((String) resultElement[7]);
	       		r.setErrorMsg((String) resultElement[8]);//comments
	       		resList.add(r);
			}
		}
    	}
       	output.setResponseCode("000");
       	output.setResponseText("SUCCESS");
       	output.setRequests(resList);
       	output.setSuccess(true);
       	entityManager.clear();
       	_logger.info("getRequests END");
   		return output;
   		}
	 
	public GetClinListIn callProcess(String msg) {
		String METHOD_NAME = "ClinListJmsReceiveListener:callProcess(String msg):";
		if(_logger.isInfoEnabled()){
			_logger.info(METHOD_NAME + " Enter");
		}
		_logger.info(METHOD_NAME + "message -->"+msg);
		GetClinListIn request = null;
		try {
			// parse xml into GetClinListIn object structure request
			request = parse(msg);
		}catch (Exception e) {
			_logger.error(e.getMessage(), e);
		}
		if(_logger.isInfoEnabled()){
			_logger.info(METHOD_NAME + " Exit");
		}
		return request;
	}
	public GetClinListIn parse(String requestXml) {
		String METHOD_NAME = "ClinListJmsReceiveListener::parse(String requestXml):";
		if (_logger.isInfoEnabled()) {
			_logger.info(METHOD_NAME + " parsing: " + requestXml);
		}
		Document doc = getJdomDocument(requestXml);
		Element root = doc.getRootElement();
		GetClinListIn req = new GetClinListIn();
		if(root != null){
			Element clinFilterRequest = root.getChild("CLINFilterRequest");
			req.setClientId(getChildElementText(clinFilterRequest, "clientId"));
			req.setTransactionID(getChildElementText(clinFilterRequest, "transactionID"));
			ContractDetails contractDetails = new ContractDetails();
			Element contractDetailsElement = clinFilterRequest.getChild("contractDetails");
			contractDetails.setContractID(getChildElementText(contractDetailsElement, "contractID"));
			contractDetails.setCustomerRequestNumber(getChildElementText(contractDetailsElement, "customerRequestNumber"));
			contractDetails.setCustomerRequestVersion(getChildElementText(contractDetailsElement, "customerRequestVersion"));
			//contractDetails.setTransactionID(getChildElementText(contractDetailsElement, "transactionID"));
			req.setContractDetails(contractDetails);
			Element userDataInfo = clinFilterRequest.getChild("userData");
			LdapUserData userData = new LdapUserData();
			userData.setUserId(getChildElementText(userDataInfo, "userId"));
			userData.seteId(getChildElementText(userDataInfo, "eId"));
			req.setUserData(userData);
			List<Element> productConfigurationsElements = clinFilterRequest.getChildren("productConfigurations");
			List<ProductConfigurations> productConfigurationsList = new ArrayList<ProductConfigurations>();
			List<FeatureConfigurations> featureConfigurationsList = null;
			List<SpecConfigurations> specConfigurationsList = null;
			ProductConfigurations productConfigurations = null;
			ProductBaseConfigurations productBaseConfigurations = null;
			FeatureConfigurations featureConfigurations = null;
			FeatureBaseConfigurations featureBaseConfigurations = null;
			SpecConfigurations specConfigurations = null;
			for(Element productConfigurationsElement : productConfigurationsElements){
				featureConfigurationsList = new ArrayList<FeatureConfigurations>();
				productConfigurations = new ProductConfigurations();
				productBaseConfigurations = new ProductBaseConfigurations();
				Element productBaseConfigurationsElement = productConfigurationsElement.getChild("productBaseConfigurations");
				productBaseConfigurations.setSolutionCode(getChildElementText(productBaseConfigurationsElement, "solutionCode"));
				productBaseConfigurations.setProductGroup(getChildElementText(productBaseConfigurationsElement, "productGroup"));
				productBaseConfigurations.setProductCode(getChildElementText(productBaseConfigurationsElement, "productCode"));
				List<Element> featureConfigurationsElements = productConfigurationsElement.getChildren("featureConfigurations");
				for(Element featureConfigurationsElement : featureConfigurationsElements){
					featureBaseConfigurations = new FeatureBaseConfigurations();
					featureConfigurations = new FeatureConfigurations();
					specConfigurationsList = new ArrayList<SpecConfigurations>();
					Element featureBaseConfigurationsElement = featureConfigurationsElement.getChild("featureBaseConfigurations");
					featureBaseConfigurations.setFeatureCode(getChildElementText(featureBaseConfigurationsElement, "featureCode"));
					featureBaseConfigurations.setFeatureInstanceID(getChildElementText(featureBaseConfigurationsElement, "featureInstanceID"));
					featureConfigurations.setChargeType(getChildElementText(featureConfigurationsElement, "chargeType"));
					featureConfigurations.setFeatureBaseConfigurations(featureBaseConfigurations);
					List<Element> specConfigurationsElements = featureConfigurationsElement.getChildren("specConfigurations");
					for(Element specConfigurationsElement : specConfigurationsElements){
						specConfigurations = new SpecConfigurations();
						specConfigurations.setCode(getChildElementText(specConfigurationsElement, "code"));
						specConfigurations.setValue(getChildElementText(specConfigurationsElement, "value"));
						specConfigurationsList.add(specConfigurations);
					}
					featureConfigurations.setSpecConfigurations(specConfigurationsList);
					featureConfigurationsList.add(featureConfigurations);
				}
				productConfigurations.setProductBaseConfigurations(productBaseConfigurations);
				productConfigurations.setFeatureConfigurations(featureConfigurationsList);
				productConfigurationsList.add(productConfigurations);
			}
			req.setProductConfigurations(productConfigurationsList);
		}
		if (_logger.isInfoEnabled()) {
			_logger.info(METHOD_NAME + " end "  );
		}
		return req;
	}
	private Document getJdomDocument(String xmlString) {
		String METHOD_NAME = "ClinListJmsReceiveListener:getJdomDocument():";
		SAXBuilder builder = new SAXBuilder();
		try {
			StringReader sr = new StringReader(xmlString);
			Document doc = builder.build(sr);
			return doc;
		} catch (JDOMException e) {
			_logger.error(METHOD_NAME + "error parsing getCLIN request: "
					+ xmlString, e);
			throw new GCHClinRequestException("error parsing: " + xmlString, e);
		} catch (IOException e) {
			_logger.error(METHOD_NAME + "error parsing getCLIN request: "
					+ xmlString, e);
			throw new GCHClinRequestException("error parsing: " + xmlString, e);

		}
	}
	private String getChildElementText(Element pe, String childName) {
		try {
			String value = null;
			Element ce = pe.getChild(childName);
			if (null != ce) {
				String originalValue = ce.getText();
				if (originalValue != null) {
					value = originalValue.trim();
				}
			}
			if (_logger.isInfoEnabled()) {
				_logger.info(childName + " -> [" + value + "]");
			}
			return value;
		} catch (Exception e) {
			_logger.error("error parsing child element " + childName, e);
			return null;
		}
	}
	public GetClinListOut getClinList(EntityManager entityManager, GetClinListIn getClinListIn){
		String METHOD_NAME = "ClinSelectServicesHelper.getClinList()";
		if(_logger.isInfoEnabled()){
			_logger.info(METHOD_NAME +  " Start ");
		}
		_logger.debug("GetClinListIn object is " + getClinListIn );
		GetClinListOut out = new GetClinListOut();
		Configuration configGchClinservices = ConfigHelper.load("com.vz.gchclin", "gchclin-config", "gchclin-services");
		/*Missing input Validations:::
			If TransactionID,ClientId is not passed in Request, we wont process that request and we wont send any error message as response too. */
		if(null != getClinListIn){
			if(StringUtils.isBlank(getClinListIn.getTransactionID() ) || StringUtils.isBlank(getClinListIn.getClientId())){
				_logger.error(METHOD_NAME + "TransactionID or ClientId is missing " + getClinListIn);
				return null;
			}
				//Acceptable Clients  PQ, GCH
			boolean isAcceptableClient = Utility.isAcceptableClient(getClinListIn.getClientId()
					, "getClinList", configGchClinservices);
			if(!isAcceptableClient){
				out.setTransactionID(getClinListIn.getTransactionID());
				out.setTransactionCode("003");
				out.setTransactionStatus("Unsupported Client ID");
				out.setErrorMessage("This Service is not enabled for client - "+ getClinListIn.getClientId());
				_logger.error(METHOD_NAME + " Client Id is not acceptable for this service : " + getClinListIn);
				return out;	
			}
			String userId= null;
			String eid=null;
			if(getClinListIn.getUserData()!=null){
				userId = getClinListIn.getUserData().getUserId();
				eid = getClinListIn.getUserData().geteId();
			}
			if(StringUtils.isBlank(userId) && StringUtils.isBlank(eid)){
				out.setTransactionID(getClinListIn.getTransactionID());
				out.setTransactionCode("002");
				out.setTransactionStatus("Missing Input ");
				out.setErrorMessage(" Missing Input - UserId or EID ");
				_logger.error(METHOD_NAME + " Missing Input - UserId or EID : " + getClinListIn);
				return out;		
			}
			if(StringUtils.isBlank(getClinListIn.getContractDetails().getContractID())){
				out.setTransactionID(getClinListIn.getTransactionID());
				out.setTransactionCode("002");
				out.setTransactionStatus("Missing Input ");
				out.setErrorMessage(" Missing Input - ContractId ");
				_logger.error(METHOD_NAME + " Missing Input - ContractId : " + getClinListIn);
				return out;	
			}
			if(getClinListIn.getProductConfigurations().isEmpty()){
				out.setTransactionID(getClinListIn.getTransactionID());
				out.setTransactionCode("002");
				out.setTransactionStatus("Missing Input ");
				out.setErrorMessage(" Missing Input - ProductConfigurations, expect atleast one ProductConfigurations ");
				_logger.error(METHOD_NAME + " Missing Input - ProductConfigurations : " + getClinListIn);
				return out;	
			}
			List<ProductConfigurations> productConfigurations = getClinListIn.getProductConfigurations();
			List<FeatureConfigurations> featureConfigurations = null;
			for(ProductConfigurations productConfiguration : productConfigurations){
				if(StringUtils.isBlank(productConfiguration.getProductBaseConfigurations().getProductCode())){
					out.setTransactionID(getClinListIn.getTransactionID());
					out.setTransactionCode("002");
					out.setTransactionStatus("Missing Input ");
					out.setErrorMessage(" Missing Input - ProductCode for one of the given ProductConfigurations ");
					_logger.error(METHOD_NAME + " Missing Input - ProductCode for one of the given ProductConfigurations : " + getClinListIn);
					return out;	
				}
				featureConfigurations = productConfiguration.getFeatureConfigurations();
				if(featureConfigurations.isEmpty()){
					out.setTransactionID(getClinListIn.getTransactionID());
					out.setTransactionCode("002");
					out.setTransactionStatus("Missing Input ");
					out.setErrorMessage(" Missing Input - FeatureConfigurations, expect atleast one FeatureConfigurations for given ProductConfigurations ");
					_logger.error(METHOD_NAME + " Missing Input - FeatureConfigurations : " + getClinListIn);
					return out;	
				}else {
					for(FeatureConfigurations featureConfiguration: featureConfigurations){
						if(StringUtils.isBlank(featureConfiguration.getFeatureBaseConfigurations().getFeatureCode())){
							out.setTransactionID(getClinListIn.getTransactionID());
							out.setTransactionCode("002");
							out.setTransactionStatus("Missing Input ");
							out.setErrorMessage(" Missing Input - FeatureCode for one of the given ProductConfigurations ");
							_logger.error(METHOD_NAME + " Missing Input - FeatureCode for one of the given ProductConfigurations : " + getClinListIn);
							return out;	
						}
					}
				}
			}
			out  = getClinListDAO(entityManager, getClinListIn);
		}else{
			out.setTransactionCode("002");
			out.setTransactionStatus("Missing Input ");
			out.setErrorMessage(" Missing Input - null ");
			_logger.error(METHOD_NAME + " Missing Input - null" );
			return out;	
		}
		if(_logger.isInfoEnabled()){
			_logger.info(METHOD_NAME +  " End ");
		}
		return out;
	}
	public GetClinListOut getClinListDAO(EntityManager entityManager, GetClinListIn getClinListIn){
		String METHOD_NAME = "ClinSelectServicesHelper.getClinListDAO";
		if(_logger.isInfoEnabled()){
			_logger.info(METHOD_NAME + " Start ");
		}
		_logger.info(METHOD_NAME + "input object is  ::: " + getClinListIn );
		GetClinListOut out = new GetClinListOut();
		out.setTransactionID(getClinListIn.getTransactionID());
		ContractDetails contractDetailsRes = new ContractDetails();
		contractDetailsRes.setContractID(getClinListIn.getContractDetails().getContractID());
		contractDetailsRes.setCustomerRequestNumber(getClinListIn.getContractDetails().getCustomerRequestNumber());
		contractDetailsRes.setCustomerRequestVersion(getClinListIn.getContractDetails().getCustomerRequestVersion());
		out.setContractDetails(contractDetailsRes);
		String contractId  = getClinListIn.getContractDetails().getContractID();
		List<ProductConfigurations> productConfigurations = getClinListIn.getProductConfigurations();
		List<FeatureConfigurations> featureConfigurations = null;
		boolean clinErrorExist = false;
		List<ProductConfigurationResponse> productConfigurationResponseList = new ArrayList<ProductConfigurationResponse>();
		for(ProductConfigurations productConfiguration : productConfigurations){
			ProductBaseConfigurations productBaseConfigurationsRes = new ProductBaseConfigurations();
			productBaseConfigurationsRes.setSolutionCode(productConfiguration.getProductBaseConfigurations().getSolutionCode());
			productBaseConfigurationsRes.setProductCode(productConfiguration.getProductBaseConfigurations().getProductCode());
			featureConfigurations = productConfiguration.getFeatureConfigurations();
			List<FeatureConfigurationResponse> featureConfigurationResponseList = new ArrayList<FeatureConfigurationResponse>();
			for(FeatureConfigurations featureConfiguration : featureConfigurations){
				boolean clinErrAtFet = false;
				FeatureConfigurationResponse featureConfigurationResponse = new FeatureConfigurationResponse();
				FeatureBaseConfigurations featureBaseConfigurationsres = new FeatureBaseConfigurations();
				featureBaseConfigurationsres.setFeatureCode(featureConfiguration.getFeatureBaseConfigurations().getFeatureCode());
				featureBaseConfigurationsres.setFeatureInstanceID(featureConfiguration.getFeatureBaseConfigurations().getFeatureInstanceID());
				List<String> fetSpecCodes = new ArrayList<String>();
				ClinError clinErrorObj = null;
				List<Clin> clinList = new ArrayList<Clin>();
				for(SpecConfigurations specConfiguration : featureConfiguration.getSpecConfigurations()){
					fetSpecCodes.add(specConfiguration.getCode());
				}
				StringBuffer sb = new StringBuffer();
				if(fetSpecCodes.isEmpty() && fetSpecCodes.size() ==0 ){
					_logger.info(METHOD_NAME  + " Specs for given FET are null from Request " + featureConfiguration.getFeatureBaseConfigurations().getFeatureCode());
					sb.append(prepareQry(featureConfiguration.getChargeType(), productBaseConfigurationsRes.getProductCode(), productConfiguration.getProductBaseConfigurations().getSolutionCode(), featureBaseConfigurationsres.getFeatureCode(), contractId));
				}else{
					List<String> allSpecCodes = Utility.getSpecCodesbyFeatureCode(entityManager,featureConfiguration.getFeatureBaseConfigurations().getFeatureCode());
					_logger.info(METHOD_NAME + "all spec codes " + allSpecCodes);
					_logger.info(METHOD_NAME + "fet spec codes " + fetSpecCodes);
					if(allSpecCodes.containsAll(fetSpecCodes)){
						_logger.info(METHOD_NAME + " Given SPECs for this featureInstanceId " +  featureBaseConfigurationsres.getFeatureInstanceID() + " are valiated");
						_logger.info(METHOD_NAME + " Fetching all specs for a feature from DB for this featureInstanceId " +  featureBaseConfigurationsres.getFeatureInstanceID());
						StringBuffer specSb = new StringBuffer();
						specSb.append(" SELECT RTRIM(XMLAGG(XMLELEMENT(e,xmlattributes (ps.spec_code || ',' AS \"regionname\"))");
						specSb.append(" ORDER BY ps.spec_code ASC).EXTRACT('./E[not(@regionname = preceding-sibling::E/@regionname)]/@regionname'),',')");
						specSb.append(" FROM clin.prod_line_item pl,  clin.prod_spec_list ps,  clin.clin_set cs,  clin.clin c");
						specSb.append(" WHERE pl.PR_CODE          = '").append(productBaseConfigurationsRes.getProductCode()).append("'");
						specSb.append(" AND pl.FET_CODE           = '").append(featureBaseConfigurationsres.getFeatureCode()).append("'");
						if(StringUtils.isNotBlank(productConfiguration.getProductBaseConfigurations().getSolutionCode()))
							specSb.append(" AND pl.SL_CODE = '").append(productBaseConfigurationsRes.getSolutionCode()).append("'");
						else{
							specSb.append(" AND pl.SL_CODE IS NULL ");
						}
						specSb.append(" AND pl.prod_line_item_oid = ps.prod_line_item_oid AND pl.prod_line_item_oid = cs.prod_line_item_oid");
						specSb.append(" AND cs.CLIN_OID           = c.clin_oid AND c.contract_id        = '").append(contractId).append("'");
						if(StringUtils.isNotBlank(featureConfiguration.getChargeType()))
							specSb.append(" AND c.CHARGE_TYPE='").append(featureConfiguration.getChargeType()).append("'");
						specSb.append( " AND ").append(Utility.effectiveDate("cs"));
						_logger.info(METHOD_NAME + "DB specs query is " + specSb.toString());
						Query specQry = entityManager.createNativeQuery(specSb.toString());
						List<String> dbSpecList = null;
						try{
							String dbSpecCodes = (String)specQry.getSingleResult();
						if(!StringUtils.isBlank(dbSpecCodes))
							dbSpecList = Arrays.asList(dbSpecCodes.split(","));
						}catch(NoResultException e){
							_logger.error(METHOD_NAME + " NoResultException " + e);
						}catch(NonUniqueResultException e){
							_logger.error(METHOD_NAME + " NonUniqueResultException " + e);
						}
						_logger.info("DB specs are "+ dbSpecList); 
						if(null != dbSpecList)
							fetSpecCodes.removeAll(dbSpecList);
						_logger.info("discard specs are " + fetSpecCodes);
						_logger.info(METHOD_NAME +  "specConfig before any discard is " + featureConfiguration.getSpecConfigurations());
						SpecConfigurations sp = null;
						List<SpecConfigurations> discardSpecList = new ArrayList<SpecConfigurations>();
						for(String discardSpecCode : fetSpecCodes){
							for(SpecConfigurations specConfiguration : featureConfiguration.getSpecConfigurations()){
								if(specConfiguration.getCode().equalsIgnoreCase(discardSpecCode)){
									_logger.info("discard spec code is " + discardSpecCode);
									discardSpecList.add(specConfiguration);								
								}
							}
					}
					_logger.info("discard spec list is " + discardSpecList + " and it is length " + discardSpecList.size());
					if(discardSpecList.size() != 0){
						_logger.info("featureConfiguration.getSpecConfigurations() bbbbbbbbbbbbbb " + featureConfiguration.getSpecConfigurations().size());
						featureConfiguration.getSpecConfigurations().removeAll(discardSpecList);
						_logger.info("featureConfiguration.getSpecConfigurations() aaaaaaaaaaaaaaaaaa " + featureConfiguration.getSpecConfigurations().size());
					}
					
					_logger.info("SpecConfigurations are " + featureConfiguration.getSpecConfigurations());
					if(featureConfiguration.getSpecConfigurations().isEmpty() && featureConfiguration.getSpecConfigurations().size() ==0 ){
						_logger.info("All specs are discarded hence retriving CLINS assuming FET as Pricable");
						sb.append(prepareQry(featureConfiguration.getChargeType(), productBaseConfigurationsRes.getProductCode(), productConfiguration.getProductBaseConfigurations().getSolutionCode(), featureBaseConfigurationsres.getFeatureCode(), contractId));
						
					}
					else{
						sb.append("WITH prod_line_item_details AS ");
						sb.append(" (SELECT prod_line_item_oid  FROM clin.prod_line_item");
						sb.append(" WHERE ");
						sb.append("  fet_code = '").append(featureBaseConfigurationsres.getFeatureCode()).append("'");
						if(StringUtils.isNotBlank(productConfiguration.getProductBaseConfigurations().getSolutionCode()))
							sb.append(" AND SL_CODE = '").append(productBaseConfigurationsRes.getSolutionCode()).append("'");
						else{
							sb.append(" AND SL_CODE IS NULL ");
						}
						sb.append( " AND pr_code  = '").append(productBaseConfigurationsRes.getProductCode()).append("'");
						sb.append("),");
						sb.append(" prod_spec_list_details AS");
						sb.append(" (SELECT psl.prod_line_item_oid,  psl.spec_code,  psl.spec_value");
						sb.append("  FROM clin.prod_spec_list psl,  prod_line_item_details pld");
						sb.append(" WHERE psl.prod_line_item_oid = pld.prod_line_item_oid)");
						sb.append(" SELECT DISTINCT cl.clin_id,   cl.CLIN_DESCRIPTION,  cl.CHARGE_TYPE,  cl. CLIN_OID, p.prod_line_item_oid");
						sb.append(" FROM prod_spec_list_details p,   clin.clin_set cs,  clin.clin cl");
						sb.append(" WHERE p.prod_line_item_oid = cs.prod_line_item_oid AND cs.clin_oid            = cl.clin_oid");
						sb.append(" AND cl.contract_id         = '").append(contractId).append("'");
						if(StringUtils.isNotBlank(featureConfiguration.getChargeType()))
							sb.append(" AND cl.CHARGE_TYPE='").append(featureConfiguration.getChargeType()).append("'");
						sb.append(" AND NOT EXISTS ");
						sb.append(" (SELECT ps.spec_code ,     ps.spec_value   FROM prod_spec_list_details ps");
						sb.append(" WHERE ps.PROD_LINE_ITEM_OID=p.prod_line_item_oid");
						sb.append(" MINUS (");
						for(SpecConfigurations specConfiguration : featureConfiguration.getSpecConfigurations()){
							sb.append(" SELECT '").append(specConfiguration.getCode()).append("' spec_code , '").append(specConfiguration.getValue()).append("' spec_value FROM dual");
							sb.append( " UNION ALL ");
						}	
						sb.delete(sb.length() - 11, sb.length() -1);
						sb.append(")");
						sb.append(" UNION ALL ");
						sb.append(" ((");
						for(SpecConfigurations specConfiguration : featureConfiguration.getSpecConfigurations()){
							sb.append(" SELECT '").append(specConfiguration.getCode()).append("' spec_code , '").append(specConfiguration.getValue()).append("' spec_value FROM dual");
							sb.append( " UNION ALL ");
						}	
						sb.delete(sb.length() - 11, sb.length() -1);
						sb.append(")");
						sb.append(" MINUS ");
						sb.append(" SELECT ps.spec_code ,    ps.spec_value ");
						sb.append(" FROM prod_spec_list_details ps ");
						sb.append(" WHERE ps.PROD_LINE_ITEM_OID=p.prod_line_item_oid)");
						sb.append(" )");
						sb.append( " AND ").append(Utility.effectiveDate("cs"));
					}
				}else{
					clinErrorExist = true;
					clinErrAtFet = true;
					clinErrorObj = new ClinError();
					clinErrorObj.setClinErrorCode("006");
					clinErrorObj.setClinErrorDescription("Missing SPEC Code or Rate Determinant");
					InvalidSpecConfigurations invalidSpecConfigurationsRes = new InvalidSpecConfigurations();
					invalidSpecConfigurationsRes.setChargeType(featureConfiguration.getChargeType());
					invalidSpecConfigurationsRes.setSpecConfigurations(featureConfiguration.getSpecConfigurations());
					clinErrorObj.setInvalidSpecConfigurations(invalidSpecConfigurationsRes);
					featureConfigurationResponse.setClinError(clinErrorObj);
					_logger.error(METHOD_NAME + " Missing SPEC Code or Rate Determinant for this featureInstanceId " +  featureBaseConfigurationsres.getFeatureInstanceID());
				}
			}
			if(!clinErrAtFet){	
			_logger.info(METHOD_NAME  + " SQL qry for feature is" + sb.toString());
			Query qry = entityManager.createNativeQuery(sb.toString(), Clin.class);
			clinList = qry.getResultList();
					if(clinList.isEmpty()){
						if(StringUtils.isNotBlank(featureConfiguration.getChargeType())){
							clinErrorObj = new ClinError();
							clinErrorObj.setClinErrorCode("007");
							clinErrorObj.setClinErrorDescription("No CLIN found for given charge type " + featureConfiguration.getChargeType());
							InvalidSpecConfigurations invalidSpecConfigurationsRes = new InvalidSpecConfigurations();
							invalidSpecConfigurationsRes.setChargeType(featureConfiguration.getChargeType());
							invalidSpecConfigurationsRes.setSpecConfigurations(featureConfiguration.getSpecConfigurations());
							clinErrorObj.setInvalidSpecConfigurations(invalidSpecConfigurationsRes);
							_logger.error(METHOD_NAME + " No CLIN found for given charge type " + featureConfiguration.getChargeType() +  " for this featureInsatnce Id :: " +  featureBaseConfigurationsres.getFeatureInstanceID());
						}
						else{
							clinErrorObj = new ClinError();
							clinErrorObj.setClinErrorCode("008");
							clinErrorObj.setClinErrorDescription("No CLIN found for billable feature ");
							InvalidSpecConfigurations invalidSpecConfigurationsRes = new InvalidSpecConfigurations();
							invalidSpecConfigurationsRes.setChargeType(featureConfiguration.getChargeType());
							invalidSpecConfigurationsRes.setSpecConfigurations(featureConfiguration.getSpecConfigurations());
							clinErrorObj.setInvalidSpecConfigurations(invalidSpecConfigurationsRes);
							_logger.error(METHOD_NAME + " No CLIN found for billable feature for this featureInsatnce Id :: " +  featureBaseConfigurationsres.getFeatureInstanceID());
						}
						clinErrorExist = true;
						clinErrAtFet = true;
						featureConfigurationResponse.setClinError(clinErrorObj);
					}else{
						List<Clins> ClinsResList = new ArrayList<Clins>();
						for(Clin clin : clinList){
							Clins clinsObj = new Clins();
							clinsObj.setClin(clin.getClinId());
							clinsObj.setClinDescription(clin.getClinDesc());
							clinsObj.setChargeType(clin.getChargeType());
							ClinsResList.add(clinsObj);
						}
						featureConfigurationResponse.setClins(ClinsResList);
					}
					}
				featureConfigurationResponse.setFeatureBaseConfigurations(featureBaseConfigurationsres);
				featureConfigurationResponseList.add(featureConfigurationResponse);
			}
			ProductConfigurationResponse productConfigurationResponse = new ProductConfigurationResponse();
			productConfigurationResponse.setProductBaseConfigurations(productBaseConfigurationsRes);
			productConfigurationResponse.setFeatureConfigurationResponse(featureConfigurationResponseList);
			productConfigurationResponseList.add(productConfigurationResponse);
			out.setProductConfigurationResponse(productConfigurationResponseList);
		}
		if(clinErrorExist){
			out.setTransactionCode("004");
			out.setTransactionStatus("Business/Data Error ");
		}else{
			out.setTransactionCode("000");
			out.setTransactionStatus("Success ");
		}
		if(_logger.isInfoEnabled()){
			_logger.info(METHOD_NAME + " response object is " + out +" End ");
		}
		return out;
	}
	public ClinSearchOut clinSearch(EntityManager entityManager, ClinSearchIn in) {
		String METHOD_NAME = "ClinSelectServicesHelper:clinSearch:";
		_logger.info(METHOD_NAME + "START");
		StringBuilder sql = new StringBuilder();
		ClinSearchOut output = new ClinSearchOut();
		List<ClinRecord> result = new ArrayList<ClinRecord>();
		sql.append("SELECT cl.CLIN_OID,cl.CLIN_ID clinId, cl.CLIN_DESCRIPTION clinDesc,cl.CONTRACT_ID contractId, cl.CHARGE_TYPE chargeType, TO_CHAR(cs.START_DATE, 'MON,DD-YYYY HH12:MI') effectiveFrom, TO_CHAR(cs.END_DATE, 'MON,DD-YYYY HH12:MI') effectiveUntil ,TO_CHAR(cl.MODIFIED_DATE,'MON,DD-YYYY HH12:MI') lastUpdateDate,"
				+ " pl.PR_CODE productCode ,pl.PG_CODE productGroupCode,pl.SL_CODE solutionCode, pl.FET_CODE featureCode,"
				+ " a.* FROM clin.clin_set cs,   clin.clin cl,   clin.prod_line_item pl,     (SELECT PROD_LINE_ITEM_OID,     	MAX(DECODE ( rn , 1, SPEC_CODE )) specCode1,     MAX(DECODE ( rn , 1, SPEC_VALUE )) SPECVALUE1,     MAX(DECODE ( rn , 2, SPEC_CODE )) SPECCODE2,     MAX(DECODE ( rn , 2, SPEC_VALUE )) SPECVALUE2,     MAX(DECODE ( rn , 3, SPEC_CODE )) SPECCODE3,     MAX(DECODE ( rn , 3, SPEC_VALUE )) SPECVALUE3, "
				+ "	MAX(DECODE ( rn , 4, SPEC_CODE )) SPECCODE4,     MAX(DECODE ( rn , 4, SPEC_VALUE )) SPECVALUE4,     MAX(DECODE ( rn , 5, SPEC_CODE )) SPECCODE5,     MAX(DECODE ( rn , 5, SPEC_VALUE )) SPECVALUE5,     MAX(DECODE ( rn , 6, SPEC_CODE )) SPECCODE6,     MAX(DECODE ( rn , 6, SPEC_VALUE )) SPECVALUE6,     MAX(DECODE ( rn , 7, SPEC_CODE )) SPECCODE7,     MAX(DECODE ( rn , 7, SPEC_VALUE )) SPECVALUE7,  "
				+ "   MAX(DECODE ( rn , 8, SPEC_CODE )) SPECCODE8,     MAX(DECODE ( rn , 8, SPEC_VALUE )) SPECVALUE8,     MAX(DECODE ( rn , 9, SPEC_CODE )) SPECCODE9,     MAX(DECODE ( rn , 9, SPEC_VALUE )) SPECVALUE9,     MAX(DECODE ( rn , 10, SPEC_CODE )) SPECCODE10,     MAX(DECODE ( rn , 10, SPEC_VALUE )) SPECVALUE10,     MAX(DECODE ( rn , 11, SPEC_CODE )) SPECCODE11,     MAX(DECODE ( rn , 11, SPEC_VALUE )) SPECVALUE11,   "
				+ "  MAX(DECODE ( rn , 12, SPEC_CODE )) SPECCODE12,     MAX(DECODE ( rn , 12, SPEC_VALUE )) SPECVALUE12,     MAX(DECODE ( rn , 13, SPEC_CODE )) SPECCODE13,     MAX(DECODE ( rn , 13, SPEC_VALUE )) SPECVALUE13,     MAX(DECODE ( rn , 14, SPEC_CODE )) SPECCODE14,     MAX(DECODE ( rn , 14, SPEC_VALUE )) SPECVALUE14,     MAX(DECODE ( rn , 15, SPEC_CODE )) SPECCODE15,     MAX(DECODE ( rn , 15, SPEC_VALUE )) SPECVALUE15,     MAX(DECODE ( rn , 16, SPEC_CODE )) SPECCODE16,     MAX(DECODE ( rn , 16, SPEC_VALUE )) SPECVALUE16   FROM     (SELECT SPEC_CODE,       SPEC_VALUE,       PROD_LINE_ITEM_OID,       row_number() OVER ( partition BY PROD_LINE_ITEM_OID order by rownum) rn     FROM clin.prod_spec_list     )   GROUP BY PROD_LINE_ITEM_OID   )  a WHERE  cs.prod_line_item_oid = pl.prod_line_item_oid AND pl.PROD_LINE_ITEM_OID =  a.PROD_LINE_ITEM_OID(+) and cs.clin_oid = cl.clin_oid ");
		sql.append( " AND ").append(Utility.effectiveDate("cs"));
		//sql.append( " AND ").append(Utility.effectiveDate("cl"));
		if (StringUtils.isNotBlank(in.getClinId())) {
			sql.append("  AND cl.CLIN_ID = '").append(in.getClinId().trim()).append("'");
		}
		if (StringUtils.isNotBlank(in.getClinDesc())) {
			sql.append(" AND cl.CLIN_DESCRIPTION ='")
					.append(in.getClinDesc().trim()).append("'");
		}
		if (StringUtils.isNotBlank(in.getContractId())) {
			sql.append(" AND cl.CONTRACT_ID ='")
					.append(in.getContractId().trim()).append("'");
		}
		sql.append(" ORDER BY  ").append(in.getSortBy()).append(" ")
				.append(in.isAsc() ? "asc" : "desc");
		_logger.info(METHOD_NAME + "QUERY::"+sql.toString());
		Query query = entityManager.createNativeQuery(sql.toString());
		int count = 0;
		count = query.getResultList().size();
		output.setTotalRows(count);
		output.setNoOfRowsReturn(0);
		if (count > 0) {
			query.setFirstResult(in.getStartRow()).setMaxResults(
					in.getPageSize());
			List<Object[]> qResult = query.getResultList();
			if (qResult != null) {
				output.setNoOfRowsReturn(qResult.size());
				for (Object[] o : qResult) {
					ClinRecord r = new ClinRecord();
					r.setClinId((String) o[1]);
					r.setClinDesc((String) o[2]);
					r.setContractId((String) o[3]);
					r.setChargeType((String) o[4]);
					r.setEffectiveFrom((String) o[5]);
					r.setEffectiveUntil((String) o[6]);
					r.setLastUpdateDate((String) o[7]);
					r.setProductCode((String) o[8]);
					r.setProductGroupCode((String) o[9]);
					r.setSolutionCode((String) o[10]);
					r.setFeatureCode((String) o[11]);
					r.setSpecCode1((String) o[13]);
					r.setSpecValue1((String) o[14]);
					r.setSpecCode2((String) o[15]);
					r.setSpecValue2((String) o[16]);
					r.setSpecCode3((String) o[17]);
					r.setSpecValue3((String) o[18]);
					r.setSpecCode4((String) o[19]);
					r.setSpecValue4((String) o[20]);
					r.setSpecCode5((String) o[21]);
					r.setSpecValue5((String) o[22]);
					r.setSpecCode6((String) o[23]);
					r.setSpecValue6((String) o[24]);
					r.setSpecCode7((String) o[25]);
					r.setSpecValue7((String) o[26]);
					r.setSpecCode8((String) o[27]);
					r.setSpecValue8((String) o[28]);
					r.setSpecCode9((String) o[29]);
					r.setSpecValue9((String) o[30]);
					r.setSpecCode10((String) o[31]);
					r.setSpecValue10((String) o[32]);
					r.setSpecCode11((String) o[33]);
					r.setSpecValue11((String) o[34]);
					r.setSpecCode12((String) o[35]);
					r.setSpecValue12((String) o[36]);
					r.setSpecCode13((String) o[37]);
					r.setSpecValue13((String) o[38]);
					r.setSpecCode14((String) o[39]);
					r.setSpecValue14((String) o[40]);
					r.setSpecCode15((String) o[41]);
					r.setSpecValue15((String) o[42]);
					r.setSpecCode16((String) o[43]);
					r.setSpecValue16((String) o[44]);
					result.add(r);
				}
			}
		}		
		output.setResponseCode("000");
		output.setResponseText("SUCCESS");
		output.setClinList(result);
		output.setSuccess(true);
		_logger.info(METHOD_NAME + "END");
		return output;
	}
	private String prepareQry(String chgType, String prCd, String solCd, String fetCd, String contractId){
		//featureConfiguration.getChargeType(), productBaseConfigurationsRes.getProductCode(),featureBaseConfigurationsres.getFeatureCode() 
		//productConfiguration.getProductBaseConfigurations().getSolutionCode(), contractId
		StringBuffer sb = new StringBuffer();
		sb.append("WITH pl_oids AS (SELECT pl.prod_line_item_oid FROM clin.prod_line_item pl, clin.clin_set cs, clin.clin c");
		sb.append("  WHERE pl.prod_line_item_oid = cs.prod_line_item_oid AND cs.CLIN_OID = c.clin_oid AND c.CONTRACT_ID = '").append(contractId).append("'");
		if(StringUtils.isNotBlank(chgType))
			sb.append(" AND c.CHARGE_TYPE='").append(chgType).append("'");
		sb.append(" AND pl.pr_code = '").append(prCd).append("'");
		sb.append(" AND pl.fet_code  ='").append(fetCd).append("' ");
		if(StringUtils.isNotBlank(solCd))
			sb.append(" AND pl.SL_CODE = '").append(solCd).append("'");
		else{
			sb.append(" AND pl.SL_CODE IS NULL ");
		}
		sb.append( " AND ").append(Utility.effectiveDate("cs"));
		sb.append("),");
		sb.append(" psl_oids AS (SELECT psl.prod_line_item_oid FROM pl_oids plo, clin.prod_spec_list psl WHERE plo.prod_line_item_oid = psl.prod_line_item_oid ),");
		sb.append(" final_oids AS ( SELECT prod_line_item_oid FROM pl_oids MINUS SELECT prod_line_item_oid FROM psl_oids)");
		sb.append(" SELECT cd.clin_id, cd.CLIN_DESCRIPTION, cd.CHARGE_TYPE, cd. CLIN_OID, fl.prod_line_item_oid");
		sb.append(" FROM final_oids fl,  clin.clin_set cset,  clin.clin cd");
		sb.append(" WHERE fl.prod_line_item_oid = cset.prod_line_item_oid  AND cset.clin_oid = cd.clin_oid");
		return sb.toString();
	}
	
}
