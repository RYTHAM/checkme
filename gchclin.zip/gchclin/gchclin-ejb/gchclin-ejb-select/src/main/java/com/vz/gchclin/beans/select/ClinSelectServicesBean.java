package com.vz.gchclin.beans.select;
   
import java.io.Serializable;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import com.vz.gchclin.common.dataobject.UploadRequestsOut;
import com.vz.gchclin.common.dataobject.UploadRequestsIn;
import com.vz.gchclin.common.dataobject.GetClinListOut;
import com.vz.gchclin.common.dataobject.GetClinListIn;
import com.vz.gchclin.common.dataobject.ClinSearchOut;
import com.vz.gchclin.common.dataobject.ClinSearchIn;

import java.io.*;


/**
 * Session Bean implementation class CustomerServicesBean
 */
@Stateless(name="ClinSelectServicesBean", mappedName="ClinSelectServicesBean")
public class ClinSelectServicesBean implements Serializable {
   
   private static final long serialVersionUID = 1L;
   
   @PersistenceContext(unitName = "clinEjbPURead")
   protected EntityManager entityManagerRead;
   
   public void testPostMQ(String message){
      ClinSelectServicesHelper.getInstance().testPostMQ(message);
   }
   
   
   public String getClobData(Long requestId) {
      return ClinSelectServicesHelper.getInstance().getClobData(entityManagerRead,requestId);
   }
   
   public ClinSearchOut search(ClinSearchIn in){
      return ClinSelectServicesHelper.getInstance().clinSearch(entityManagerRead,in);
   }
   
   public UploadRequestsOut getRequests(UploadRequestsIn in) {
      return ClinSelectServicesHelper.getInstance().getRequests(entityManagerRead,in);
   }
   
   public GetClinListIn callProcess(String msg){
      GetClinListIn in = ClinSelectServicesHelper.getInstance().callProcess(msg);
      getClinList(in);
      return in;
      
   }
   
   public GetClinListOut getClinList(GetClinListIn getClinListIn){
      return ClinSelectServicesHelper.getInstance().getClinList(entityManagerRead, getClinListIn);
   }
   
   public GetClinListOut getClinListOut(String msg){
	   return ClinSelectServicesHelper.getInstance().getClinList(entityManagerRead, ClinSelectServicesHelper.getInstance().callProcess(msg));
   }
    private void writeObject(ObjectOutputStream stream)
               throws IOException {
           stream.defaultWriteObject();
       }

       private void readObject(ObjectInputStream stream)
               throws IOException, ClassNotFoundException {
           stream.defaultReadObject();
       }
}
