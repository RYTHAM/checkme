package com.vz.gchclin.beans.select;

import com.vz.gchclin.common.dataobject.GetClinListOut;
import com.vz.gchclin.common.dataobject.GetClinListIn;
import javax.ejb.Stateless;
import javax.ejb.Remote;
import java.io.Serializable;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.log4j.Logger;

import java.io.*;


@Stateless(name="ClinRetrivalBean", mappedName="ClinRetrivalBean")
@Remote(IClinRetrivalBean.class)
public class ClinRetrivalBean implements Serializable{
	
	private static final long serialVersionUID = 1L;
	public static final Logger _logger = Logger.getLogger(ClinRetrivalBean.class);
	
	@PersistenceContext(unitName = "clinEjbPURead")
	protected EntityManager entityManagerRead;
	public GetClinListOut getClinList(GetClinListIn getClinListIn){
		return ClinSelectServicesHelper.getInstance().getClinList(entityManagerRead, getClinListIn);
	}
	
	 private void writeObject(ObjectOutputStream stream)
	            throws IOException {
	        stream.defaultWriteObject();
	    }

	    private void readObject(ObjectInputStream stream)
	            throws IOException, ClassNotFoundException {
	        stream.defaultReadObject();
	    }
}