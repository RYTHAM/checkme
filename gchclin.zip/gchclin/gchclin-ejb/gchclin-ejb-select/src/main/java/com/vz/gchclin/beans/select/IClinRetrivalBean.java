package com.vz.gchclin.beans.select;

import com.vz.gchclin.common.dataobject.GetClinListOut;
import com.vz.gchclin.common.dataobject.GetClinListIn;

public interface IClinRetrivalBean{
	
	
	public GetClinListOut getClinList(GetClinListIn getClinListIn);
}