package com.vz.gchclin.beans.select;

import javax.persistence.*;

import org.junit.Before;
import org.junit.After;
import org.junit.Test;

import com.vz.gchclin.common.dataobject.ClinSearchIn;
import com.vz.gchclin.common.dataobject.UploadRequestsIn;

import java.util.ArrayList;
import java.util.List;

import com.vz.gchclin.common.dataobject.GetClinListIn;
import com.vz.gchclin.common.dataobject.GetClinListOut;
import com.vz.gchclin.beans.select.ClinSelectServicesHelper;
import com.vz.gchclin.beans.select.ClinSelectServicesBean;
import com.vz.gchclin.common.dataobject.UploadRecord;
import com.vz.gchclin.common.dataobject.UploadRequestsOut;

import com.vz.gchclin.common.dataobject.ClinSearchOut;
import com.vz.gchclin.common.dataobject.ClinRecord;

import org.apache.log4j.BasicConfigurator;

public class ClinSelectServicesBeanTest {

	EntityManager manager;
	private String inputXml;
	private GetClinListIn inputObject;
	private GetClinListOut responseObj;

	@Before
	public void beforeTest() {
		manager = Persistence.createEntityManagerFactory("clinEjbPUTestRead")
				.createEntityManager();
		System.out.println("ENTITY CREATED");
		inputXml = "<clinFilter><CLINFilterRequest><clientId>PQ</clientId><transactionID>1</transactionID><contractDetails><contractID>J57711-00</contractID><customerRequestNumber/><customerRequestVersion/></contractDetails><productConfigurations><productBaseConfigurations><solutionCode/><productCode>PR_ACC</productCode><productGroup/></productBaseConfigurations><featureConfigurations><featureBaseConfigurations><featureCode>FET_LA</featureCode><featureInstanceID>10A</featureInstanceID></featureBaseConfigurations><chargeType/><specConfigurations><code>SP_ACC_TECH</code><value>Ethernet over TDM or DWDM</value></specConfigurations><specConfigurations><code>SP_ACC_SPEED</code><value>10 Mbps</value></specConfigurations><specConfigurations><code>SP_CUST_HAND_OFF_TYPE</code><value>Ethernt</value></specConfigurations></featureConfigurations></productConfigurations><userData><eId/><gsamLevels/><isAvailable/><translatedGsamInfo/><userId>v473725</userId></userData></CLINFilterRequest></clinFilter>";
	}

	@Test
	public void getClobData() {

		System.out.println("getClobData   "
				+ ClinSelectServicesHelper.getInstance().getClobData(manager,
						new Long(255)));

	}

	@Test
	public void clinSelectServicesBeanMethods() {
		System.out.println("ClinSelectServicesBean ClinSelectServicesBean ");
		ClinSelectServicesBean bean = new ClinSelectServicesBean();
		ClinSearchIn in = new ClinSearchIn();
		in.setClinId("DUMMY");
		ClinRecord r = null;
		ClinSearchOut out = null;
		List<ClinRecord> result = null;
		try {
			out = bean.search(in);
			result = out.getClinList();
			if (result.size() > 0) {
				r = result.get(0);
				System.out
						.println("CLIN SEARCH RESLT size::  " + result.size());
				System.out.println(r.getClinId() + r.getClinDesc()
						+ r.getContractId());
			}
		} catch (Exception e) {
		}

	}

	@Test
	public void getRequests() {
		System.out.println("getRequests start");
		UploadRequestsIn in = new UploadRequestsIn();
		in.setStartRow(0);
		in.setPageSize(1);
		in.setRequester("V436645");
		Long getUploadRequestId = null;
		UploadRequestsOut out = ClinSelectServicesHelper.getInstance()
				.getRequests(manager, in);
		System.out.println("getTotalRows" + out.getTotalRows());
		List<UploadRecord> resList = null;
		if (out != null) {
			getUploadRequestId = out.getRequests().get(0).getUploadRequestId();
		}
		System.out.println("getUploadRequestId" + getUploadRequestId);
		System.out.println("getRequests END");
	}

	@Test
	public void search() {
		System.out.println("SEARCH BY CLIN ID");
		ClinSearchIn in = new ClinSearchIn();
		in.setClinId("DUMMY");
		ClinRecord r = null;
		ClinSearchOut out = ClinSelectServicesHelper.getInstance().clinSearch(
				manager, in);// .getClinList().size();
		List<ClinRecord> result = out.getClinList();
		if (result.size() > 0) {
			r = result.get(0);
			System.out.println("CLIN SEARCH RESLT size::  " + result.size());
			System.out.println(r.getClinId() + r.getClinDesc()
					+ r.getContractId());
		}

	}

	@Test
	public void testParseInputXml() {
		try {
			System.out.println("start ::: ");

			Query query = manager
					.createNativeQuery("select count(*) from clin.clin");
			Long c = ((java.math.BigDecimal) query.getSingleResult())
					.longValue();
			System.out.println("size is " + c);

			System.out.println(" end ::: ");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Test
	public void testParseInputXmlForClin() {
		try {
			System.out
					.println("ClinSelectServicesBeanTest.testParseInputXml() start ::: ");
			inputObject = ClinSelectServicesHelper.getInstance().callProcess(
					inputXml);

			System.out
					.println("ClinSelectServicesBeanTest.testParseInputXml() parsed object is::  "
							+ inputObject.getClientId());
			System.out
					.println("ClinSelectServicesBeanTest.testParseInputXml() end ::: ");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Test
	public void getClinListTest() {

		try {
			System.out
					.println("ClinSelectServicesBeanTest .getClinListTest() start ::: ");
			inputObject = ClinSelectServicesHelper.getInstance().callProcess(
					inputXml);
			responseObj = ClinSelectServicesHelper.getInstance().getClinList(
					manager, inputObject);

			System.out
					.println(" ClinSelectServicesBeanTest .getClinListTest()  end ::: ");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Test
	public void getClinListTestForValidations() {

		try {
			System.out
					.println("ClinSelectServicesBeanTest .getClinListTestForValidations() start ::: ");
			ClinSelectServicesHelper obj = ClinSelectServicesHelper
					.getInstance();
			obj.getClinList(manager, null);
			String noClientId = "<clinFilter><CLINFilterRequest><transactionID>1</transactionID><contractDetails><contractID>J57711-00</contractID><customerRequestNumber/><customerRequestVersion/></contractDetails><productConfigurations><productBaseConfigurations><solutionCode/><productCode>PR_ACC</productCode><productGroup/></productBaseConfigurations><featureConfigurations><featureBaseConfigurations><featureCode>FET_LA</featureCode><featureInstanceID>10A</featureInstanceID></featureBaseConfigurations><chargeType/><specConfigurations><code>SP_ACC_TECH</code><value>Ethernet over TDM or DWDM</value></specConfigurations><specConfigurations><code>SP_ACC_SPEED</code><value>10 Mbps</value></specConfigurations><specConfigurations><code>SP_CUST_HAND_OFF_TYPE</code><value>Ethernt</value></specConfigurations></featureConfigurations></productConfigurations><userData><eId/><gsamLevels/><isAvailable/><translatedGsamInfo/><userId>v473725</userId></userData></CLINFilterRequest></clinFilter>";

			obj.getClinList(manager, obj.callProcess(noClientId));

			String wrongClientId = "<clinFilter><CLINFilterRequest><clientId>GCT</clientId><transactionID>1</transactionID><contractDetails><contractID>J57711-00</contractID><customerRequestNumber/><customerRequestVersion/></contractDetails><productConfigurations><productBaseConfigurations><solutionCode/><productCode>PR_ACC</productCode><productGroup/></productBaseConfigurations><featureConfigurations><featureBaseConfigurations><featureCode>FET_LA</featureCode><featureInstanceID>10A</featureInstanceID></featureBaseConfigurations><chargeType/><specConfigurations><code>SP_ACC_TECH</code><value>Ethernet over TDM or DWDM</value></specConfigurations><specConfigurations><code>SP_ACC_SPEED</code><value>10 Mbps</value></specConfigurations><specConfigurations><code>SP_CUST_HAND_OFF_TYPE</code><value>Ethernt</value></specConfigurations></featureConfigurations></productConfigurations><userData><eId/><gsamLevels/><isAvailable/><translatedGsamInfo/><userId>v473725</userId></userData></CLINFilterRequest></clinFilter>";
			obj.getClinList(manager, obj.callProcess(wrongClientId));
			String noUserId = "<clinFilter><CLINFilterRequest><clientId>PQ</clientId><transactionID>1</transactionID><contractDetails><contractID>J57711-00</contractID><customerRequestNumber/><customerRequestVersion/></contractDetails><productConfigurations><productBaseConfigurations><solutionCode/><productCode>PR_ACC</productCode><productGroup/></productBaseConfigurations><featureConfigurations><featureBaseConfigurations><featureCode>FET_LA</featureCode><featureInstanceID>10A</featureInstanceID></featureBaseConfigurations><chargeType/><specConfigurations><code>SP_ACC_TECH</code><value>Ethernet over TDM or DWDM</value></specConfigurations><specConfigurations><code>SP_ACC_SPEED</code><value>10 Mbps</value></specConfigurations><specConfigurations><code>SP_CUST_HAND_OFF_TYPE</code><value>Ethernt</value></specConfigurations></featureConfigurations></productConfigurations><userData></userData></CLINFilterRequest></clinFilter>";
			obj.getClinList(manager, obj.callProcess(noUserId));
			String noContractId = "<clinFilter><CLINFilterRequest><clientId>PQ</clientId><transactionID>1</transactionID><contractDetails><customerRequestNumber/><customerRequestVersion/></contractDetails><productConfigurations><productBaseConfigurations><solutionCode/><productCode>PR_ACC</productCode><productGroup/></productBaseConfigurations><featureConfigurations><featureBaseConfigurations><featureCode>FET_LA</featureCode><featureInstanceID>10A</featureInstanceID></featureBaseConfigurations><chargeType/><specConfigurations><code>SP_ACC_TECH</code><value>Ethernet over TDM or DWDM</value></specConfigurations><specConfigurations><code>SP_ACC_SPEED</code><value>10 Mbps</value></specConfigurations><specConfigurations><code>SP_CUST_HAND_OFF_TYPE</code><value>Ethernt</value></specConfigurations></featureConfigurations></productConfigurations><userData><eId/><gsamLevels/><isAvailable/><translatedGsamInfo/><userId>v473725</userId></userData></CLINFilterRequest></clinFilter>";
			obj.getClinList(manager, obj.callProcess(noContractId));
			String noProductConfig = "<clinFilter><CLINFilterRequest><clientId>PQ</clientId><transactionID>1</transactionID><contractDetails><contractID>J57711-00</contractID><customerRequestNumber/><customerRequestVersion/></contractDetails><userData><eId/><gsamLevels/><isAvailable/><translatedGsamInfo/><userId>v473725</userId></userData></CLINFilterRequest></clinFilter>";
			obj.getClinList(manager, obj.callProcess(noProductConfig));
			String noPrCd = "<clinFilter><CLINFilterRequest><clientId>PQ</clientId><transactionID>1</transactionID><contractDetails><contractID>J57711-00</contractID><customerRequestNumber/><customerRequestVersion/></contractDetails><productConfigurations><productBaseConfigurations><solutionCode/><productGroup/></productBaseConfigurations><featureConfigurations><featureBaseConfigurations><featureCode>FET_LA</featureCode><featureInstanceID>10A</featureInstanceID></featureBaseConfigurations><chargeType/><specConfigurations><code>SP_ACC_TECH</code><value>Ethernet over TDM or DWDM</value></specConfigurations><specConfigurations><code>SP_ACC_SPEED</code><value>10 Mbps</value></specConfigurations><specConfigurations><code>SP_CUST_HAND_OFF_TYPE</code><value>Ethernt</value></specConfigurations></featureConfigurations></productConfigurations><userData><eId/><gsamLevels/><isAvailable/><translatedGsamInfo/><userId>v473725</userId></userData></CLINFilterRequest></clinFilter>";
			obj.getClinList(manager, obj.callProcess(noPrCd));
			String noFetConfig = "<clinFilter><CLINFilterRequest><clientId>PQ</clientId><transactionID>1</transactionID><contractDetails><contractID>J57711-00</contractID><customerRequestNumber/><customerRequestVersion/></contractDetails><productConfigurations><productBaseConfigurations><solutionCode/><productCode>PR_ACC</productCode><productGroup/></productBaseConfigurations></productConfigurations><userData><eId/><gsamLevels/><isAvailable/><translatedGsamInfo/><userId>v473725</userId></userData></CLINFilterRequest></clinFilter>";
			obj.getClinList(manager, obj.callProcess(noFetConfig));
			String noFetCd = "<clinFilter><CLINFilterRequest><clientId>PQ</clientId><transactionID>1</transactionID><contractDetails><contractID>J57711-00</contractID><customerRequestNumber/><customerRequestVersion/></contractDetails><productConfigurations><productBaseConfigurations><solutionCode/><productCode>PR_ACC</productCode><productGroup/></productBaseConfigurations><featureConfigurations><featureBaseConfigurations><featureInstanceID>10A</featureInstanceID></featureBaseConfigurations><chargeType/><specConfigurations><code>SP_ACC_TECH</code><value>Ethernet over TDM or DWDM</value></specConfigurations><specConfigurations><code>SP_ACC_SPEED</code><value>10 Mbps</value></specConfigurations><specConfigurations><code>SP_CUST_HAND_OFF_TYPE</code><value>Ethernt</value></specConfigurations></featureConfigurations></productConfigurations><userData><eId/><gsamLevels/><isAvailable/><translatedGsamInfo/><userId>v473725</userId></userData></CLINFilterRequest></clinFilter>";
			obj.getClinList(manager, obj.callProcess(noFetCd));
			String inputXmlDao = "<clinFilter><CLINFilterRequest><clientId>PQ</clientId><transactionID>1</transactionID><contractDetails><contractID>J57711-00</contractID><customerRequestNumber/><customerRequestVersion/></contractDetails><productConfigurations><productBaseConfigurations><solutionCode/><productCode>PR_ACC</productCode><productGroup/></productBaseConfigurations><featureConfigurations><featureBaseConfigurations><featureCode>FET_LA</featureCode><featureInstanceID>10A</featureInstanceID></featureBaseConfigurations><chargeType/><specConfigurations><code>SP_ACC_TECH</code><value>Ethernet over TDM or DWDM</value></specConfigurations><specConfigurations><code>SP_ACC_SPEED</code><value>10 Mbps</value></specConfigurations><specConfigurations><code>SP_CUST_HAND_OFF_TYPE</code><value>Ethernt</value></specConfigurations></featureConfigurations></productConfigurations><userData><eId/><gsamLevels/><isAvailable/><translatedGsamInfo/><userId>v473725</userId></userData></CLINFilterRequest></clinFilter>";
			obj.getClinListDAO(manager, obj.callProcess(inputXmlDao));
			System.out
					.println(" ClinSelectServicesBeanTest .getClinListTest()  end ::: ");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@After
	public void afterTest() {
		manager.close();
		inputXml = null;
		responseObj = null;
	}

}
