package com.vz.gchclin.ws.select.internal;


import javax.ejb.EJB;
import com.vz.gchclin.common.dataobject.GetClinListIn;
import com.vz.gchclin.common.dataobject.GetClinListOut;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import com.vz.gchclin.beans.select.IClinRetrivalBean;

@WebService(name = "GCHCLINService", targetNamespace = "http://com.vz.gchclin.ws.select.external", serviceName = "GCHCLINService")
@SOAPBinding(style = SOAPBinding.Style.DOCUMENT, use = SOAPBinding.Use.LITERAL, parameterStyle = SOAPBinding.ParameterStyle.WRAPPED)
public class ClinWsSelectInternalServicesImpl implements ClinWsSelectInternalServices{


	
	@EJB(name="ClinRetrivalBean", mappedName="ClinRetrivalBean")
	private IClinRetrivalBean clinRetrivalBean;
	
	
	@WebMethod
	@WebResult(name = "CLINFilterResponse")
	@Override
	public GetClinListOut  clinFilter(@WebParam(name = "CLINFilterRequest")GetClinListIn getClinListIn) {
		return clinRetrivalBean.getClinList(getClinListIn);
	}
	
	
	
	
	
	
}
