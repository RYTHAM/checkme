package com.vz.gchclin.ws.select.internal;

import com.vz.gchclin.common.dataobject.GetClinListIn;
import com.vz.gchclin.common.dataobject.GetClinListOut;

public interface ClinWsSelectInternalServices{
	public GetClinListOut  clinFilter(GetClinListIn getClinListIn); 
}