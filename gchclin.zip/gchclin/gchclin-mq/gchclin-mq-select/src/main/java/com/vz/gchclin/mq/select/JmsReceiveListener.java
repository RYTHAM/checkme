package com.vz.gchclin.mq.select;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;
import javax.jms.BytesMessage;

import org.apache.log4j.Logger;


/**
 * A service that sends and receives JMS messages.
 * 
 * @auther lingrong.chen
 */
public abstract class JmsReceiveListener implements MessageListener {

	protected static Logger _logger = Logger
			.getLogger(JmsReceiveListener.class);

	public JmsReceiveListener() {
		super();
		init();
	}

	public void onMessage(Message message) {
		String METHOD_NAME = "JmsReceiveListener:onMessage()";

		if (_logger.isInfoEnabled()) {
			_logger.info(METHOD_NAME + "invoking JmsReceiveListener..");
		}

		if (message instanceof TextMessage) {
			_logger.info(METHOD_NAME + "Received TextMessage \n");
			try {
				String msg = ((TextMessage) message).getText();
				// send backend for parser and db process
				if (_logger.isInfoEnabled()) {
					_logger.info(METHOD_NAME + ": Calling Data Processor API: "
							+ " with msg:\n" + msg);
				}
				callProcess(msg);
			} catch (JMSException ex) {
				_logger.info(METHOD_NAME + "Receiving Message error = \n", ex);
				throw new RuntimeException(ex);
			}
		} else if (message instanceof BytesMessage) {
			_logger.info(METHOD_NAME + "Received BytesMessage \n");
			try {

				byte[] byteArr = new byte[(int) ((BytesMessage) message)
						.getBodyLength()];
				((BytesMessage) message).readBytes(byteArr);
				String msg = new String(byteArr);
				// send backend for parser and db process
				if (_logger.isInfoEnabled()) {
					_logger.info(METHOD_NAME + ": Calling Data Processor API: "
							+ " with msg:\n" + msg);
				}
				callProcess(msg);
			} catch (JMSException ex) {
				_logger.info(METHOD_NAME + "Receiving  Message error = \n", ex);
				throw new RuntimeException(ex);
			}
		} else {
			try {
				_logger.info(METHOD_NAME + "Recieved Message type: "
						+ message.getJMSType() + "\nRecieved Message: "
						+ message);
			} catch (JMSException ex) {
				_logger.info(METHOD_NAME + "Receiving Message error = \n", ex);
			}
			throw new IllegalArgumentException(
					"Message must be of type TextMessage");
		}
	}

	
	protected abstract void init();

	protected abstract void callProcess(String msg);
}
