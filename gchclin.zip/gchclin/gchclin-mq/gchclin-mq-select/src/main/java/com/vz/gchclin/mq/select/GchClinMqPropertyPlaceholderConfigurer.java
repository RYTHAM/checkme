package com.vz.gchclin.mq.select;

import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.commons.configuration.Configuration;

import com.vz.helpers.config.ConfigHelper;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;

public class GchClinMqPropertyPlaceholderConfigurer extends PropertyPlaceholderConfigurer {

  private static Logger _logger = Logger.getLogger(GchClinMqPropertyPlaceholderConfigurer.class);
  private String propertiesTable;

  /**
   * Provide a different prefix
   */
  public GchClinMqPropertyPlaceholderConfigurer() {
    super();
    setPlaceholderPrefix("#{");
  }

  @Override
  protected void loadProperties(Properties props) throws IOException {
    String METHOD_NAME = "GchClinMqPropertyPlaceholderConfigurer:loadProperties()";

    if (null == props) {
	throw new IOException("No properties passed by Spring framework - cannot proceed");
    }   
    
    try {
	
	// get endPoint for each env from salesview-config
	Configuration config = ConfigHelper.load("com.vz.gchclin", "gchclin-config", "config");
	props.setProperty("MQ_HOSTNAME",config.getString("mq/host"));
	props.setProperty("MQ_PORT",config.getString("mq/port"));
	props.setProperty("MQ_QUEUEMANAGER",config.getString("mq/queue-manager"));
	props.setProperty("MQ_CHANNEL",config.getString("mq/channel", "EIB.GCHCLIN.SVRCONN"));
	// clinlist
	props.setProperty("MULTI_TO_GCHCLIN_CLINLIST_DESTINATION",config.getString("mq/clinlist-queue"));
	

	if (_logger.isInfoEnabled()) {
	    _logger.info(METHOD_NAME + "\n: MQ_HOSTNAME = " + props.getProperty("MQ_HOSTNAME")
			 + "\n: MQ_PORT = " + props.getProperty("MQ_PORT")
			 + "\n: MQ_CHANNEL = " + props.getProperty("MQ_CHANNEL")
			 + "\n: MQ_QUEUEMANAGER = " + props.getProperty("MQ_QUEUEMANAGER"));
	    _logger.info(METHOD_NAME + "\n CLINLIST:"
			 + "\n: GCT_TO_GCH_DESTINATION = " + props.getProperty("MULTI_TO_GCHCLIN_CLINLIST_DESTINATION")
			);
	  
	}
	
        if (props.size() == 0) {
	    _logger.error(METHOD_NAME + "The configuration could not be reached or does not contain any properties in [" 
			       + props + "]");
	    
        }
        
    } catch (Exception ex){
	_logger.error(METHOD_NAME + ":Failed to connect or send message from  queues :", ex);
	    throw new IOException("Can't set properties" +ex);
    } 
  }

}
