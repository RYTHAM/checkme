package com.vz.gchclin.mq.select;


import org.jdom.Document;
import org.jdom.Element;
import com.vz.gchclin.common.dataobject.*;
import com.vz.gchclin.common.util.GCHClinRequestException;
import org.jdom.input.SAXBuilder;

import java.io.IOException;

import org.jdom.JDOMException;

import java.io.StringReader;
import com.vz.gchclin.common.ldap.LdapUserData;
import java.util.List;
import java.util.ArrayList;

import com.vz.gchclin.beans.select.IClinRetrivalBean;


import javax.naming.Context;
import javax.naming.InitialContext;


import org.apache.commons.configuration.Configuration;
import com.vz.gchclin.common.util.EIBMessageSender;
import com.vz.helpers.config.ConfigHelper;
/**
 * A service that sends and receives JMS messages.
 * 
 * @auther laxminarsimha.kongari
 */
public class ClinListJmsReceiveListener extends JmsReceiveListener {
	
	
	@Override
	protected void init() {
		String METHOD_NAME = "ClinListJmsReceiveListener:init()";
		_logger.warn(METHOD_NAME + ": ClinListJmsReceiveListener invoked...");
	}

	@Override
	protected void callProcess(String msg) {
		String METHOD_NAME = "ClinListJmsReceiveListener:callProcess(String msg):";
		
		if(_logger.isInfoEnabled()){
			_logger.info(METHOD_NAME + " Enter");
		}
		_logger.info(METHOD_NAME + "message -->"+msg);
		
		GetClinListIn request = null;
		try {
			// parse xml into GetClinListIn object structure request
			request = parse(msg);
			GetClinListOut out = getClinSelectServicesBean().getClinList(request);
			sendClinResponse("PQ", out);
		}catch (Exception e) {
			_logger.error(e.getMessage(), e);
		}
		
		if(_logger.isInfoEnabled()){
			_logger.info(METHOD_NAME + " Exit");
		}
	}
	
	
	
	public GetClinListIn parse(String requestXml) {
		String METHOD_NAME = "ClinListJmsReceiveListener::parse(String requestXml):";
		if (_logger.isInfoEnabled()) {
			_logger.info(METHOD_NAME + " parsing: " + requestXml);
		}
			
		Document doc = getJdomDocument(requestXml);
		Element root = doc.getRootElement();

		GetClinListIn req = new GetClinListIn();
		if(root != null){
			Element clinFilterRequest = root.getChild("CLINFilterRequest");
			req.setClientId(getChildElementText(clinFilterRequest, "clientId"));
			req.setTransactionID(getChildElementText(clinFilterRequest, "transactionID"));
			ContractDetails contractDetails = new ContractDetails();
			Element contractDetailsElement = clinFilterRequest.getChild("contractDetails");
			contractDetails.setContractID(getChildElementText(contractDetailsElement, "contractID"));
			contractDetails.setCustomerRequestNumber(getChildElementText(contractDetailsElement, "customerRequestNumber"));
			contractDetails.setCustomerRequestVersion(getChildElementText(contractDetailsElement, "customerRequestVersion"));
			//contractDetails.setTransactionID(getChildElementText(contractDetailsElement, "transactionID"));
			req.setContractDetails(contractDetails);
			
			Element userDataInfo = clinFilterRequest.getChild("userData");
			LdapUserData userData = new LdapUserData();
			userData.setUserId(getChildElementText(userDataInfo, "userId"));
			userData.seteId(getChildElementText(userDataInfo, "eId"));
			req.setUserData(userData);
			
			List<Element> productConfigurationsElements = clinFilterRequest.getChildren("productConfigurations");
			List<ProductConfigurations> productConfigurationsList = new ArrayList<ProductConfigurations>();
			List<FeatureConfigurations> featureConfigurationsList = null;
			List<SpecConfigurations> specConfigurationsList = null;
			ProductConfigurations productConfigurations = null;
			ProductBaseConfigurations productBaseConfigurations = null;
			FeatureConfigurations featureConfigurations = null;
			FeatureBaseConfigurations featureBaseConfigurations = null;
			SpecConfigurations specConfigurations = null;
			for(Element productConfigurationsElement : productConfigurationsElements){
				featureConfigurationsList = new ArrayList<FeatureConfigurations>();
				productConfigurations = new ProductConfigurations();
				productBaseConfigurations = new ProductBaseConfigurations();
				Element productBaseConfigurationsElement = productConfigurationsElement.getChild("productBaseConfigurations");
				productBaseConfigurations.setSolutionCode(getChildElementText(productBaseConfigurationsElement, "solutionCode"));
				productBaseConfigurations.setProductGroup(getChildElementText(productBaseConfigurationsElement, "productGroup"));
				productBaseConfigurations.setProductCode(getChildElementText(productBaseConfigurationsElement, "productCode"));
				List<Element> featureConfigurationsElements = productConfigurationsElement.getChildren("featureConfigurations");
				for(Element featureConfigurationsElement : featureConfigurationsElements){
					featureBaseConfigurations = new FeatureBaseConfigurations();
					featureConfigurations = new FeatureConfigurations();
					specConfigurationsList = new ArrayList<SpecConfigurations>();
					Element featureBaseConfigurationsElement = featureConfigurationsElement.getChild("featureBaseConfigurations");
					featureBaseConfigurations.setFeatureCode(getChildElementText(featureBaseConfigurationsElement, "featureCode"));
					featureBaseConfigurations.setFeatureInstanceID(getChildElementText(featureBaseConfigurationsElement, "featureInstanceID"));
					featureConfigurations.setChargeType(getChildElementText(featureConfigurationsElement, "chargeType"));
					featureConfigurations.setFeatureBaseConfigurations(featureBaseConfigurations);
					List<Element> specConfigurationsElements = featureConfigurationsElement.getChildren("specConfigurations");
					for(Element specConfigurationsElement : specConfigurationsElements){
						specConfigurations = new SpecConfigurations();
						specConfigurations.setCode(getChildElementText(specConfigurationsElement, "code"));
						specConfigurations.setValue(getChildElementText(specConfigurationsElement, "value"));
						specConfigurationsList.add(specConfigurations);
					}
					featureConfigurations.setSpecConfigurations(specConfigurationsList);
					featureConfigurationsList.add(featureConfigurations);
				}
				productConfigurations.setProductBaseConfigurations(productBaseConfigurations);
				productConfigurations.setFeatureConfigurations(featureConfigurationsList);
				productConfigurationsList.add(productConfigurations);
			}
			req.setProductConfigurations(productConfigurationsList);
		}
					
		if (_logger.isInfoEnabled()) {
			_logger.info(METHOD_NAME + " end "  );
		}
		return req;
	}
	
	
	private Document getJdomDocument(String xmlString) {
		String METHOD_NAME = "ContractRequestXmlParser:getJdomDocument():";
		SAXBuilder builder = new SAXBuilder();

		try {
			StringReader sr = new StringReader(xmlString);
			Document doc = builder.build(sr);
			return doc;

		} catch (JDOMException e) {
			_logger.error(METHOD_NAME + "error parsing manageAccount request: "
					+ xmlString, e);
			throw new GCHClinRequestException("error parsing: " + xmlString, e);

		} catch (IOException e) {
			_logger.error(METHOD_NAME + "error parsing manageAccount request: "
					+ xmlString, e);
			throw new GCHClinRequestException("error parsing: " + xmlString, e);

		}
	}

	private String getChildElementText(Element pe, String childName) {
		try {
			String value = null;

			Element ce = pe.getChild(childName);
			if (ce != null) {
				String originalValue = ce.getText();
				if (originalValue != null) {
					value = originalValue.trim();
				}
			}

			if (_logger.isDebugEnabled()) {
				_logger.debug(childName + " -> [" + value + "]");
			}
			return value;

		} catch (Exception e) {
			_logger.error("error parsing child element " + childName, e);
			return null;
		}
	}
	
	
	/*public static void main(String[] a){
		String msg = "<CLINFilterRequest><ContractID>Contract1</ContractID><CustomerRequestNumber></CustomerRequestNumber><CustomerRequestVersion></CustomerRequestVersion><ProductConfigurations><SolutionCode></SolutionCode><ProductGroup></ProductGroup><ProductCode>PR_PIP</ProductCode><FeatureConfigurations><FeatureCode>FET_XX</FeatureCode><FeatureInstanceID>10A</FeatureInstanceID><ChargeType></ChargeType><SpecConfigurations><Code>Key1</Code><Value>Value1</Value></SpecConfigurations><SpecConfigurations><Code>Key2</Code><Value>Value2</Value></SpecConfigurations></FeatureConfigurations></ProductConfigurations><ProductConfigurations><SolutionCode></SolutionCode><ProductGroup></ProductGroup><ProductCode>PR_ACC</ProductCode><FeatureConfigurations><FeatureCode>FET_YY</FeatureCode><FeatureInstanceID>101</FeatureInstanceID><ChargeType>NRC</ChargeType><SpecConfigurations><Code>Key1</Code><Value>Value1</Value></SpecConfigurations><SpecConfigurations><Code>Key2</Code><Value>Value2</Value></SpecConfigurations><SpecConfigurations><Code>Key3</Code><Value>Value3</Value></SpecConfigurations></FeatureConfigurations><FeatureConfigurations><FeatureCode>FET_ZZ</FeatureCode><FeatureInstanceID>102</FeatureInstanceID><SpecConfigurations><Code>Key1</Code><Value>Value1</Value></SpecConfigurations></FeatureConfigurations></ProductConfigurations></CLINFilterRequest>";
		ClinListJmsReceiveListener obj = new ClinListJmsReceiveListener();
		obj.callProcess(msg);
	}*/
	
	
	public static IClinRetrivalBean getClinSelectServicesBean() throws Exception{
    	String METHOD_NAME = " [ClinListJmsReceiveListener::getClinSelectServicesBean] ";
        _logger.info(METHOD_NAME + " ENTER : ");
        String jndiName = "ClinRetrivalBean#com.vz.gchclin.beans.select.IClinRetrivalBean";
        IClinRetrivalBean spBean =null;
              
		try {
			Context ctx = new InitialContext();
			spBean = (IClinRetrivalBean) ctx.lookup(jndiName);
		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
		}
        
          if (_logger.isInfoEnabled()) {
            _logger.info("looked up EJB " );
        }
        return spBean;
    }
	
	
	public String generateResponse(GetClinListOut rs){
		String METHOD_NAME = "ClinSelectServicesHelper.generateResponse";
		_logger.debug(METHOD_NAME + " start");
		StringBuffer sb = new StringBuffer();
		
		sb.append("<clinFilterResponse>");
		sb.append("<CLINFilterResponse>");

		sb.append("<transactionCode>").append(rs.getTransactionCode());
		sb.append("</transactionCode>");
		sb.append("<transactionStatus>").append(rs.getTransactionStatus());
		sb.append("</transactionStatus>");
		sb.append("<errorMessage>").append(rs.getErrorMessage());
		sb.append("</errorMessage>");
		sb.append("<transactionID>").append(rs.getTransactionID());
		sb.append("</transactionID>");
		if(rs.getTransactionCode().equals("000") || rs.getTransactionCode().equals("004")){
		sb.append("<contractDetails>");
		sb.append("<contractID>").append(rs.getContractDetails().getContractID());
		sb.append("</contractID>");
		sb.append("<customerRequestNumber>").append(rs.getContractDetails().getCustomerRequestNumber());
		sb.append("</customerRequestNumber>");
		sb.append("<customerRequestVersion>").append(rs.getContractDetails().getCustomerRequestVersion());
		sb.append("</customerRequestVersion>");
		
		sb.append("</contractDetails>");
		for(ProductConfigurationResponse productConfigRes : rs.getProductConfigurationResponse()){
			sb.append("<productConfigurationResponse>");
			sb.append("<productBaseConfigurations>");
			sb.append("<solutionCode>").append(productConfigRes.getProductBaseConfigurations().getSolutionCode());
			sb.append("</solutionCode>");
			sb.append("<productCode>").append(productConfigRes.getProductBaseConfigurations().getProductCode());;
			sb.append("</productCode>");
			sb.append("</productBaseConfigurations>");
			for(FeatureConfigurationResponse featureConfigRes : productConfigRes.getFeatureConfigurationResponse()){
				sb.append("<featureConfigurationResponse>");
				sb.append("<featureBaseConfigurations>");
				sb.append("<featureCode>").append(featureConfigRes.getFeatureBaseConfigurations().getFeatureCode());
				sb.append("</featureCode>");
				sb.append("<featureInstanceID>").append(featureConfigRes.getFeatureBaseConfigurations().getFeatureInstanceID());
				sb.append("</featureInstanceID>");
				sb.append("</featureBaseConfigurations>");
				if(null == featureConfigRes.getClins()){
					sb.append("<clinError>");
					sb.append("<clinErrorCode>").append(featureConfigRes.getClinError().getClinErrorCode());
					sb.append("</clinErrorCode>");
					sb.append("<clinErrorDescription>").append(featureConfigRes.getClinError().getClinErrorDescription());
					sb.append("</clinErrorDescription>");
					sb.append("<invalidSpecConfigurations>");
					sb.append("<chargeType>").append(featureConfigRes.getClinError().getInvalidSpecConfigurations().getChargeType());
					sb.append("</chargeType>");
					for(SpecConfigurations specConfig : featureConfigRes.getClinError().getInvalidSpecConfigurations().getSpecConfigurations()){
						sb.append("<specConfigurations>");
						sb.append("<code>").append(specConfig.getCode());
						sb.append("</code>");
						sb.append("<value>").append(specConfig.getValue());
						sb.append("</value>");
						sb.append("</specConfigurations>");
					}
					sb.append("</invalidSpecConfigurations>");
					sb.append("</clinError>");					
				}else{
					for(Clins clinRes : featureConfigRes.getClins()){
						sb.append("<clins>");
						sb.append("<clin>").append(clinRes.getClin());
						sb.append("</clin>");
						sb.append("<clinDescription><![CDATA[").append(clinRes.getClinDescription());
						sb.append("]]></clinDescription>");
						sb.append("<chargeType>").append(clinRes.getChargeType());
						sb.append("</chargeType>");
						sb.append("</clins>");
					}
				}
				sb.append("</featureConfigurationResponse>");
			}
			sb.append("</productConfigurationResponse>");
		}
		}
		sb.append("</CLINFilterResponse>");
		sb.append("</clinFilterResponse>");
		_logger.debug(METHOD_NAME + " Response XML is :::: " + sb.toString());
		_logger.debug(METHOD_NAME + " end");
		return sb.toString();
	}
	
	
	private void sendClinResponse(String system, GetClinListOut responseData) {
		String METHOD_NAME = "ClinSelectServicesHelper:sendClinResponse():";
		Configuration config = ConfigHelper.load("com.vz.gchclin", "gchclin-config", "config");
		EIBMessageSender p = new EIBMessageSender();
		_logger.info("EIB connection details :::  host::" + config.getString("mq/host")
				 + "channel :: " + config.getString("mq/channel") + "port ::" + config.getString("mq/port") + " Res Queue Name ::"
				 + config.getString("mq/pq/ack-queue") + " Queue Manager ::" + config.getString("mq/queue-manager"));
		p.setHost(config.getString("mq/host"));
		p.setChannel(config.getString("mq/channel"));
		p.setPort(Integer.parseInt(config.getString("mq/port")));
		p.setType(1);
		p.setQueName(config.getString("mq/pq/ack-queue"));
		//p.setQueName(config.getString("mq/clinlist-queue"));
		
		p.setQueueManager(config.getString("mq/queue-manager"));
		
		try {
			if (responseData != null){
				String respStr = generateResponse(responseData);
				if (_logger.isInfoEnabled())
					_logger.info(METHOD_NAME + ": CLIN Response is :: "
									+ respStr);
				p.setMessage(respStr);
				p.sendMessage();				
			}else{
				_logger.error(METHOD_NAME
								+ " Response XML is null");
			}
		} catch (Exception ex) {
			_logger.error(METHOD_NAME + " CLINFilterResponse to PQ is failed:", ex);
		}
	}
	

}
