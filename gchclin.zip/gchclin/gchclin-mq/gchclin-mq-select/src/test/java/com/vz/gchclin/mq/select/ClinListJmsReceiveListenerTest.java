package com.vz.gchclin.mq.select;

import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import com.vz.gchclin.common.dataobject.GetClinListIn;
import com.vz.gchclin.common.dataobject.GetClinListOut;
import static org.junit.Assert.*;
import com.vz.gchclin.beans.select.ClinSelectServicesBean;
import org.springframework.jndi.JndiObjectFactoryBean;
import com.vz.gchclin.beans.select.IClinRetrivalBean;
import java.util.List;
import java.util.ArrayList;
import com.vz.gchclin.common.dataobject.*;
import com.vz.gchclin.common.ldap.LdapUserData;
import java.util.Date;
import java.io.IOException;


public class ClinListJmsReceiveListenerTest {
	
	private String inputXml; 
	private GetClinListIn inputObject;
	private GetClinListOut out;
	

  @Before
  public void beforeTest() {
	 
	 inputXml = "<clinFilter><CLINFilterRequest><clientId>PQ</clientId><contractDetails><transactionID>1</transactionID><contractID>Contract1</contractID><customerRequestNumber>1</customerRequestNumber><customerRequestVersion>2</customerRequestVersion></contractDetails><productConfigurations><productBaseConfigurations><productCode>FET_ACC</productCode><productGroup>pg</productGroup></productBaseConfigurations><featureConfigurations><featureBaseConfigurations><featureCode>FET_ACC_PHY_CNG</featureCode><featureInstanceID>10A</featureInstanceID></featureBaseConfigurations><chargeType>MRC</chargeType><specConfigurations><code>SP_COUNTRY</code><value>Value2</value></specConfigurations><specConfigurations><code>SP_ACC_SPEED</code><value>Value2</value></specConfigurations><specConfigurations><code>SP_COUNTRY</code><value>Value1</value></specConfigurations></featureConfigurations></productConfigurations><productConfigurations><productBaseConfigurations><productCode>FET_ACC1</productCode><productGroup>pg1</productGroup></productBaseConfigurations><featureConfigurations><featureBaseConfigurations><featureCode>FET_ACC_PHY_CNG___222</featureCode><featureInstanceID>10B</featureInstanceID></featureBaseConfigurations><chargeType>MRC</chargeType><specConfigurations><code>SP_COUNTRY</code><value>Value222</value></specConfigurations></featureConfigurations><featureConfigurations><featureBaseConfigurations><featureCode>FET_ACC_PHY_CNG___333</featureCode><featureInstanceID>10c</featureInstanceID></featureBaseConfigurations><chargeType></chargeType><specConfigurations><code>SP_ee</code><value>Value222</value></specConfigurations></featureConfigurations></productConfigurations><userData><eId>eid</eId><userId>v473725</userId></userData></CLINFilterRequest></clinFilter>";

	  //inputXml = null;
	 out = new GetClinListOut();
	 out.setErrorMessage(null);
  }

  @Test
  public void testParseInputXml() {
    try {
    	System.out.println("ClinListJmsReceiveListenerTest.testParseInputXml() start ::: ");
    	ClinListJmsReceiveListener listener = new ClinListJmsReceiveListener();
    	if(null != inputXml)
    		inputObject = listener.parse(inputXml);
    	
    	System.out.println("ClinListJmsReceiveListenerTest.testParseInputXml() parsed object is::  " + inputObject.getClientId());
    	System.out.println("ClinListJmsReceiveListenerTest.testParseInputXml() end ::: ");
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }
  
  

  
 /* @Test
  public void testConstructOutObject() {
    try {
    	System.out.println("ClinListJmsReceiveListenerTest.testConstructOutObject() start ::: ");
    	ClinListJmsReceiveListener listener = new ClinListJmsReceiveListener();
    	String outObj = null;
    	if(null != out)
    		outObj= listener.generateResponse(out);
    	assertNotNull(outObj);
    	System.out.println("ClinListJmsReceiveListenerTest.test() outObj is::  " + outObj);
    	System.out.println("ClinListJmsReceiveListenerTest.testConstructOutObject() end ::: ");
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }
  */
  
  @Test
  public void testGetClinSelectServicesBean(){
	  try {
	    	System.out.println("ClinListJmsReceiveListenerTest.testGetClinSelectServicesBean() start ::: ");
	    	IClinRetrivalBean ejbObj = ClinListJmsReceiveListener.getClinSelectServicesBean();
	    	//assertNotNull(ejbObj);
	    	
	    	System.out.println("ClinListJmsReceiveListenerTest.testParseInputXml() end ::: ");
	    } catch (Exception ex) {
	      ex.printStackTrace();
	    }
	  
  }
  
  @Test
  public void generateResponseTest(){
	  ClinListJmsReceiveListener listener = new ClinListJmsReceiveListener();
	  
	  GetClinListOut out = new GetClinListOut();
		out.setTransactionID("1");
		
		ContractDetails conObj = new ContractDetails();
		conObj.setContractID("J576-00");
		conObj.setCustomerRequestNumber("setCustomerRequestNumber");
		conObj.setCustomerRequestVersion("0");
		System.out.println("Contract input obj is " + conObj.getContractID() +" ," + conObj.getCustomerRequestNumber() + " ," + conObj.getCustomerRequestVersion());
		System.out.println(conObj.toString());
		
		out.setContractDetails(conObj);
		out.setErrorMessage("no error");
		
		List<ProductConfigurationResponse> resList = new ArrayList<ProductConfigurationResponse>();
		ProductConfigurationResponse resObj = new ProductConfigurationResponse();
		
		ProductBaseConfigurations productBaseConfigurations = new ProductBaseConfigurations();
		productBaseConfigurations.setSolutionCode("solutionCode");
		productBaseConfigurations.setProductGroup("productGroup");
		productBaseConfigurations.setProductCode("productCode");
		
		resObj.setProductBaseConfigurations(productBaseConfigurations);
		
		System.out.println(productBaseConfigurations.toString());
		System.out.println("productBaseConfigurations" + productBaseConfigurations.getSolutionCode() + ", " + productBaseConfigurations.getProductGroup() + ", " + productBaseConfigurations.getProductCode());
		
		List<FeatureConfigurationResponse> fetResList = new ArrayList<FeatureConfigurationResponse>();
		
		FeatureConfigurationResponse fetResObj = new FeatureConfigurationResponse();
		FeatureBaseConfigurations featureBaseConfigurations = new FeatureBaseConfigurations();
		featureBaseConfigurations.setFeatureCode("featureCode");
		featureBaseConfigurations.setFeatureInstanceID("featureInstanceID");
		System.out.println(featureBaseConfigurations.toString());
		System.out.println("featureBaseConfigurations " + featureBaseConfigurations.getFeatureCode() + ", " + featureBaseConfigurations.getFeatureInstanceID());
		
		fetResObj.setFeatureBaseConfigurations(featureBaseConfigurations);
		
		List<Clins> clinList = new ArrayList<Clins>();
		Clins clinsObj = new Clins();
		clinsObj.setClin("clin");
		clinsObj.setClinDescription("clin.getClinDesc()");
		clinsObj.setChargeType("REC");
		System.out.println(clinsObj.toString());
		System.out.println(clinsObj.getClin() +" " + clinsObj.getClinDescription() +" " + clinsObj.getChargeType());
		clinList.add(clinsObj);
		
		fetResObj.setClins(clinList);
		
		
		System.out.println(fetResObj.toString());
		System.out.println(fetResObj.getClins() + " "  +fetResObj.getFeatureBaseConfigurations());
		
		fetResList.add(fetResObj);
		resObj.setFeatureConfigurationResponse(fetResList);
		
		System.out.println(resObj.toString());
		
		System.out.println(resObj.getFeatureConfigurationResponse() + "" + resObj.getProductBaseConfigurations() );
		resList.add(resObj);
		out.setProductConfigurationResponse(resList); 
		
		System.out.println(out.getTransactionID() + " " + out.getContractDetails() + " " + out.getProductConfigurationResponse() + " " + out.getErrorMessage());
		System.out.println(out.toString());
		out.setTransactionCode("000");
		out.setTransactionStatus("Success");
		
	  listener.generateResponse(out);
	  
  }
  
  @Test
  public void callProcessTest(){
	  ClinListJmsReceiveListener listener = new ClinListJmsReceiveListener();
	  listener.callProcess(inputXml);
  }
  
  @Test
  public void generateResponseTestWithClinErr(){
	  ClinListJmsReceiveListener listener = new ClinListJmsReceiveListener();
	  
	  GetClinListOut out = new GetClinListOut();
		out.setTransactionID("1");
		
		ContractDetails conObj = new ContractDetails();
		conObj.setContractID("J576-00");
		conObj.setCustomerRequestNumber("setCustomerRequestNumber");
		conObj.setCustomerRequestVersion("0");
		System.out.println("Contract input obj is " + conObj.getContractID() +" ," + conObj.getCustomerRequestNumber() + " ," + conObj.getCustomerRequestVersion());
		System.out.println(conObj.toString());
		
		out.setContractDetails(conObj);
		out.setErrorMessage("no error");
		
		List<ProductConfigurationResponse> resList = new ArrayList<ProductConfigurationResponse>();
		ProductConfigurationResponse resObj = new ProductConfigurationResponse();
		
		ProductBaseConfigurations productBaseConfigurations = new ProductBaseConfigurations();
		productBaseConfigurations.setSolutionCode("solutionCode");
		productBaseConfigurations.setProductGroup("productGroup");
		productBaseConfigurations.setProductCode("productCode");
		
		resObj.setProductBaseConfigurations(productBaseConfigurations);
		
		System.out.println(productBaseConfigurations.toString());
		System.out.println("productBaseConfigurations" + productBaseConfigurations.getSolutionCode() + ", " + productBaseConfigurations.getProductGroup() + ", " + productBaseConfigurations.getProductCode());
		
		List<FeatureConfigurationResponse> fetResList = new ArrayList<FeatureConfigurationResponse>();
		
		FeatureConfigurationResponse fetResObj = new FeatureConfigurationResponse();
		FeatureBaseConfigurations featureBaseConfigurations = new FeatureBaseConfigurations();
		featureBaseConfigurations.setFeatureCode("featureCode");
		featureBaseConfigurations.setFeatureInstanceID("featureInstanceID");
		System.out.println(featureBaseConfigurations.toString());
		System.out.println("featureBaseConfigurations " + featureBaseConfigurations.getFeatureCode() + ", " + featureBaseConfigurations.getFeatureInstanceID());
		
		fetResObj.setFeatureBaseConfigurations(featureBaseConfigurations);
		
		
		ClinError clinErrorObj = new ClinError();
		clinErrorObj.setClinErrorCode("008");
		clinErrorObj.setClinErrorDescription("No CLIN found for billable feature ");
		InvalidSpecConfigurations invalidSpecConfigurationsRes = new InvalidSpecConfigurations();
		invalidSpecConfigurationsRes.setChargeType("REC");
		List<SpecConfigurations> specConfigurationsList  = new ArrayList<SpecConfigurations>();
		SpecConfigurations specConfigurations = new SpecConfigurations();
		specConfigurations.setCode("code");
		specConfigurations.setValue("value");
		specConfigurationsList.add(specConfigurations);
		
		System.out.println(specConfigurations.toString());
		System.out.println("specConfigurations " + specConfigurations.getCode() + ", " + specConfigurations.getValue() );
		invalidSpecConfigurationsRes.setSpecConfigurations(specConfigurationsList);
		System.out.println(invalidSpecConfigurationsRes.getChargeType() + " " +invalidSpecConfigurationsRes.getSpecConfigurations());
		System.out.println(invalidSpecConfigurationsRes.toString());
		
		System.out.println(clinErrorObj.toString());
		System.out.println(clinErrorObj.getClinErrorCode() + " " +clinErrorObj.getClinErrorDescription() + " " +clinErrorObj.getInvalidSpecConfigurations());
		
		clinErrorObj.setInvalidSpecConfigurations(invalidSpecConfigurationsRes);
		
		fetResObj.setClinError(clinErrorObj);
		System.out.println(fetResObj.toString());
		System.out.println(fetResObj.getClinError() + " " +fetResObj.getFeatureBaseConfigurations());
		
		fetResList.add(fetResObj);
		resObj.setFeatureConfigurationResponse(fetResList);
		
		System.out.println(resObj.toString());
		
		System.out.println(resObj.getFeatureConfigurationResponse() + "" + resObj.getProductBaseConfigurations() );
		resList.add(resObj);
		out.setProductConfigurationResponse(resList); 
		
		System.out.println(out.getTransactionID() + " " + out.getContractDetails() + " " + out.getProductConfigurationResponse() + " " + out.getErrorMessage());
		System.out.println(out.toString());
		out.setTransactionCode("000");
		out.setTransactionStatus("Success");
		
	  listener.generateResponse(out);
	  
  }
  
  
  @Test
  public void propTest(){
	  GchClinMqPropertyPlaceholderConfigurer conf = new GchClinMqPropertyPlaceholderConfigurer();
	  try{
		  conf.loadProperties(new java.util.Properties());
	  }catch(IOException e){
		  
	  } 
  }

  @After
  public void afterTest() {
	  inputXml = null; 
  }
  
}
