test the build
test to check DEV2 to DEV4 propagation - Good
test to check DEV2 =/= DEV4 ==> DEV1